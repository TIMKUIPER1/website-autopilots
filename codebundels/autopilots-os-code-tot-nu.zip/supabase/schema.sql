create table if not exists public.sales_team_members (
  id text primary key,
  ghl_user_id text,
  full_name text not null,
  email text not null unique,
  role text not null check (role in ('admin', 'setter', 'closer')),
  preferred_language text not null default 'nl' check (preferred_language in ('nl', 'en')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.sales_login_sessions (
  id uuid primary key default gen_random_uuid(),
  team_member_id text not null references public.sales_team_members(id) on delete cascade,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  duration_seconds integer
);

create table if not exists public.ghl_opportunity_events (
  id text primary key,
  contact_id text,
  assigned_user_id text,
  pipeline_id text,
  stage_id text,
  status text,
  monetary_value numeric,
  created_at timestamptz,
  updated_at timestamptz,
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.sales_calls (
  id text primary key,
  contact_id text,
  contact_name text,
  setter_user_id text,
  closer_user_id text,
  call_started_at timestamptz,
  duration_seconds integer,
  answered boolean not null default false,
  result text,
  recording_url text,
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.sales_call_transcripts (
  call_id text primary key references public.sales_calls(id) on delete cascade,
  transcript text not null,
  language text not null default 'nl',
  created_at timestamptz not null default now()
);

create table if not exists public.sales_ai_scores (
  call_id text primary key references public.sales_calls(id) on delete cascade,
  total_score integer not null,
  went_well jsonb not null default '[]'::jsonb,
  could_improve jsonb not null default '[]'::jsonb,
  missed_moment text,
  created_at timestamptz not null default now()
);

create index if not exists sales_calls_setter_idx on public.sales_calls(setter_user_id);
create index if not exists sales_calls_closer_idx on public.sales_calls(closer_user_id);
create index if not exists ghl_opportunity_stage_idx on public.ghl_opportunity_events(stage_id);

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  legal_name text,
  status text not null default 'active' check (status in ('lead', 'active', 'paused', 'churned')),
  owner_team_member_id text references public.sales_team_members(id),
  ghl_company_id text,
  stripe_customer_id text,
  clickup_reference text,
  health_status text not null default 'unknown' check (health_status in ('green', 'orange', 'red', 'unknown')),
  mrr numeric not null default 0,
  setup_revenue numeric not null default 0,
  gross_margin_percent numeric,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.customer_domains (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  domain text not null,
  verified boolean not null default false,
  source_system text,
  created_at timestamptz not null default now(),
  unique (domain)
);

create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete set null,
  full_name text,
  email text,
  phone text,
  role text,
  ghl_contact_id text,
  source_system text,
  source_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.integration_accounts (
  id uuid primary key default gen_random_uuid(),
  source_system text not null,
  label text not null,
  owner text,
  status text not null default 'planned' check (status in ('planned', 'connected', 'error', 'paused')),
  last_synced_at timestamptz,
  created_at timestamptz not null default now(),
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.sync_runs (
  id uuid primary key default gen_random_uuid(),
  integration_account_id uuid references public.integration_accounts(id) on delete set null,
  source_system text not null,
  status text not null check (status in ('running', 'success', 'failed')),
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  records_seen integer not null default 0,
  records_changed integer not null default 0,
  error_message text,
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.raw_imports (
  id uuid primary key default gen_random_uuid(),
  sync_run_id uuid references public.sync_runs(id) on delete set null,
  source_system text not null,
  source_id text not null,
  entity_type text not null,
  payload jsonb not null,
  imported_at timestamptz not null default now(),
  unique (source_system, source_id, entity_type)
);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete set null,
  title text not null,
  document_type text not null,
  storage_path text,
  source_system text,
  source_id text,
  confidence_score numeric,
  review_status text not null default 'pending' check (review_status in ('pending', 'approved', 'rejected', 'needs_review')),
  created_at timestamptz not null default now(),
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.invoices_sales (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete set null,
  stripe_invoice_id text unique,
  invoice_number text,
  amount numeric not null default 0,
  currency text not null default 'eur',
  status text not null default 'draft',
  issued_at timestamptz,
  due_at timestamptz,
  paid_at timestamptz,
  source_system text not null default 'stripe',
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.invoices_purchase (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete set null,
  vendor_name text not null,
  invoice_number text,
  amount numeric not null default 0,
  currency text not null default 'eur',
  category text,
  spend_type text not null default 'business' check (spend_type in ('business', 'private', 'mixed', 'unknown')),
  status text not null default 'pending' check (status in ('pending', 'approved', 'paid', 'rejected')),
  issued_at timestamptz,
  due_at timestamptz,
  paid_at timestamptz,
  source_system text,
  source_id text,
  confidence_score numeric,
  review_status text not null default 'pending' check (review_status in ('pending', 'approved', 'rejected', 'needs_review')),
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.review_items (
  id uuid primary key default gen_random_uuid(),
  item_type text not null,
  source_system text not null,
  source_id text,
  company_id uuid references public.companies(id) on delete set null,
  title text not null,
  suggestion text,
  confidence_score numeric,
  status text not null default 'open' check (status in ('open', 'approved', 'changed', 'ignored')),
  assigned_to text references public.sales_team_members(id) on delete set null,
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  raw jsonb not null default '{}'::jsonb
);

create table if not exists public.audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_team_member_id text references public.sales_team_members(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  before_value jsonb,
  after_value jsonb,
  created_at timestamptz not null default now()
);

create index if not exists companies_stripe_customer_idx on public.companies(stripe_customer_id);
create index if not exists companies_ghl_company_idx on public.companies(ghl_company_id);
create index if not exists contacts_email_idx on public.contacts(email);
create index if not exists documents_company_idx on public.documents(company_id);
create index if not exists invoices_sales_company_idx on public.invoices_sales(company_id);
create index if not exists invoices_purchase_company_idx on public.invoices_purchase(company_id);
create index if not exists review_items_status_idx on public.review_items(status);
