const assert = require("node:assert/strict");
const test = require("node:test");
const { __test } = require("../server");

test("securityHeaders adds baseline browser protections", () => {
  const headers = __test.securityHeaders({ "Content-Type": "application/json" });
  assert.equal(headers["X-Content-Type-Options"], "nosniff");
  assert.equal(headers["X-Frame-Options"], "SAMEORIGIN");
  assert.match(headers["Content-Security-Policy"], /default-src 'self'/);
});

test("safeJsonParse returns fallback for invalid JSON", () => {
  assert.deepEqual(__test.safeJsonParse("{\"ok\":true}"), { ok: true });
  assert.equal(__test.safeJsonParse("not-json", "fallback"), "fallback");
});

test("supabaseEnabled returns a boolean", () => {
  assert.equal(typeof __test.supabaseEnabled(), "boolean");
});

test("filterForRole hides finance and management data for setters", () => {
  const data = {
    viewer: null,
    team: [
      { id: "setter-1", role: "setter" },
      { id: "closer-1", role: "closer" }
    ],
    calls: [
      { id: "call-1", ownerId: "setter-1" },
      { id: "call-2", ownerId: "setter-2" }
    ],
    setters: [
      {
        id: "setter-1",
        callMinutes: 10,
        callsToday: 2,
        callsWeek: 4,
        answeredCalls: 3,
        noShows: 1,
        bingos: 1,
        callsPerBingo: 4,
        conversationsPerBingo: 3,
        bingosPerHour: 6,
        nopePerBingo: 1
      }
    ],
    closers: [{ id: "closer-1" }],
    totals: {},
    os: {
      ceo: {},
      finance: {},
      marketing: {},
      teamOps: {},
      customers: [{ id: "cust-1", name: "Klant", openInvoices: 100, usageCost: 50 }]
    }
  };
  const result = __test.filterForRole(data, { id: "setter-1", role: "setter", email: "s@example.com", name: "Setter" });
  assert.equal(result.os.finance, null);
  assert.equal(result.os.marketing, null);
  assert.equal(result.calls.length, 1);
  assert.equal(result.closers.length, 0);
  assert.equal(result.setters.length, 1);
});

test("buildCashflowForecast calculates rolling ending cash", () => {
  const rows = __test.buildCashflowForecast({
    cashPosition: 1000,
    forecast7Days: 500,
    forecast30Days: 1200,
    weeklyBusinessSpend: 100,
    weeklyPrivateSpend: 50,
    weeklyMixedSpend: 25,
    mrr: 300
  });
  assert.equal(rows[0].endingCash, 1325);
  assert.equal(rows[1].startingCash, 1325);
  assert.equal(rows[2].totalOutgoing, 700);
});

test("buildStripeForecast uses fallback when there is no Stripe data", () => {
  const fallback = [{ id: "fallback", expectedPaymentAt: "2026-07-20" }];
  assert.deepEqual(__test.buildStripeForecast({ invoices: [], upcomingSubscriptions: [] }, fallback), fallback);
});

test("buildFinanceMatching creates review match with reasons", () => {
  const result = __test.buildFinanceMatching({
    transactions: [{
      id: "tx-1",
      date: "2026-07-20",
      description: "Nova Dental AP-100",
      amount: 100,
      currency: "EUR",
      direction: "incoming",
      spendType: "business",
      source: "Wise"
    }],
    invoiceForecast: [{
      id: "inv-1",
      invoiceNumber: "AP-100",
      customer: "Nova Dental",
      amount: 100,
      status: "open",
      expectedPaymentAt: "2026-07-20"
    }],
    uploadedInvoices: [],
    decisions: {}
  });
  assert.equal(result.summary.total, 1);
  assert.equal(result.matches[0].targetId, "inv-1");
  assert.ok(result.matches[0].confidence >= 90);
});
