create table if not exists public.integration_health (
  source_system text primary key,
  status text not null default 'unknown' check (status in ('unknown', 'success', 'partial', 'error', 'demo', 'stale')),
  detail text,
  metadata jsonb not null default '{}'::jsonb,
  checked_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
