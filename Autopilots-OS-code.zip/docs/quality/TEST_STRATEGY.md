# Test Strategy - Autopilots OS

## Huidige situatie

`sales-dashboard` heeft geen testscript, geen testframework en geen dependencyconfig. Kritieke logica zoals finance matching, Stripe forecast, role filtering en GHL normalisatie is ongetest.

## Unit tests

Start met pure functies uit `server.js`:

- `buildFinanceMatching`
- `scoreSalesInvoiceCandidate`
- `scoreUploadedInvoiceCandidate`
- `suggestFinanceCategory`
- `buildCashflowForecast`
- `buildStripeForecast`
- `filterForRole`
- `normalizeStripeInvoice`
- `normalizeWiseTransaction`
- KPI-berekeningen voor setters/closers
- validators en parsers zoals CSV parsing

## Integration tests

- API auth/login/logout.
- Dashboard met mocked GHL/Stripe/Wise.
- Supabase repositories.
- Storage upload/download met private bucket.
- Job queue retries.
- Webhook inbox idempotency.

## End-to-end tests

Minimaal:

- login/logout;
- setter dashboard;
- manager dashboard;
- taalwissel;
- sales callreview;
- factuurupload;
- invoice extraction;
- transaction matching;
- review approve/change/ignore;
- projectstatus;
- permissions voor setter/closer/admin;
- mobiele viewport.

## Contract tests

Per integratie:

- GHL response shapes;
- Stripe invoices/subscriptions/webhooks;
- Wise profile/balance/statement/CSV;
- ClickUp tasks;
- Read AI transcripts;
- ElevenLabs usage;
- Telnyx CDR/messages/usage.

## Data quality tests

- dubbele external IDs;
- ontbrekende customer domains;
- stale syncs;
- ongeldige bedragen/valuta;
- unmatched customers;
- factuurstatus mismatch;
- GHL assignee zonder interne user;
- dashboardtellingen versus analytics views.

## Eerste testkeuze

Gebruik eerst Node test runner of Vitest. Omdat de huidige app geen dependencies heeft, kan `node:test` snel waarde geven zonder frameworkmigratie. Zodra TypeScript/Next.js wordt ingevoerd, kan Vitest + Playwright worden toegevoegd.

