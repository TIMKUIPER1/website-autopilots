# Backlog

Prioriteit: P0 blokkeert veilig gebruik, P1 fundament, P2 hoge bedrijfswaarde, P3 optimalisatie, P4 toekomst.

## Eerste tien tickets

1. **OS-001 - Productie-safe auth baseline**
   - Probleem: plaintext/dev wachtwoorden en in-memory sessies.
   - Uitkomst: authmigratieplan + tijdelijke hardening.
   - Acceptance: geen fallback login in productie, login rate limit, tests.
   - Prioriteit: P0. Complexiteit: M.

2. **OS-002 - Test harness voor bestaande kernlogica**
   - Probleem: finance en rolfiltering ongetest.
   - Uitkomst: unit tests voor `filterForRole`, cashflow, matching, Stripe forecast.
   - Acceptance: `npm test` draait lokaal.
   - Prioriteit: P0. Complexiteit: S.

3. **OS-003 - Productie-safe errorhandler**
   - Probleem: `detail: error.message` kan intern detail lekken.
   - Uitkomst: veilige publieke errors en interne logging.
   - Acceptance: 500 response toont geen intern detail in productie.
   - Prioriteit: P0. Complexiteit: S.

4. **OS-004 - Auditlog voor financeacties**
   - Probleem: upload/download/match/sync niet gelogd.
   - Uitkomst: audit event service.
   - Acceptance: elke financeactie schrijft actor, actie, entity, timestamp.
   - Prioriteit: P0. Complexiteit: M.

5. **OS-005 - Data backup en importplan**
   - Probleem: lokale JSON is enige runtime state.
   - Uitkomst: backupscript + importmapping.
   - Acceptance: backup van `data/` met manifest en checksum.
   - Prioriteit: P0. Complexiteit: S.

6. **OS-006 - Supabase migrations runner**
   - Probleem: schema bestaat zonder migratieproces.
   - Uitkomst: migrationsmap en apply workflow.
   - Acceptance: local/staging/prod migrations reproduceerbaar.
   - Prioriteit: P1. Complexiteit: M.

7. **OS-007 - Integration health model**
   - Probleem: health is alleen booleans.
   - Uitkomst: DB-backed sync status per integratie.
   - Acceptance: status, last_success, last_error, freshness zichtbaar.
   - Prioriteit: P1. Complexiteit: M.

8. **OS-008 - Stripe raw/core sync naar DB**
   - Probleem: Stripe schrijft JSON.
   - Uitkomst: invoices/subscriptions in raw + core DB.
   - Acceptance: tellingen matchen huidige JSON-sync.
   - Prioriteit: P1. Complexiteit: M.

9. **OS-009 - Private document storage**
   - Probleem: facturen staan lokaal.
   - Uitkomst: private bucket + signed download.
   - Acceptance: upload/download werkt zonder lokale file reliance.
   - Prioriteit: P1. Complexiteit: M.

10. **OS-010 - Finance review inbox persistent**
   - Probleem: matches/decisions lokaal en beperkt.
   - Uitkomst: review_items + payment_allocations in DB.
   - Acceptance: approve/change/ignore persisted en audited.
   - Prioriteit: P1. Complexiteit: M.

## Overige tickets

11. **OS-011 - GHL raw/staging sync naar DB** P1 M.
12. **OS-012 - External identity mapping service** P1 M.
13. **OS-013 - Users/roles uit database** P1 M.
14. **OS-014 - Permission middleware** P1 M.
15. **OS-015 - RLS policies voor gevoelige tabellen** P1 L.
16. **OS-016 - Wise CSV import naar DB** P1 M.
17. **OS-017 - Wise statement API retry/fallback** P2 M.
18. **OS-018 - Customer 360 basispagina** P2 M.
19. **OS-019 - Customer domain matching** P2 M.
20. **OS-020 - Sales KPI analytics views** P2 M.
21. **OS-021 - Setter persoonlijke portal** P2 M.
22. **OS-022 - Closer persoonlijke portal** P2 M.
23. **OS-023 - Sales manager dashboard** P2 M.
24. **OS-024 - ClickUp read-only sync** P2 M.
25. **OS-025 - Closed-won handoff model** P2 M.
26. **OS-026 - Project risk dashboard** P2 M.
27. **OS-027 - Training datamodel migrations** P2 M.
28. **OS-028 - Training lesson/progress UI** P3 M.
29. **OS-029 - AI coaching recommendation service** P3 L.
30. **OS-030 - Read AI transcript adapter** P3 M.
31. **OS-031 - Gmail invoice ingest adapter** P2 L.
32. **OS-032 - Google Drive customer folder adapter** P3 M.
33. **OS-033 - ElevenLabs usage adapter** P2 M.
34. **OS-034 - Telnyx usage adapter** P2 M.
35. **OS-035 - Usage margin alerts** P2 M.
36. **OS-036 - i18n extraction naar translation files** P2 S.
37. **OS-037 - Mobile/responsive Playwright tests** P2 S.
38. **OS-038 - Security headers/CSP** P1 S.
39. **OS-039 - Structured logging** P1 S.
40. **OS-040 - Job queue and worker skeleton** P1 M.

