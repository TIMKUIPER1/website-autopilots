# Implementation Roadmap

## Now

### 1. Stabiliseer het prototype

- Bedrijfswaarde: veilig doorbouwen zonder dat data of toegang onbetrouwbaar is.
- Technische waarde: tests, auth, errorhandling, audit.
- Definition of done: login veilig, tests draaien, financeacties gelogd, data backup.
- Meetbaar resultaat: P0 securityrisico's gemitigeerd.

### 2. Maak Supabase de centrale opslag

- Bedrijfswaarde: dashboards worden betrouwbaar.
- Technische waarde: weg van lokale JSON.
- Definition of done: GHL/Stripe/imports raw + core records in DB.
- Meetbaar resultaat: dashboard kan vanaf DB lezen.

### 3. Finance foundation

- Bedrijfswaarde: cashflow, facturen en matching worden bruikbaar.
- Technische waarde: storage, invoices, transactions, review_items.
- Definition of done: uploads naar private storage, Stripe invoices in DB, Wise CSV/API in DB, review inbox persisted.

## Next

### 4. Customer 360

- Klantdossier met contacts, documents, invoices, projects, usage en timeline.

### 5. Sales betrouwbaarheid

- GHL core sync, sales KPI analytics, role portals.

### 6. ClickUp delivery sync

- Delivery dashboard met echte taken, milestones, blockers en handoff.

### 7. Training Academy

- Lessons, progress, callreview assignments en AI recommendations.

## Later

### 8. Usage provider sync

- ElevenLabs/Telnyx live usage per AI medewerker/klant.

### 9. Marketing en social analytics

- Social dashboards en AI marketing agent.

### 10. Accounting export en period close

- Export naar accountant/boekhoudpakket na expliciete boekhoudvereisten.

