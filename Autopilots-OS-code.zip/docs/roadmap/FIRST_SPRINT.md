# First Sprint - Stabilisatie en betrouwbaar fundament

## Sprintdoel

Maak het bestaande Autopilots OS veilig genoeg om gecontroleerd door te ontwikkelen. Geen nieuwe dashboardfeatures. Focus op authrisico, tests, auditability, data backup en integratie-health.

## Status 2026-07-20

Gestart en deels uitgevoerd:

- OS-002 test harness: eerste 5 unit tests toegevoegd.
- OS-003 safe errorhandler: uitgevoerd.
- OS-004 auditlog financeacties: lokale auditlog uitgevoerd als tijdelijke stap.
- OS-005 data backup script: uitgevoerd.
- OS-006 migrations runner: migratiebestand aangemaakt; runner/proces nog open.
- OS-007 integration health: lokale health opslag gestart.
- OS-038 security headers/CSP: uitgevoerd.
- Supabase mirror layer: gestart voor auditlog, integration health en Stripe raw/core sync.

Nog open:

- OS-001 volledige authmigratie naar productiebasis.
- Correcte `SUPABASE_SERVICE_ROLE_KEY` invullen.
- Migraties toepassen in remote Supabase.
- OS-006 automatische migrations runner/proces.
- OS-039 structured logging uitbreiden.
- OS-040 worker skeleton.
- Auditlog en integration health naar database migreren.

## Tickets

### OS-001 Productie-safe auth baseline

- Reden: plaintext/dev wachtwoorden en in-memory sessies zijn P0.
- Bestanden: `server.js`, `config.js`, `.env.example`.
- Resultaat: geen fallbackwachtwoorden in productie, rate limiting, duidelijk authmigratiepad.
- Acceptatie: productie zonder expliciete password env weigert login/config.
- Test: login success/fail/rate-limit.

### OS-002 Test harness

- Reden: kritieke berekeningen zijn ongetest.
- Bestanden: `server.js`, nieuwe testbestanden.
- Resultaat: tests voor finance, role filtering, forecast.
- Acceptatie: `npm test` groen.
- Test: unit tests.

### OS-003 Safe errorhandler

- Reden: interne details kunnen lekken.
- Bestanden: `server.js`.
- Resultaat: productie toont generieke fout, intern logt detail.
- Acceptatie: geforceerde 500 toont geen stack/detail.
- Test: endpoint met fout mocken.

### OS-004 Auditlog financeacties

- Reden: finance downloads en beslissingen moeten traceerbaar zijn.
- Bestanden: `server.js`, `supabase/schema.sql` later repository.
- Resultaat: actor/action/entity/timestamp gelogd.
- Acceptatie: upload/download/match/sync schrijft audit event.
- Test: integratietest.

### OS-005 Data backup script

- Reden: lokale JSON is runtime state.
- Bestanden: nieuw script.
- Resultaat: backup met manifest/checksums.
- Acceptatie: restorebaar backupbestand.
- Test: backup draaien en manifest valideren.

### OS-006 Migration skeleton

- Reden: schema is los SQL-bestand.
- Bestanden: `supabase/migrations`.
- Resultaat: reproduceerbare DB wijzigingen.
- Acceptatie: fresh DB kan schema krijgen.
- Test: migration dry run.

### OS-007 Integration health

- Reden: integraties moeten betrouwbaarheid tonen.
- Bestanden: `server.js`, schema.
- Resultaat: status per integratie met freshness.
- Acceptatie: dashboard toont live/stale/error/demo.
- Test: health unit/integration.

### OS-038 Security headers/CSP

- Reden: static server heeft geen headers.
- Bestanden: `server.js`.
- Resultaat: basis headers.
- Acceptatie: responses hebben CSP/frame/options.
- Test: curl header check.

### OS-039 Structured logging

- Reden: console logs zijn onvoldoende.
- Bestanden: logging utility.
- Resultaat: JSON logs met request ID.
- Acceptatie: errors en syncs bevatten correlation ID.
- Test: log snapshot.

### OS-040 Worker skeleton

- Reden: syncs draaien nu in request.
- Bestanden: nieuwe jobs module.
- Resultaat: voorbereid voor background sync.
- Acceptatie: job interface en mock worker test.
- Test: unit test retry policy.
