# Implementation Log

## 2026-07-20 - Fase 0 hardening gestart

Uitgevoerd:

- Productie-safe errorhandler toegevoegd: interne foutdetails worden alleen buiten productie teruggegeven.
- Security headers toegevoegd aan JSON, HTML/static responses en factuurdownloads.
- Login rate limiting toegevoegd met standaard 8 pogingen per 15 minuten per IP/e-mailcombinatie.
- Lokale auditlog toegevoegd voor login, logout, finance upload/download, finance matching en integratie-syncs.
- Integration health opslag toegevoegd voor syncstatussen.
- Server testvriendelijk gemaakt met `require.main === module` en testexports.
- Testscript toegevoegd met `node --test`.
- Eerste unit tests toegevoegd voor security headers, rolfiltering, cashflow forecast, Stripe fallback en finance matching.
- Backupscript toegevoegd voor lokale `data/` met manifest en SHA-256 checksums.
- `backups/` toegevoegd aan `.gitignore`.
- `.env.example` uitgebreid met `LOGIN_MAX_ATTEMPTS` en `DEBUG_TOKEN`.
- Supabase migrations skeleton toegevoegd op basis van het bestaande schema.

Verificatie:

- `node --check server.js`: geslaagd.
- `node --test`: 5 tests, 5 geslaagd.
- Backupscript uitgevoerd: 4 databestanden vastgelegd.
- Smoke test lokaal:
  - `/` bevat security headers.
  - `/health` werkt.
  - admin login werkt.
  - `/api/me` werkt.
  - mislukte loginpogingen geven na 8 pogingen 429.
  - usage sync vult integration health met demo-status.

Niet gedaan in deze stap:

- Geen Supabase Auth migratie.
- Geen database runtime migratie.
- Geen automatische migratierunner naar remote Supabase.
- Geen private object storage.
- Geen Next.js/TypeScript rewrite.
- Geen externe live syncs voor ElevenLabs/Telnyx/ClickUp/Read AI/Google.

## 2026-07-20 - Fase 1 Supabase mirror layer gestart

Uitgevoerd:

- Supabase REST mirrorlaag toegevoegd met lokale JSON fallback.
- Auditlog schrijft lokaal en spiegelt naar `audit_log` wanneer Supabase service role beschikbaar is.
- Integration health schrijft lokaal en spiegelt naar `integration_health` wanneer beschikbaar.
- Stripe-sync spiegelt raw Stripe invoices/subscriptions naar `raw_imports`.
- Stripe-sync spiegelt genormaliseerde facturen/upcoming subscriptions naar `invoices_sales`.
- `integration_health` tabel toegevoegd aan `supabase/schema.sql`.
- Extra migratie toegevoegd: `supabase/migrations/20260720001000_add_integration_health.sql`.
- Supabase checkscript toegevoegd: `npm run check:supabase`.
- Extra tests toegevoegd voor JSON parsing en Supabase-config helper.
- `/health` gebruikt nu dezelfde Supabase writable-check als de runtime mirrorlaag, zodat placeholders niet als schrijfbaar worden getoond.

Verificatie:

- `node --check server.js`: geslaagd.
- `node --test`: 7 tests, 7 geslaagd.
- `npm run check:supabase`: geblokkeerd doordat `SUPABASE_SERVICE_ROLE_KEY` in `.env` nog ontbreekt of placeholder is.

Belangrijk:

- De app blijft werken via lokale fallback.
- Supabase runtime mirror wordt automatisch actief zodra `SUPABASE_SERVICE_ROLE_KEY` correct is ingevuld en de migraties in Supabase zijn toegepast.
