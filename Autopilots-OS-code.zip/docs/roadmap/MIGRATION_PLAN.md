# Migration Plan - Geen Big-Bang Rewrite

## Strategie

Gebruik een strangler-aanpak: huidige app blijft lokaal bruikbaar terwijl nieuwe modules achter feature flags en parallelle data-validatie worden opgebouwd.

## Fase 0 - Stabilisatie

- Secrets en `.gitignore` controleren.
- Standaardwachtwoorden/productierisico verwijderen.
- Rate limiting.
- Productie-safe errorhandler.
- Auditlog voor finance/downloads/syncs.
- Tests rond kernlogica.
- Data backup van `data/`.

## Fase 1 - Platformfundament

- TypeScript projectstructuur.
- Auth provider.
- Users, teams, roles, permissions.
- i18n basis.
- Databaseclient.
- Migrations.
- Auditlog.
- App shell/navigatie.

## Fase 2 - Centrale klantdata

- Companies, contacts, domains.
- External identity mapping.
- GHL en Stripe customer mapping.
- Customer timeline.
- Parallel met huidige klantkaart vergelijken.

## Fase 3 - Sales migreren

- GHL raw/staging/core sync.
- Calls/transcripts.
- KPI analytics views.
- Setter/closer dashboards.
- Managerweergave.
- Parallelle validatie met bestaande dashboard.

## Fase 4 - Training

- Academy datamodel.
- Lessons/progress.
- Competencies.
- AI recommendations vanuit call scores.
- Manager reviews.

## Fase 5 - Delivery en projecten

- ClickUp sync.
- Project/milestone/task overview.
- Closed-won handoff.
- Risks/blockers/capacity.

## Fase 6 - Finance foundation

- Suppliers.
- Purchase invoices.
- Sales invoices.
- Storage.
- Gmail ingest.
- Stripe webhooks.
- Wise transaction normalization.
- Review inbox.

## Fase 7 - Reconciliatie

- Matching engine in services.
- Allocations.
- Partial payments.
- Credit notes.
- Correction rules.
- Period review.
- Accounting export.

## Fase 8 - Management cockpit

- Reliable KPIs.
- Alerts.
- Forecasts.
- Weekly brief.
- Decision log.

## Fase 9 - Hardening

- Performance.
- Security review.
- Observability.
- Backup/restore.
- Production acceptance.

