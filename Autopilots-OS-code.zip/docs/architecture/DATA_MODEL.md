# Data Model - Autopilots OS

## Principes

Dashboards mogen niet direct afhankelijk zijn van externe API-responses. Gebruik lagen:

1. **Raw**: exacte externe payload.
2. **Staging**: genormaliseerde bronrecords.
3. **Core**: Autopilots bedrijfsentiteiten.
4. **Analytics**: views/aggregates voor dashboards.

## Algemene velden

Gebruik waar relevant:

- `id`
- `organization_id`
- `source_system`
- `source_id`
- `source_account_id`
- `created_at`
- `updated_at`
- `deleted_at`
- `synced_at`
- `created_by`
- `updated_by`
- `raw_payload`
- `metadata`
- `version`

Niet ieder record heeft ieder veld nodig. Transactionele records zoals banktransacties krijgen `source_id`, `raw_payload`, `synced_at` en idempotency metadata. Handmatige core records krijgen `created_by`, `updated_by` en auditlog.

## ERD

```mermaid
erDiagram
  organizations ||--o{ users : has
  organizations ||--o{ integration_accounts : owns
  organizations ||--o{ companies : owns
  users ||--o{ audit_logs : writes
  users ||--o{ sales_calls : owns
  companies ||--o{ contacts : has
  companies ||--o{ customer_domains : has
  companies ||--o{ customer_external_identities : maps
  companies ||--o{ documents : stores
  companies ||--o{ projects : has
  companies ||--o{ sales_invoices : receives
  companies ||--o{ purchase_invoices : allocated_to
  companies ||--o{ usage_records : consumes
  contacts ||--o{ opportunities : linked_to
  opportunities ||--o{ sales_calls : has
  sales_calls ||--o{ transcripts : has
  sales_calls ||--o{ ai_scores : scored_by
  training_programs ||--o{ training_modules : contains
  training_modules ||--o{ training_lessons : contains
  users ||--o{ training_enrollments : enrolled
  training_lessons ||--o{ lesson_progress : tracked
  users ||--o{ coaching_recommendations : receives
  projects ||--o{ milestones : has
  milestones ||--o{ tasks : has
  purchase_invoices ||--o{ payment_allocations : matched_by
  bank_transactions ||--o{ payment_allocations : allocated_to
  integration_accounts ||--o{ sync_runs : runs
  sync_runs ||--o{ raw_imports : imports
  raw_imports ||--o{ staging_records : normalizes
  review_items ||--o{ audit_logs : resolves
```

## Kern-tabellen

### Platform

- `organizations`
- `users`
- `teams`
- `roles`
- `permissions`
- `user_roles`
- `role_permissions`
- `settings`
- `feature_flags`
- `notifications`
- `audit_logs`
- `idempotency_keys`

### Integraties

- `integration_accounts`
- `sync_runs`
- `sync_cursors`
- `raw_imports`
- `webhook_inbox`
- `failed_jobs`
- `external_identities`

### Customer 360

- `companies`
- `contacts`
- `customer_domains`
- `customer_external_identities`
- `customer_timeline_events`
- `contracts`
- `documents`
- `meetings`
- `customer_health_scores`

### Sales

- `leads`
- `opportunities`
- `pipelines`
- `pipeline_stages`
- `activities`
- `sales_calls`
- `transcripts`
- `call_scores`
- `lost_reasons`
- `no_show_events`
- `sales_goals`
- `commissions`

### Training

- `training_programs`
- `training_modules`
- `training_lessons`
- `training_content`
- `quizzes`
- `quiz_questions`
- `assignments`
- `submissions`
- `training_enrollments`
- `lesson_progress`
- `competencies`
- `user_competency_scores`
- `certifications`
- `coaching_recommendations`
- `manager_reviews`

### Projectmanagement

- `departments`
- `programs`
- `projects`
- `workstreams`
- `milestones`
- `tasks`
- `task_dependencies`
- `task_comments`
- `project_files`
- `project_risks`
- `change_requests`
- `capacity_allocations`

### Finance

- `suppliers`
- `supplier_aliases`
- `purchase_invoices`
- `sales_invoices`
- `bank_accounts`
- `bank_transactions`
- `payment_allocations`
- `credit_notes`
- `subscriptions`
- `cost_categories`
- `cost_centers`
- `client_allocations`
- `usage_records`
- `approval_flows`
- `review_items`
- `accounting_exports`
- `period_closes`

## Externe IDs

Gebruik een generieke mapping:

```sql
entity_type
internal_entity_id
source_system
source_account_id
external_id
external_parent_id
last_seen_at
metadata
```

Zo hoeft `companies` niet steeds nieuwe kolommen te krijgen voor elke integratie.

## Huidig schema

`supabase/schema.sql` bevat al een eerste richting voor:

- sales team members;
- sessions;
- GHL opportunity events;
- sales calls/transcripts/scores;
- companies;
- customer domains;
- contacts;
- integration accounts;
- sync runs;
- raw imports;
- documents;
- sales/purchase invoices;
- review items;
- audit log.

Maar runtime gebruikt dit schema nog niet. De migratie moet dus eerst opslag- en repositorylagen bouwen voordat dashboards hierop vertrouwen.

## Migratie bestaande data

Bronnen:

- `data/ghl-live-data.json`
- `data/stripe-invoices.json`
- `data/wise-transactions.json`
- `data/finance-matches.json`
- `data/ai-usage-costs.json`
- `data/invoice-uploads/index.json`
- `config.js` teamleden
- bestaande Supabase-tabellen

Plan:

1. Maak backup van `data/`.
2. Import raw payloads naar `raw_imports`.
3. Normaliseer GHL/Stripe/Wise/usage naar staging.
4. Bouw external identity mappings.
5. Upsert companies/contacts/invoices/transactions.
6. Valideer tellingen tegen oude dashboardoutput.
7. Laat dashboard tijdelijk parallel oude en nieuwe bron vergelijken.
8. Zet module per module over.
9. Archiveer oude JSON na acceptatie, niet verwijderen.

