# Integrations Architecture

## Huidige integraties

| Integratie | Huidige status | Bewijs | Credentials | Source of truth | Opmerking |
| --- | --- | --- | --- | --- | --- |
| GoHighLevel | PARTIAL/LIVE | `/api/dashboard`, `/api/debug/live-data` | aanwezig | GHL | 2500 opportunities/conversations/contacts via cache; mappings hard-coded. |
| Stripe | PARTIAL/LIVE | `/api/integrations/stripe/sync` | aanwezig | Stripe | 53 facturen en 4 upcoming subscriptions getest. |
| Wise | PARTIAL/BLOCKED | profiles endpoint getest | aanwezig | Wise/CSV | Profielen werken; transactions via statements kunnen blokkeren; CSV fallback. |
| Supabase | PLANNED/PARTIAL | env + schema | aanwezig | toekomstige core DB | Runtime gebruikt Supabase nog niet. |
| ElevenLabs | PLANNED | usage sync toont token ontbreekt | ontbreekt | ElevenLabs | Nu demo model. |
| Telnyx | PLANNED | usage sync toont token ontbreekt | ontbreekt | Telnyx | Nu demo model. |
| ClickUp | PLANNED | geen backendroute | ontbreekt/app plugin | ClickUp | Eerst als project source of truth behouden. |
| Gmail/Google Workspace | PLANNED | geen backendroute | plugin aanwezig, app creds ontbreken | Gmail/Drive | Plugin is genoeg voor assisted werk, niet voor autonome backend sync. |
| Read AI | PLANNED | geen backendroute | ontbreekt | Read AI | Nodig voor transcripties/meetings. |
| Marketingplatformen | PLANNED | geen backendroute | ontbreekt | platforms | LinkedIn/Meta/TikTok/Youtube later. |
| LLM-providers | PLANNED | geen key/routes | ontbreekt | LLM | AI-score is nu heuristiek. |

## Adapterpatroon

Elke integratie krijgt:

- `healthCheck()`
- `fetchChanges(cursor)`
- `fetchById(id)`
- `normalize(raw)`
- `upsertRaw(payload)`
- `upsertCore(stagingRecord)`
- `handleWebhook(event)`
- `refreshToken()` waar nodig
- `rateLimitPolicy`
- `retryPolicy`

## GoHighLevel

Doel:

- salesdata, contacts, conversations, pipelines, users, calendars, call logs, afspraken.

Nodig:

- incremental sync cursors;
- webhook inbox waar beschikbaar;
- stable mapping van GHL users naar interne users;
- pipeline/stage configuratie uit database in plaats van `config.js`;
- datakwaliteitstests voor owner mapping.

Foutscenario's:

- 429 rate limit;
- ontbrekende scopes;
- incomplete pagination;
- mismatch tussen configured team en observed assignees.

## Stripe

Doel:

- sales invoices, subscriptions, payments, customer mapping, forecast.

Aanbevolen rechten:

- restricted read key voor customers, invoices, subscriptions, products/prices, payment intents/charges, balance transactions.

Nodig:

- webhooks voor invoice paid/created/updated;
- idempotency op event ID;
- raw payloads;
- customer identity mapping;
- payout/balance transaction later voor cash realiteit.

## Wise

Doel:

- business/personal transacties, balans, bankreconciliatie.

Nodig:

- profile mapping business/personal;
- statement permission fix of CSV fallback;
- transaction normalization;
- duplicate detection;
- source account metadata.

## Google Workspace

Doel:

- inkomende facturen via Gmail;
- klantmappen/documenten via Drive;
- attachments opslaan in private storage.

Plugin versus backend:

- Plugin is genoeg voor assisted work in Codex.
- Backend automation heeft OAuth/client credentials, scopes en scheduled sync nodig.

## ClickUp

Aanbevolen voorlopig: ClickUp blijft leidend.

Autopilots OS synchroniseert:

- spaces/folders/lists/tasks;
- status/milestones;
- assignees;
- due dates;
- blockers;
- deep links.

Write pas toevoegen als statusupdates vanuit OS noodzakelijk zijn.

## Read AI

Doel:

- meeting transcripts, summaries, action items, customer timeline.

Nodig:

- API/toegang verifiëren;
- mapping op attendee domain/customer;
- document privacybeleid;
- transcript permissions.

## ElevenLabs en Telnyx

Doel:

- usagekosten per AI medewerker/klant.

Nodig:

- API keys;
- mapping van agent/voice/number/message profile naar customer;
- monthly usage sync;
- cost normalization;
- margin alerts.

## Dataretentie en privacy

Elke integratie moet vastleggen:

- persoonsgegevens;
- bewaartermijn;
- deletion flow;
- legal basis;
- source account;
- last synced;
- error state.

