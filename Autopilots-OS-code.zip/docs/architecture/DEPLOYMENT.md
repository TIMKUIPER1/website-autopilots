# Deployment & Environments

## Huidige situatie

- Railway config aanwezig:
  - `builder = "NIXPACKS"`
  - start command `node server.js`
  - healthcheck `/health`
- Geen gescheiden environments zichtbaar in repo.
- `.env` lokaal aanwezig en genegeerd.
- Lokale data onder `data/` wordt gebruikt als runtime state.

## Gewenste omgevingen

| Omgeving | Doel | Data | Secrets | Deploy |
| --- | --- | --- | --- | --- |
| Local | ontwikkeling | lokale testdata | lokale `.env` | lokale Node/Next |
| Development | gedeelde dev | test Supabase | dev secrets | preview/develop branch |
| Staging | acceptatie | productieachtige testdata | staging secrets | protected deploy |
| Production | intern live | productie Supabase | prod secrets | protected main deploy |

## Railway geschiktheid

Railway kan geschikt blijven voor:

- webapp;
- API;
- worker;
- Redis;
- scheduled jobs.

Voorwaarden:

- geen lokale file storage in productie;
- persistent DB buiten container;
- Redis/job monitoring;
- secrets per environment;
- backups en restoretest.

## Vereist productiefundament

- Database migrations.
- Seeddata per environment.
- Gescheiden webhooks per omgeving.
- Feature flags.
- Health endpoint voor app.
- Job health endpoint.
- Integration health dashboard.
- Structured logs.
- Error monitoring.
- Uptime monitoring.
- Database backups.
- Restoretest.
- Rollback plan.

## Actuele Supabase blokkade

Op 2026-07-20 is een runtime mirrorlaag gebouwd, maar de remote Supabase-check is nog niet groen omdat `SUPABASE_SERVICE_ROLE_KEY` lokaal ontbreekt of nog placeholder is. Zodra de juiste service role key beschikbaar is, moeten de migraties in `supabase/migrations/` worden toegepast en daarna kan `npm run check:supabase` bevestigen dat `audit_log`, `integration_health`, `raw_imports` en `invoices_sales` bereikbaar zijn.

## Releaseflow

1. Pull request.
2. Tests en lint.
3. Preview deploy.
4. Staging deploy.
5. Smoke tests.
6. Productie deploy.
7. Post-deploy health check.
8. Monitoring window.
