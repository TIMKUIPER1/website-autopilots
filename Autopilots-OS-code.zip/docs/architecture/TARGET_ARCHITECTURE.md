# Target Architecture - Autopilots OS

## Architectuurkeuze

Aanbevolen richting: **modulaire monoliet**.

Waarom:

- Het team heeft nu één kleine Node-app zonder dependencies. Direct microservices introduceren zou operationele complexiteit toevoegen zonder bewezen schaalnoodzaak.
- De domeinen zijn sterk gekoppeld: klant, sales, finance, delivery, usage en documenten moeten samen in Customer 360 komen.
- Een modulaire monoliet kan duidelijke modulegrenzen, typed contracts, database transacties en centrale autorisatie leveren zonder distributed system overhead.
- Modules kunnen later worden afgesplitst wanneer load, team ownership of compliance dat rechtvaardigt.

## Aanbevolen stack

### Webapp

- Next.js met TypeScript.
- React voor dashboards en formulieren.
- Server components waar data server-side moet blijven.
- Client components voor filters, tabellen, uploads en interactieve dashboards.
- Route-based modules:
  - `/ceo`
  - `/sales`
  - `/training`
  - `/customers`
  - `/finance`
  - `/delivery`
  - `/operations`
  - `/team`
  - `/integrations`
  - `/settings`
- Design system gebaseerd op de huidige Autopilots Style Stack.
- Centrale i18n-laag met JSON translation files en database-contentvertalingen waar nodig.

### Backend

Voorkeur: dezelfde Next.js-app met server routes/actions voor de eerste productiefase. Aparte Fastify/NestJS API pas overwegen als:

- sync/workers zoveel groeien dat web/API lifecycle apart moet;
- mobiele/externe clients typed public API nodig hebben;
- team ownership per service echt gescheiden wordt.

Structuur:

```text
src/
  app/
  modules/
    platform/
    customers/
    sales/
    training/
    finance/
    delivery/
    operations/
    integrations/
  server/
    auth/
    db/
    jobs/
    storage/
    logging/
    permissions/
  integrations/
    ghl/
    stripe/
    wise/
    clickup/
    google/
    read-ai/
    elevenlabs/
    telnyx/
```

Elke module krijgt:

- routes/UI;
- API handlers;
- services;
- repositories;
- validators;
- tests;
- permissions;
- audit events.

### Database

PostgreSQL via Supabase wordt centrale waarheid.

Eisen:

- migrations;
- foreign keys;
- unique constraints;
- indices;
- RLS;
- auditlog;
- raw/staging/core/analytics lagen;
- idempotency keys;
- sync cursors;
- `organization_id` voor toekomstige multi-tenant grenzen;
- timestamps en soft delete waar nodig.

### Auth

Aanbevolen: Supabase Auth, tenzij later een externe IdP expliciet beter blijkt.

Vereist:

- geen plaintext wachtwoorden;
- invite flow;
- password reset;
- e-mailverificatie;
- MFA voor directie/finance;
- persistent sessions;
- session revocation;
- secure cookies;
- server-side permission checks;
- database RLS.

### Jobs en synchronisatie

Aanbevolen:

- BullMQ + Redis op Railway of Supabase-compatible job alternatief.
- Scheduled jobs voor incremental sync.
- Webhook inbox voor Stripe/GHL/ClickUp/Google waar beschikbaar.
- Retry met exponential backoff.
- Dead-letter queue.
- Idempotency table.
- Sync cursors per integration account.
- Raw payload storage.
- Replay-mogelijkheid.

### Storage

Supabase Storage of vergelijkbare private object storage.

Vereist:

- private buckets;
- signed URLs;
- file hash;
- metadata in database;
- access logs;
- size/MIME policies;
- malware scan hook waar mogelijk;
- retention policy;
- versiebeheer voor documenten waar nodig.

### Observability

- Structured logs met correlation IDs.
- Error tracking.
- Job dashboard.
- Sync status per integratie.
- Data freshness per module.
- Auditlog voor gevoelige acties.
- Uptime checks.
- Alerts bij sync failures, stale data, security events.

## Mermaid - Systeemarchitectuur

```mermaid
flowchart LR
  User["Gebruiker"] --> Web["Next.js Webapp"]
  Web --> Auth["Supabase Auth"]
  Web --> API["Server/API Layer"]
  API --> Perm["Permission Service"]
  API --> DB[("PostgreSQL / Supabase")]
  API --> Storage["Private Object Storage"]
  API --> Queue["Job Queue"]
  Queue --> Worker["Sync Workers"]
  Worker --> GHL["GoHighLevel"]
  Worker --> Stripe["Stripe"]
  Worker --> Wise["Wise"]
  Worker --> ClickUp["ClickUp"]
  Worker --> Google["Google Workspace"]
  Worker --> ReadAI["Read AI"]
  Worker --> Eleven["ElevenLabs"]
  Worker --> Telnyx["Telnyx"]
  API --> Logs["Structured Logs"]
  Worker --> Logs
  Logs --> Monitor["Monitoring & Alerts"]
```

## Mermaid - Dataflow

```mermaid
flowchart TD
  External["External API/Webhook"] --> Raw["Raw import"]
  Raw --> Staging["Normalisatie / staging"]
  Staging --> Matching["Matching / identity resolution"]
  Matching --> Review["Review inbox"]
  Review --> Core["Core records"]
  Core --> Analytics["Reporting views"]
  Analytics --> Dashboard["Dashboards"]
```

## Mermaid - Financeflow

```mermaid
flowchart TD
  Source["Gmail / Upload / Supplier portal"] --> Storage["Private document storage"]
  Storage --> Extract["Extractie"]
  Extract --> Invoice["Leverancier + factuur"]
  Wise["Wise / Stripe bankfeeds"] --> Tx["Banktransacties"]
  Invoice --> Match["Matching engine"]
  Tx --> Match
  Match --> Review["Review inbox"]
  Review --> Allocation["Aflettering"]
  Allocation --> Export["Accounting export"]
```

## Mermaid - Salesflow

```mermaid
flowchart TD
  Lead["GHL lead"] --> Setter["Setter"]
  Setter --> Call["Call"]
  Call --> Transcript["Transcript"]
  Transcript --> Score["AI-score"]
  Score --> Training["Training recommendation"]
  Setter --> Closer["Closer"]
  Closer --> Deal["Deal"]
  Deal --> Handoff["Delivery handoff"]
```

## Mermaid - Projectflow

```mermaid
flowchart TD
  Won["Closed won"] --> Template["Projecttemplate"]
  Template --> Intake["Intake"]
  Intake --> Milestones["Milestones"]
  Milestones --> Tasks["Taken"]
  Tasks --> Test["Testfase"]
  Test --> Live["Livegang"]
  Live --> Aftercare["Nazorg"]
```

## Modulegrenzen

### Platform

Organisaties, users, rollen, permissions, instellingen, talen, notificaties, auditlogs, feature flags, integraties, system health.

### Customer 360

Companies, contacts, domains, external identities, contracts, subscriptions, communication, documents, meetings, tasks, invoices, payments, usage, projects, health, timeline.

### Sales

Leads, opportunities, pipelines, activities, calls, meetings, transcripts, outcomes, no-shows, lost reasons, attribution, commissions, goals, scorecards, forecasts.

### Training Academy

Programs, modules, lessons, quizzes, assignments, certifications, competencies, progress, manager reviews, coaching recommendations.

### Projectmanagement

ClickUp blijft voorlopig leidend. Autopilots OS toont status, milestones, risico, capaciteit, klantkoppeling en handoff. Een interne projectmodule komt pas wanneer ClickUp structureel tekortschiet.

### Finance

Operationele finance, factuurverwerking, bankreconciliatie, managementrapportage en accounting export. Niet positioneren als volledig boekhoudpakket zonder expliciete accountancyvereisten.

## Wanneer later afsplitsen

Alleen afsplitsen naar aparte services bij:

- zware sync workloads;
- compliance-isolatie voor finance/documenten;
- aparte externe API voor klanten;
- team ownership met aparte releasecyclus;
- aantoonbare performance bottleneck.

