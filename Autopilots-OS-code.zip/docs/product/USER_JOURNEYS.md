# User Journeys

## Setter

Login -> persoonlijke dagstart -> bellijst -> call -> resultaat -> persoonlijke score -> aanbevolen training -> follow-up.

Huidige ondersteuning:

- Login en persoonlijk gefilterd dashboard werken.
- Calls worden gefilterd op owner.
- AI-score is heuristisch.

Gat:

- Geen bellijst, follow-upflow, trainingtoewijzing of commissie.

## Closer

Login -> meetings -> dealcontext -> transcript -> offerte -> follow-up -> won/lost -> overdracht.

Huidige ondersteuning:

- Closerrol bestaat.
- Closer dashboard en KPI-tabel bestaan.

Gat:

- Geen offerteflow, dealcontext, delivery handoff of echte meeting journey.

## Salesmanager

Teamoverzicht -> afwijking ontdekken -> call bekijken -> coaching geven -> training toewijzen -> voortgang volgen.

Huidige ondersteuning:

- Admin ziet teamdata en callscore.

Gat:

- Geen salesmanagerrol, geen coaching/feedback, geen training assignments.

## Projectmanager

Nieuwe closed-won -> projecttemplate -> scope controleren -> team toewijzen -> milestones -> risico's -> klantupdate -> livegang.

Huidige ondersteuning:

- Delivery demo-milestones.

Gat:

- Geen ClickUp sync, projecttemplates, scope/handoff of updates.

## Finance

Factuur ontvangen -> extractie -> controle -> transactie gevonden -> match beoordelen -> afletteren -> exporteren.

Huidige ondersteuning:

- Handmatige upload.
- Stripe invoices.
- Wise profiles en CSV/API feedvoorbereiding.
- Matchingvoorstellen lokaal.

Gat:

- Geen OCR/extractie, private storage, echte allocations, export of period close.

## Directie

Login -> acht kerncijfers -> top risico's -> top kansen -> drill-down -> bronrecord -> actie toewijzen.

Huidige ondersteuning:

- CEO cards en risico's bestaan.

Gat:

- KPI's deels demo, geen bronrecorddrilldown, geen action assignment.

## UX-oordeel

Het bestaande design ondersteunt losse dashboardkaarten goed, maar nog geen volledige taakgerichte journeys. De volgende UX-stap is per rol een startscherm met acties, alerts, bronstatus en duidelijke vervolgstap.

