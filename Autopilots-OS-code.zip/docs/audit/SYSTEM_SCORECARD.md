# System Scorecard - Autopilots OS

Score: 0 = afwezig, 5 = productiewaardig.

| Onderdeel | Score | Onderbouwing | Grootste risico | Eerstvolgende actie |
| --- | ---: | --- | --- | --- |
| Functionele volledigheid | 2 | Login, dashboards, GHL, Stripe, uploads werken deels; training/projecten/marketing grotendeels demo. | Visueel compleet lijkt functioneel compleet. | Statuslabels in UI en brondata per kaart tonen. |
| Databetrouwbaarheid | 2 | GHL en Stripe deels live; CEO/finance/team/delivery mengen demo, cache en lokaal. | Management neemt besluiten op demo/fallbackdata. | Raw/staging/core/analytics datalagen invoeren. |
| Security | 1 | Plaintext wachtwoorden, in-memory sessies, lokale uploads, geen rate limiting. | Ongeautoriseerde toegang of datalek bij productie. | Auth vervangen/stabiliseren en rate limiting toevoegen. |
| Autorisatie | 2 | Admin checks voor finance-endpoints; setterdashboard server-side gefilterd. | Rollen te grof en niet database-side enforced. | RBAC matrix en permission middleware. |
| Onderhoudbaarheid | 1 | Grote monolietbestanden zonder tests of modules. | Elke wijziging kan regressies veroorzaken. | Domeinmodules en tests rond bestaande functies. |
| Schaalbaarheid | 1 | Syncs lopen in request/response, lokale JSON, 15 MB cache. | Timeouts/rate limits bij groei. | Background jobs met sync cursors. |
| Testdekking | 0 | Geen testscript, geen testfiles in `sales-dashboard`. | Kritieke financeberekeningen ongetest. | Node test runner/Vitest toevoegen voor pure functies. |
| Foutafhandeling | 2 | `safeFetch` voor GHL, basis JSON-errors; globale catch lekt `detail`. | Productie kan exceptiondetails tonen. | Centrale errorhandler zonder intern detail voor users. |
| Observability | 1 | `/health` en console.warn; geen structured logs/job monitoring. | Syncfouten blijven onzichtbaar. | Structured logs, sync_runs, integration health. |
| UX | 3 | Rustige app shell, submenu's, finance filters, duidelijke cards. | Demo/live status niet overal duidelijk genoeg. | Data freshness/source badges per module. |
| Responsive gedrag | 2 | CSS media queries aanwezig; niet systematisch getest. | Tabellen/cards kunnen mobiel slecht werken. | Playwright responsive smoke tests. |
| Toegankelijkheid | 2 | Labels en buttons deels aanwezig; geen audit. | Keyboard/screenreader issues. | Axe/ARIA audit op kernflows. |
| Documentatie | 2 | README en deze audit; runtimearchitectuur nog niet eerder compleet. | Kennis zit in code/chat. | Docs als onderhoudsartefact bijhouden. |
| Productiegereedheid | 1 | Railway config bestaat, maar auth/storage/jobs/tests ontbreken. | Te vroeg live inzetten met gevoelige data. | Fase 0 stabilisatie uitvoeren. |

## Module scores

| Module | Compleetheid | Data | Security/Auth | Onderhoudbaarheid | Productie | Status |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Login/auth | 2 | 2 | 1 | 2 | 1 | LOCAL_PROTOTYPE |
| CEO cockpit | 2 | 1 | 2 | 2 | 1 | DEMO/PARTIAL |
| Sales | 3 | 3 | 2 | 2 | 2 | PARTIAL |
| Calls/AI score | 2 | 2 | 2 | 2 | 1 | DEMO/PARTIAL |
| Finance dashboard | 3 | 2 | 2 | 2 | 1 | PARTIAL |
| Stripe | 3 | 4 | 3 | 2 | 2 | PARTIAL |
| Wise | 2 | 1 | 3 | 2 | 1 | BLOCKED/PARTIAL |
| Uploads | 2 | 2 | 2 | 2 | 1 | LOCAL_PROTOTYPE |
| Matching engine | 2 | 1 | 2 | 2 | 1 | LOCAL_PROTOTYPE |
| Customer 360 | 1 | 1 | 1 | 1 | 0 | DEMO |
| Delivery | 1 | 0 | 1 | 1 | 0 | DEMO |
| Operations | 1 | 0 | 1 | 1 | 0 | DEMO |
| Marketing | 1 | 0 | 1 | 1 | 0 | DEMO |
| Team/productiviteit | 1 | 0 | 1 | 1 | 0 | DEMO |
| Integratiestatus | 2 | 2 | 2 | 2 | 1 | PARTIAL |
| Meertaligheid | 2 | 1 | n.v.t. | 1 | 1 | LOCAL_PROTOTYPE |
| Supabase schema | 2 | n.v.t. | 1 | 2 | 1 | PLANNED/PARTIAL |
| Deployment | 2 | n.v.t. | 1 | 2 | 1 | LOCAL_PROTOTYPE |

## Conclusie

Autopilots OS scoort als prototype goed op snelheid en zichtbaarheid, maar laag op productiefundament. De eerste ontwikkelwaarde zit niet in meer dashboardkaarten, maar in betrouwbaarheid: auth, persistente database, testbare modules, veilige storage, sync jobs en duidelijke bronstatus.

