# Current State Audit - Autopilots OS

Datum audit: 2026-07-15  
Scope: `sales-dashboard`

## Samenvatting

Autopilots OS is nu een werkend intern prototype met een Node HTTP-server, een grote HTML/CSS/JavaScript-frontend en lokale JSON-opslag voor integratiecaches en financebestanden. De app kan lokaal starten, inloggen, dashboards laden, GHL-data lezen, Stripe-facturen synchroniseren, Wise-profielen ophalen, facturen uploaden/downloaden en role-based dashboardfilters toepassen.

Het systeem is nog niet productiewaardig. Belangrijkste redenen: handmatige auth met plaintext wachtwoorden, in-memory sessies, lokale opslag, geen tests, geen background jobs, geen migrationsysteem, beperkte autorisatie, geen auditlogging in runtime, geen databasegebruik ondanks Supabase-schema, en meerdere modules die visueel of demo-gebaseerd zijn.

## Geinspecteerde bestanden

- `server.js`: Node HTTP-server, API-routes, auth, integraties, dashboardnormalisatie, lokale opslag.
- `public/index.html`: volledige frontend, CSS, login, dashboards, client-side rendering, submenu's.
- `config.js`: hard-coded teamleden, GHL user IDs, pipeline stage IDs en getelde kalenders.
- `package.json`: alleen `start` script, geen dependencies.
- `.env.example`: verwachte secrets en runtimeconfig.
- `.gitignore`: bevat nu `data/`, `.env`, logs en `node_modules`.
- `railway.toml`: Railway Nixpacks deploy met `node server.js`, healthcheck op `/health`.
- `supabase/schema.sql`: initieel schema voor sales, customer, finance, raw imports, review en auditlog.
- `data/*.json`: lokale runtime caches voor GHL, Stripe en AI usage.

## Repository en status

- Hoofdrepo: geen wijzigingen zichtbaar via `git status --short`.
- Nested repo `sales-dashboard`: gewijzigde bestanden:
  - `.gitignore`
  - `README.md`
  - `package.json`
  - `public/index.html`
  - `server.js`
  - `supabase/schema.sql`
- Laatste commits:
  - `9952e88 Hide non-call transcript bodies`
  - `c34856a Map Bingos to appointment creator`
  - `cc3bb66 Fix phone-only calls and call minutes`
  - `7300027 Prepare production sales dashboard`
- Grootste runtimebestand: `data/ghl-live-data.json`, ongeveer 15 MB.

## Stack

- Backend: Node.js core `http`, `fs`, `path`, `crypto`.
- Frontend: single-file HTML/CSS/JavaScript in `public/index.html`.
- Database: Supabase/PostgreSQL-schema aanwezig, maar runtime schrijft/leest niet uit Supabase.
- Storage: lokaal filesystem onder `data/`.
- Auth: eigen login met hard-coded users uit `config.js` en wachtwoorden uit `.env`.
- Deploy: Railway-config aanwezig.
- Tests/tooling: geen testscript, geen TypeScript, geen linter, geen formatter, geen e2e-tooling.

## Request flow

1. Browser opent `/`.
2. `staticFile()` serveert `public/index.html`.
3. Loginformulier doet `POST /api/login`.
4. Server vergelijkt e-mail/wachtwoord tegen `users` uit `config.js` plus `.env`.
5. Server zet `ap_sales_sid` cookie en bewaart sessie in `sessions = new Map()`.
6. Frontend haalt `/api/dashboard` op.
7. Backend laadt GHL live/cache of demo fallback, verrijkt met lokale Stripe/Wise/usage/uploadbestanden.
8. Frontend rendert dashboardkaarten client-side.

## Routes

| Route | Methode | Auth | Status | Opmerking |
| --- | --- | --- | --- | --- |
| `/health` | GET | Nee | LIVE | Geeft integratieconfigstatus zonder secrets. Getest OK. |
| `/api/login` | POST | Nee | LOCAL_PROTOTYPE | Plaintext wachtwoordvergelijking, sessie in memory. Getest OK. |
| `/api/logout` | POST | Cookie | LOCAL_PROTOTYPE | Verwijdert sessie uit memory. |
| `/api/me` | GET | Cookie | LOCAL_PROTOTYPE | Getest OK. |
| `/api/dashboard` | GET | Cookie | PARTIAL | Getest OK; GHL live/cache, overige modules deels demo/lokaal. |
| `/api/calls/:id/score` | POST | Cookie | DEMO | AI-score is lokale heuristiek, geen echte LLM. |
| `/api/finance/invoices/upload` | POST | Admin | LOCAL_PROTOTYPE | Upload naar lokale disk. Getest OK. |
| `/api/finance/invoices/:id/download` | GET | Admin | LOCAL_PROTOTYPE | Admin-only download. Getest OK. |
| `/api/finance/matches/:id` | POST | Admin | LOCAL_PROTOTYPE | Schrijft decisions naar lokale JSON. |
| `/api/integrations/stripe/sync` | POST | Admin | PARTIAL | Getest: 53 facturen, 4 upcoming subscriptions. |
| `/api/integrations/wise/profiles` | POST | Admin | PARTIAL | Getest: 2 profielen gevonden. |
| `/api/integrations/wise/sync` | POST | Admin | BLOCKED/PARTIAL | Probeert Wise statements; CSV fallback nodig als API blokkeert. |
| `/api/integrations/wise/csv-upload` | POST | Admin | LOCAL_PROTOTYPE | CSV-import lokaal. |
| `/api/integrations/usage/sync` | POST | Admin | DEMO | Getest: demo usage model, providers ontbreken. |
| `/api/debug/live-data` | GET | Admin of debug token | PARTIAL | Getest: zonder auth 401; admin geeft GHL diagnostiek. |
| onbekend pad | GET | Nee | LIVE | Geeft 404 JSON. Getest OK. |

## Runtime testresultaten

- `/health`: OK, Stripe/Wise/GHL/Supabase configured, ElevenLabs/Telnyx false.
- Admin login: OK met `admin@autopilots.nl`.
- `/api/me`: OK.
- `/api/dashboard`: OK, `rawSync.mode = live`, 20 calls, OS-secties aanwezig.
- GHL debug: counts `opportunities=2500`, `conversations=2500`, `contacts=2500`, `pipelines=6`, `users=13`, `calendars=6`, `voiceCallLogs=0`, `calendarEvents=5`.
- Setter login: OK met fallback/dev wachtwoord.
- Setter dashboard: finance/marketing/teamOps verborgen, calls gefilterd naar 3, closers leeg, setters 1.
- Setter `POST /api/integrations/stripe/sync`: 403.
- Debug zonder auth: 401.
- Factuurupload/download admin: OK; testrecord is na audit verwijderd.
- Factuurdownload als setter: 403.
- Usage sync: demo model, 3 agents, total cost 638.99.
- Stripe sync: 53 invoices, 4 upcoming subscriptions.
- Wise profiles: 2 profiles.

## Opslag

| Bestand | Status | Opmerking |
| --- | --- | --- |
| `data/ghl-live-data.json` | LOCAL_PROTOTYPE | 15 MB cache met GHL raw data. |
| `data/stripe-invoices.json` | LOCAL_PROTOTYPE | Laatste Stripe-sync met 53 facturen en 4 upcoming subscriptions. |
| `data/wise-transactions.json` | BLOCKED | Ontbrak tijdens audit; Wise CSV/API-feed nog niet gevuld. |
| `data/finance-matches.json` | LOCAL_PROTOTYPE | Ontbrak tijdens audit; wordt aangemaakt bij reviewbeslissingen. |
| `data/ai-usage-costs.json` | DEMO | Demo usage feed. |
| `data/invoice-uploads/index.json` | LOCAL_PROTOTYPE | Uploadindex lokaal. |

## Authenticatie en autorisatie

- Users staan hard-coded in `config.js`.
- Wachtwoorden worden uit `.env` geladen; fallback in development is `autopilot` voor admin en `welkom` voor medewerkers.
- Wachtwoorden worden plaintext vergeleken.
- Sessies staan in memory en verdwijnen bij restart.
- Cookie is `HttpOnly`; in productie gebruikt `SameSite=None; Secure`, lokaal `SameSite=Lax`.
- Rollen zijn beperkt tot `admin`, `setter`, `closer`.
- Enkele gevoelige endpoints controleren server-side adminrol.
- RBAC is te grof voor toekomstige modules zoals finance manager, projectmanager, freelancer, auditor.

## Moduleoverzicht

| Module | Status | Bewijs | Opmerking |
| --- | --- | --- | --- |
| CEO | DEMO/PARTIAL | `operatingSystemDemo()` | KPI's grotendeels hard-coded/demo, aangevuld met Stripe/Wise waar beschikbaar. |
| Klanten | DEMO | `operatingSystemDemo().customers` | Drie demo-klanten; geen centrale customer database runtime. |
| Finance | PARTIAL | Stripe sync, upload, matching engine | Stripe live deels; Wise transacties niet gevuld; upload/matching lokaal; geen boekhoudpakket. |
| Sales | PARTIAL | GHL live/cache, `normalizeLiveData()` | KPI's op GHL-opportunities/conversations/calendar events; mapping fragiel. |
| Training | PLANNED | Geen route/tabel/runtime | Alleen AI-score/callcoach als eerste hint. |
| Projectmanagement | PLANNED | Delivery demo cards | ClickUp nog niet aangesloten. |
| Delivery | DEMO | `operatingSystemDemo().delivery` | Drie demo-milestones. |
| Operations | DEMO | `operatingSystemDemo().operations` | Geen Read AI/Gmail/Docs runtime. |
| Marketing | DEMO | `operatingSystemDemo().marketing` | Geen social API-koppelingen. |
| Team | DEMO/PARTIAL | hard-coded users + demo activity | Geen ClickUp/GHL loginproductiviteit. |
| Integraties | PARTIAL | GHL/Stripe/Wise/usage endpoints | GHL/Stripe/Wise profiles getest; usage demo; ClickUp/Read AI/Google/social planned. |
| Instellingen | PLANNED | Geen scherm | Geen settingsmodel. |
| Meertaligheid | LOCAL_PROTOTYPE | `i18n` object in frontend | NL/EN hard-coded in single file. |

## Huidige sterke punten

- Werkende centrale cockpit in Autopilots-stijl.
- GHL-data wordt echt opgehaald en gecached.
- Stripe-sync werkt met live key.
- Wise-profielen kunnen worden opgehaald.
- Admin-only serverchecks bestaan voor financeacties.
- Finance matching heeft een begin van uitlegbare confidence/reasons.
- `.gitignore` sluit `data/` en `.env` uit.
- Supabase-schema laat de juiste richting zien.

## Belangrijkste technische schuld

- Eén `server.js` van meer dan 100 KB met routes, adapters, businesslogic, renderingdata, file I/O en matching.
- Eén `public/index.html` van bijna 100 KB met styling, markup en state/renderlogica.
- Geen modulegrenzen, tests, typed contracts of database repositories.
- Geen queue/retry/idempotencylaag voor integraties.
- Geen production-grade auth/RBAC.
- Lokale bestanden als bron van waarheid.
- Demo en live data lopen in dezelfde dashboardmodellen door elkaar.

