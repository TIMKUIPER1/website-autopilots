# Gap Analysis - Autopilots OS

| Categorie | Huidige situatie | Gewenste situatie | Risico als niets gebeurt | Benodigde wijziging | Prioriteit |
| --- | --- | --- | --- | --- | --- |
| Platform | Single Node/HTML app | Modulaire monoliet met modules | Moeilijk onderhoudbaar | Modulegrenzen + TypeScript | P1 |
| Auth | Plaintext env-wachtwoorden, in-memory sessies | Supabase Auth, MFA, revocation | Account/security risico | Authmigratie | P0 |
| RBAC | Admin/setter/closer | Fijnmazige rollen/permissions/RLS | Te veel of te weinig toegang | Permission service + RLS | P0 |
| Database | Schema bestaat, runtime JSON | PostgreSQL als centrale waarheid | Data kwijt/inconsistent | Repositories + migrations | P1 |
| Sales | GHL live/cache + hard-coded mapping | Genormaliseerde sales core records | KPI-mismatch | GHL adapter + identity mapping | P2 |
| Training | Niet aanwezig | Academy + AI recommendations | Geen schaalbare coaching | Training datamodel + UI | P3 |
| Projecten | Delivery demo, geen ClickUp | ClickUp sync + projectoverzicht | Deliveryrisico's handmatig | ClickUp adapter | P2 |
| Finance | Stripe live, Wise partial, uploads lokaal | Factuurverwerking + reconciliatie | Onbetrouwbare cash/marge | Finance foundation + storage | P1 |
| Meertaligheid | Hard-coded frontend object | i18n framework + user locale | Moeilijk uitbreidbaar | Translation files + DB content strategy | P2 |
| Integraties | Directe fetches in `server.js` | Adapters, jobs, cursors, retries | Timeouts/rate limits | Worker + adapterlaag | P1 |
| Security | Geen rate limit/CSP/audit runtime | Security baseline | Productierisico | Fase 0 hardening | P0 |
| Tests | Geen tests | Unit/integration/e2e | Regressies | Test harness | P0 |
| Observability | Health + console | Logs, job monitoring, alerts | Fouten blijven verborgen | Structured logging | P1 |
| UX | Mooie cockpit, bronstatus beperkt | Bronstatus, rolportalen, journeys | Verwarring live/demo | Data badges + user journeys | P2 |
| Deployment | Railway basis | local/dev/staging/prod | Onveilige livegang | Environment strategy | P1 |

## Grootste functionele gaten

1. Geen productiewaardige auth.
2. Geen centrale database runtime.
3. Geen veilige storage.
4. Geen background sync.
5. Geen tests.
6. Geen echte Customer 360.
7. Geen echte trainingmodule.
8. Geen ClickUp delivery-sync.
9. Geen Gmail/Read AI/Google Drive backend sync.
10. Geen echte ElevenLabs/Telnyx usage sync.

