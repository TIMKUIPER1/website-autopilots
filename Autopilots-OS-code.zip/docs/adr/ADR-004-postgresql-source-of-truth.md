# ADR-004: PostgreSQL als centrale waarheid

## Context

Runtime gebruikt lokale JSON-caches.

## Beslissing

PostgreSQL via Supabase wordt centrale waarheid.

## Motivatie

Relaties, constraints, RLS, auditlogs en analytics views zijn nodig.

## Gevolgen

Lokale JSON wordt alleen tijdelijke import/backup, niet productiebron.

