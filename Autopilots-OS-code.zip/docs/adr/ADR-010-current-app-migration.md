# ADR-010: Migratie van huidige Node/HTML-monoliet

## Context

Huidige app werkt deels en bevat waardevolle logica.

## Beslissing

Geen big-bang rewrite. Gebruik strangler-migratie.

## Motivatie

Behoud werkende GHL/Stripe/finance flows en migreer module voor module.

## Gevolgen

Parallelle validatie tussen oude dashboardoutput en nieuwe databaseviews.

