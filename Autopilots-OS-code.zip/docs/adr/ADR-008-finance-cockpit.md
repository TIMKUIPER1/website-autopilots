# ADR-008: Finance cockpit versus volledig boekhoudsysteem

## Context

Autopilots wil finance inzicht, matching en forecast.

## Beslissing

Bouw eerst een operationele finance cockpit en reconciliatie-engine, geen volledig boekhoudpakket.

## Motivatie

Officiele boekhouding vereist grootboek, btw, period close, jurisdictie en accountantafspraken.

## Gevolgen

Export naar accountant/boekhoudpakket komt later.

