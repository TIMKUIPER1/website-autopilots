# ADR-002: Frontend- en backendstack

## Context

Huidige app is pure Node + single HTML file.

## Opties

- Pure Node/HTML blijven gebruiken.
- Next.js TypeScript.
- Aparte Fastify/NestJS API plus frontend.

## Beslissing

Next.js met TypeScript als doelstack, API/serverlogica eerst binnen dezelfde app.

## Motivatie

Route-based modules, typed UI/API, goede deploybaarheid en geen onnodig zware backend split.

## Gevolgen

Gefaseerde migratie nodig; huidige app blijft referentie.

## Wanneer heroverwegen

Als API-clients, workerload of teamgrenzen aparte API vereisen.

