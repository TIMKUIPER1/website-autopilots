# ADR-005: Raw, staging, core en analytics data

## Context

Dashboards gebruiken nu genormaliseerde objecten direct uit fetch/cache/demo.

## Beslissing

Gebruik raw imports, staging records, core records en analytics views.

## Motivatie

Integraties veranderen; dashboards moeten stabiel blijven.

## Gevolgen

Meer databasewerk vooraf, minder dashboardfragiliteit.

