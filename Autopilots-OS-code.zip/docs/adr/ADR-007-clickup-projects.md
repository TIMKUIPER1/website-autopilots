# ADR-007: ClickUp behouden of projectmodule bouwen

## Context

Delivery/projectmanagement staat nu als demo in Autopilots OS.

## Beslissing

ClickUp blijft voorlopig leidend. Autopilots OS synchroniseert en toont overzicht.

## Motivatie

Een ClickUp-kloon bouwen heeft nu te weinig onderbouwde waarde.

## Wanneer heroverwegen

Als dubbele invoer te groot wordt, permissions niet passen of finance/operations koppelingen structureel tekortschieten.

