# ADR-006: Queue en background jobs

## Context

Syncs draaien nu in HTTP requests.

## Beslissing

Introduceer queue-based workers met retries, cursors en dead-letter queue.

## Motivatie

GHL/Stripe/Wise syncs kunnen traag zijn, rate limits raken of falen.

## Gevolgen

Railway Redis/BullMQ of passend alternatief nodig.

