# ADR-001: Modular monolith versus microservices

## Context

Autopilots OS heeft sterk gekoppelde domeinen: customer, sales, finance, delivery, usage en documenten.

## Opties

- Huidige single-file app behouden.
- Modulaire monoliet.
- Microservices.

## Beslissing

Kies een modulaire monoliet.

## Motivatie

Dit geeft duidelijke modulegrenzen zonder distributed system complexiteit.

## Gevolgen

Modules delen database en auth, maar krijgen eigen services/repositories/tests.

## Wanneer heroverwegen

Bij zware sync workloads, aparte team ownership of compliance-isolatie.

