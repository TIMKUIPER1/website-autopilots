# ADR-009: Internationalisatie

## Context

Frontend heeft hard-coded NL/EN i18n object.

## Beslissing

Gebruik centrale translation keys, user locale en contentstrategie per contenttype.

## Motivatie

Meertaligheid moet platformfunctie zijn, niet verspreide strings.

## Gevolgen

UI-strings naar translation files; training/content waar nodig in DB.

