# ADR-003: Supabase Auth en RBAC

## Context

Huidige auth gebruikt hard-coded users, env-wachtwoorden en in-memory sessies.

## Opties

- Eigen auth hardenen.
- Supabase Auth.
- Externe IdP.

## Beslissing

Gebruik Supabase Auth met eigen RBAC-tabellen en RLS.

## Motivatie

Password reset, MFA, persistent sessions en database-integratie zijn nodig.

## Gevolgen

Migratie van `config.js` users naar database/users.

## Wanneer heroverwegen

Bij enterprise SSO-eis.

