# RBAC Matrix - Autopilots OS

## Rollen

- Super admin
- Founder/directie
- Finance manager
- Sales manager
- Setter
- Closer
- Projectmanager
- Delivery medewerker
- Operations
- Marketing
- Teamlid
- Freelancer
- Auditor/accountant
- Toekomstige klantgebruiker

## Matrix

Legenda: `own`, `team`, `all`, `none`, `approve`, `export`, `sensitive`.

| Module | Super admin | Directie | Finance | Sales manager | Setter | Closer | Projectmanager | Delivery | Ops | Marketing | Freelancer | Auditor | Klant |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Platform settings | all | all | none | none | none | none | none | none | none | none | none | none | none |
| Users/roles | all | all | none | team read | none | none | team read | team read | team read | none | none | read | none |
| CEO cockpit | all | all | finance subset | sales subset | none | none | delivery subset | delivery subset | ops subset | marketing subset | none | read | none |
| Sales KPI | all | all | none | team | own | own | none | none | none | none | none | read | none |
| Calls/transcripts | all | all | none | team review | own | own | linked only | linked only | linked only | none | assigned only | read logged | none |
| Training | all | all | none | team assign/review | own | own | none | none | none | none | assigned own | read | none |
| Customers | all | all | financial read | sales linked | assigned limited | assigned limited | assigned projects | assigned projects | all ops | marketing limited | assigned only | read logged | own |
| Documents | all | all | finance docs | sales docs limited | none | none | project docs | project docs | ops docs | marketing docs | assigned docs | read logged | own docs |
| Finance | all | all sensitive | all approve/export | none | none | none | project budget limited | cost limited | none | own spend limited | none | read/export logged | none |
| Personal expenses | all | all sensitive | all sensitive | none | none | none | none | none | none | none | none | read logged if allowed | none |
| Delivery/projects | all | all | budget read | handoff read | none | handoff read | all assigned | assigned update | ops read/update | none | assigned update | read | own project read |
| Operations timeline | all | all | finance-related | customer comms | none | none | assigned | assigned | all | none | assigned | read | own |
| Marketing | all | all | spend read | campaign read | none | none | none | none | none | all | none | read | none |
| Integrations | all | all | finance integrations | sales integrations | none | none | clickup read | clickup read | google/readai read | social read | none | read | none |
| Exports | all | all logged | finance export | sales export | none | none | project export | none | ops export | marketing export | none | export logged | own export |

## Belangrijke regels

- Setters zien geen bedrijfsfinance.
- Closers zien geen bedrijfsfinance tenzij expliciet managementrol.
- Freelancers zien alleen toegewezen projecten, klanten en documenten.
- Persoonlijke uitgaven alleen finance en directie.
- Transcripties alleen bij operationele noodzaak.
- Factuurdownloads worden gelogd.
- Exports worden gelogd.
- Service role key komt nooit in de browser.
- Frontend verbergen is geen autorisatie.

## RLS-richting

Voor gevoelige tabellen:

- `organization_id = current_user_org()`
- finance tabellen: alleen rollen met `finance.view`
- personal expense records: `finance.view_sensitive` of `directie`
- project records: assigned user/team of projectmanager
- sales calls: owner, closer, sales manager team, admin
- audit logs: admin/directie/auditor read-only

Elke API-route moet permission middleware gebruiken en waar mogelijk database RLS vertrouwen als tweede laag.

