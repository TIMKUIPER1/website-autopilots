# Security Audit - Autopilots OS

Datum: 2026-07-15  
Scope: `sales-dashboard`

## Geteste positieve controles

- `/api/dashboard` zonder sessie geeft 401.
- Setterdashboard wordt server-side gefilterd: geen finance, marketing of teamOps.
- Setter kan `POST /api/integrations/stripe/sync` niet uitvoeren: 403.
- Debugendpoint zonder sessie of debugtoken geeft 401.
- Factuurdownload als setter geeft 403.
- Upload/download gebruikt `path.join` met opgeslagen naam en admincheck.
- `.env` en `data/` staan in `.gitignore`.

## Risicolijst

| Severity | Risico | Bewijs | Impact | Exploitability | Aanbevolen fix | Complexiteit |
| --- | --- | --- | --- | --- | --- | --- |
| Critical | Plaintext/dev wachtwoorden | `server.js` `login()`, `fallbackPassword()`; `config.js` users | Account takeover als productieconfig fout staat | Hoog | Supabase Auth/Auth.js, hashed passwords, reset, MFA | Medium |
| Critical | In-memory sessies | `const sessions = new Map()` | Sessies kwijt bij restart, geen revocation/audit | Medium | Persistente sessies/authprovider | Medium |
| High | Lokale uploads en caches | `data/invoice-uploads`, `data/*.json` | Datalek/backup/retentie/onveilige productieopslag | Medium | Supabase Storage private buckets + DB metadata | Medium |
| High | Geen rate limiting/bruteforce | Geen middleware/deps | Password spraying mogelijk | Hoog | Login rate limit, IP/user lockout, alerting | Low |
| High | Globale error lekt `detail` | `json(res, 500, { error, detail: error.message })` | Interne foutinfo naar browser | Medium | Productie-safe errorhandler | Low |
| High | Debugendpoint kan veel data tonen | `/api/debug/live-data` admin/debugtoken | Gevoelige CRM-diagnostiek kan lekken | Medium | Alleen admin + auditlog, geen token via query, redactie | Low/Medium |
| High | Geen CSRF-bescherming | Cookie-auth + POST endpoints | Cross-site POST mogelijk bij bepaalde cookie settings | Medium | SameSite Lax/Strict waar mogelijk, CSRF token | Medium |
| High | Geen database-side autorisatie | Supabase RLS ontbreekt in runtime | Frontend/serverbug kan teveel data tonen | Medium | RLS en permission checks | High |
| Medium | Uploadvalidatie beperkt | Extensie allowlist, geen MIME/malware/hash | Schadelijke bestanden kunnen worden opgeslagen | Medium | MIME sniffing, hash, size policy, malware scan | Medium |
| Medium | Geen auditlog voor financeacties runtime | `audit_log` schema bestaat, niet gebruikt | Geen forensische trail | Medium | Auditlog middleware/service | Medium |
| Medium | Service role key aanwezig in env | Niet client-side gevonden, wel runtime | Lek bij logging/misconfig ernstig | Laag/Medium | Secrets manager, least privilege, nooit frontend | Medium |
| Medium | Hard-coded team/rollen | `config.js` | Verkeerde toegang bij personeelswissel | Medium | Users/roles in DB + invite flow | Medium |
| Medium | Geen security headers/CSP | `staticFile()` zet alleen content-type | XSS impact groter | Medium | Helmet-equivalent headers/CSP | Low |
| Medium | Geen webhookauth/idempotency | Geen webhookroutes of idempotency table runtime | Dubbele/onjuiste syncs later | Medium | Webhook inbox + idempotency | Medium |
| Low | Onbekende routes JSON 404 | Getest OK | Geen direct risico | Laag | Behouden | Low |

## Specifieke controles

- Sessies gaan verloren bij herstart: ja, in-memory `Map`.
- Wachtwoorden plaintext: ja, directe stringvergelijking.
- Development fallbackwachtwoorden mogelijk: ja in non-production.
- Users hard-coded: ja in `config.js`.
- Gevoelige bestanden lokaal: ja onder `data/`.
- Downloads voldoende geautoriseerd voor huidige admin/setter test: ja, admin-only.
- Debugdata productiegegevens: waarschijnlijk, omdat GHL diagnostics en observed data worden opgebouwd.
- Exceptiondetails aan gebruikers: ja via globale catch `detail`.
- Financeacties role protected: geteste endpoints wel, RBAC blijft grof.

## Uitgevoerde veilige correcties tijdens audit

Tijdens de eerste auditronde zijn geen codewijzigingen uitgevoerd. Een tijdelijk factuuruploadrecord dat tijdens de audit is aangemaakt voor testdoeleinden is direct verwijderd uit lokale testdata.

Na de audit is op 2026-07-20 Fase 0 gestart:

- productie-safe errorhandler;
- security headers;
- login rate limiting;
- lokale auditlog;
- integration health opslag;
- testexports en unit tests;
- databackupscript.

Zie `docs/roadmap/IMPLEMENTATION_LOG.md`.

## Prioriteit

1. Auth vervangen of hardenen.
2. Rate limiting + veilige errorhandler.
3. Auditlog voor alle gevoelige acties.
4. Lokale storage vervangen door private object storage.
5. RBAC server-side en database-side.
6. Secrets en debugroute hardenen.
