    const state = { data: null, viewer: null, query: "", financeFilter: "all", activeModule: "command", activeSection: "ceo", lang: localStorage.getItem("apSalesLang") || "nl" };
    const sectionMenu = {
      command: {
        title: "Command Center",
        items: [
          ["Overzicht", "section-ceo"],
          ["Risico's", "ceo-risks"],
          ["Beslissingen", "ceo-decisions"]
        ]
      },
      sales: {
        title: "Sales",
        items: [
          ["Overzicht", "section-sales"],
          ["Pipeline", "sales-funnel"],
          ["Setters", "section-setters", "setter"],
          ["Closers", "section-closers", "closer"],
          ["Gesprekken", "section-transcripts"]
        ]
      },
      finance: {
        title: "Finance",
        items: [
          ["Overzicht", "section-finance"],
          ["Cashflow", "finance-cashflow"],
          ["Facturen", "finance-invoices"],
          ["AI-usage", "finance-usage"],
          ["Review inbox", "finance-review-card"],
          ["Abonnementen", "finance-subscriptions"],
          ["Transacties", "finance-wise"],
          ["Uploaden", "finance-upload"]
        ]
      },
      customers: {
        title: "Klanten",
        items: [
          ["Overzicht", "section-customers"],
          ["Klantkaart", "customers-map"],
          ["Klanttimeline", "section-operations"],
          ["Documenten & contact", "operations-timeline"]
        ]
      },
      delivery: {
        title: "Delivery",
        items: [
          ["Overzicht", "section-delivery"],
          ["Voortgang", "delivery-progress"]
        ]
      },
      marketing: {
        title: "Marketing",
        items: [
          ["Overzicht", "section-marketing"],
          ["Contentprestaties", "marketing-posts"]
        ]
      },
      team: {
        title: "Team",
        items: [
          ["Overzicht", "section-team"],
          ["Activiteit", "team-activity"]
        ]
      },
      integrations: {
        title: "Integraties",
        items: [
          ["Overzicht", "section-integrations"],
          ["GoHighLevel", "integrations-ghl"],
          ["Stripe", "integrations-stripe"],
          ["Wise", "integrations-wise"],
          ["AI-usage", "integrations-usage"],
          ["Systeemstatus", "integrations-status"]
        ]
      }
    };
    const i18n = {
      nl: {
        teamDashboard: "Operating system",
        loginTitle: "Login voor het Autopilots bedrijfsbrein.",
        loginText: "Bekijk sales, klanten, finance, delivery, operations en teamdata vanuit een rustige centrale cockpit.",
        email: "E-mail",
        password: "Wachtwoord",
        language: "Taal",
        loginButton: "Inloggen",
        overview: "Overzicht",
        setters: "Setters",
        closers: "Closers",
        transcripts: "Transcripties",
        salesPerformance: "Autopilots Operating System",
        loading: "Data laden...",
        thisWeek: "Deze week",
        today: "Vandaag",
        thisMonth: "Deze maand",
        refresh: "Verversen",
        logout: "Uitloggen",
        liveSync: "Live gekoppeld - laatst gesynchroniseerd",
        demoSync: "Demo-data actief - vul de backend token in voor live data",
        callsToday: "Calls vandaag",
        callsWeek: "Calls deze week",
        answeredCalls: "Gesprekken beantwoord",
        bingos: "Bingo's",
        callMinutes: "Minuten gebeld",
        noShows: "No-shows",
        bingosPerHour: "Bingo's per uur",
        conversationsPerBingo: "Gesprekken per Bingo",
        setterFunnel: "Setter funnel",
        bingoMeans: "Bingo = afspraak",
        opportunitiesInStage: "Opportunities in stage",
        callsToBingo: "Calls naar Bingo",
        nopeRatioTitle: "Nope not today ratio",
        callsPerBingo: "calls per Bingo",
        nopePerBingo: "Nope per Bingo",
        setterPerformance: "Setter performance",
        closerPerformance: "Closer performance",
        perPerson: "Per persoon",
        wonLost: "Won/lost",
        transcriptDatabase: "Transcriptie database",
        searchPlaceholder: "Zoek contact, setter of resultaat",
        setter: "Setter",
        callMinutesShort: "Min. gebeld",
        callsTodayShort: "Calls vandaag",
        callsWeekShort: "Calls week",
        conversations: "Gesprekken",
        callsBingo: "Calls/Bingo",
        bingoHour: "Bingo/beluur",
        closer: "Closer",
        showed: "Opgekomen",
        meetings: "Meetings",
        won: "Gewonnen",
        lost: "Verloren",
        daysToWon: "Dagen tot won",
        noRoleData: "Geen data voor deze rol.",
        noCalls: "Geen gesprekken gevonden.",
        aiScore: "AI score",
        loadingCoach: "AI coaching wordt geladen...",
        missed: "Waar ging het mis",
        wentWell: "Wat ging goed",
        couldImprove: "Wat kon beter",
        minute: "min",
        management: "management"
      },
      en: {
        teamDashboard: "Operating system",
        loginTitle: "Log in to the Autopilots company cockpit.",
        loginText: "View sales, customers, finance, delivery, operations and team data from one calm central workspace.",
        email: "Email",
        password: "Password",
        language: "Language",
        loginButton: "Log in",
        overview: "Overview",
        setters: "Setters",
        closers: "Closers",
        transcripts: "Transcripts",
        salesPerformance: "Autopilots Operating System",
        loading: "Loading data...",
        thisWeek: "This week",
        today: "Today",
        thisMonth: "This month",
        refresh: "Refresh",
        logout: "Log out",
        liveSync: "Live connected - last synced",
        demoSync: "Demo data active - add the backend token for live data",
        callsToday: "Calls today",
        callsWeek: "Calls this week",
        answeredCalls: "Answered conversations",
        bingos: "Bingos",
        callMinutes: "Call minutes",
        noShows: "No-shows",
        bingosPerHour: "Bingos per hour",
        conversationsPerBingo: "Conversations per Bingo",
        setterFunnel: "Setter funnel",
        bingoMeans: "Bingo = appointment",
        opportunitiesInStage: "Opportunities in stage",
        callsToBingo: "Calls to Bingo",
        nopeRatioTitle: "Nope not today ratio",
        callsPerBingo: "calls per Bingo",
        nopePerBingo: "Nope per Bingo",
        setterPerformance: "Setter performance",
        closerPerformance: "Closer performance",
        perPerson: "Per person",
        wonLost: "Won/lost",
        transcriptDatabase: "Transcript database",
        searchPlaceholder: "Search contact, setter or result",
        setter: "Setter",
        callMinutesShort: "Call min.",
        callsTodayShort: "Calls today",
        callsWeekShort: "Calls week",
        conversations: "Conversations",
        callsBingo: "Calls/Bingo",
        bingoHour: "Bingo/call hour",
        closer: "Closer",
        showed: "Showed",
        meetings: "Meetings",
        won: "Won",
        lost: "Lost",
        daysToWon: "Days to won",
        noRoleData: "No data for this role.",
        noCalls: "No conversations found.",
        aiScore: "AI score",
        loadingCoach: "AI coaching is loading...",
        missed: "Where it went wrong",
        wentWell: "What went well",
        couldImprove: "What could improve",
        minute: "min",
        management: "management"
      }
    };

    const loginView = document.getElementById("loginView");
    const appView = document.getElementById("appView");
    const mainTitle = document.querySelector(".ap-title h1");
    const subnav = document.getElementById("subnav");
    const loginForm = document.getElementById("loginForm");
    const loginError = document.getElementById("loginError");
    const viewerLabel = document.getElementById("viewerLabel");
    const viewerName = document.getElementById("viewerName");
    const viewerAvatar = document.getElementById("viewerAvatar");
    const syncLabel = document.getElementById("syncLabel");
    const ceoStats = document.getElementById("ceoStats");
    const ceoRisks = document.getElementById("ceoRisks");
    const ceoDecisions = document.getElementById("ceoDecisions");
    const customersTable = document.getElementById("customersTable");
    const financeStats = document.getElementById("financeStats");
    const financeReview = document.getElementById("financeReview");
    const financeMatchStats = document.getElementById("financeMatchStats");
    const financeMatchList = document.getElementById("financeMatchList");
    const financeMatchStatus = document.getElementById("financeMatchStatus");
    const financeForecastTotal = document.getElementById("financeForecastTotal");
    const invoiceForecastTable = document.getElementById("invoiceForecastTable");
    const cashflowForecastTable = document.getElementById("cashflowForecastTable");
    const usageCostStatus = document.getElementById("usageCostStatus");
    const usageCostStats = document.getElementById("usageCostStats");
    const usageCostTable = document.getElementById("usageCostTable");
    const wiseTransactionsList = document.getElementById("wiseTransactionsList");
    const subscriptionsList = document.getElementById("subscriptionsList");
    const automaticInvoiceSources = document.getElementById("automaticInvoiceSources");
    const invoiceUploadForm = document.getElementById("invoiceUploadForm");
    const invoiceUploadMessage = document.getElementById("invoiceUploadMessage");
    const invoiceFileInput = document.getElementById("invoiceFileInput");
    const invoiceFileName = document.getElementById("invoiceFileName");
    const wiseCsvUploadForm = document.getElementById("wiseCsvUploadForm");
    const wiseCsvUploadMessage = document.getElementById("wiseCsvUploadMessage");
    const wiseCsvFileInput = document.getElementById("wiseCsvFileInput");
    const wiseCsvFileName = document.getElementById("wiseCsvFileName");
    const uploadedInvoicesList = document.getElementById("uploadedInvoicesList");
    const deliveryList = document.getElementById("deliveryList");
    const operationsStats = document.getElementById("operationsStats");
    const operationsTimeline = document.getElementById("operationsTimeline");
    const marketingStats = document.getElementById("marketingStats");
    const topPosts = document.getElementById("topPosts");
    const teamStats = document.getElementById("teamStats");
    const teamTable = document.getElementById("teamTable");
    const integrationsList = document.getElementById("integrationsList");
    const ghlStatusChip = document.getElementById("ghlStatusChip");
    const ghlDatasetStats = document.getElementById("ghlDatasetStats");
    const ghlDatasetList = document.getElementById("ghlDatasetList");
    const stripeSyncBtn = document.getElementById("stripeSyncBtn");
    const stripeSyncStatus = document.getElementById("stripeSyncStatus");
    const wiseProfilesBtn = document.getElementById("wiseProfilesBtn");
    const wiseProfilesStatus = document.getElementById("wiseProfilesStatus");
    const wiseProfilesList = document.getElementById("wiseProfilesList");
    const wiseSyncBtn = document.getElementById("wiseSyncBtn");
    const wiseSyncStatus = document.getElementById("wiseSyncStatus");
    const usageSyncBtn = document.getElementById("usageSyncBtn");
    const usageSyncStatus = document.getElementById("usageSyncStatus");
    const totalStats = document.getElementById("totalStats");
    const pipeline = document.getElementById("pipeline");
    const settersTable = document.getElementById("settersTable");
    const closersTable = document.getElementById("closersTable");
    const callList = document.getElementById("callList");
    const searchInput = document.getElementById("searchInput");
    const loginLanguage = document.getElementById("loginLanguage");
    const languageSelect = document.getElementById("languageSelect");

    init();

    async function init() {
      bindEvents();
      try {
        const me = await api("/api/me");
        state.viewer = me.user;
        await loadDashboard();
        showApp();
      } catch {
        showLogin();
      }
    }

    function bindEvents() {
      if (window.lucide) window.lucide.createIcons();
      loginForm.addEventListener("submit", handleLoginSubmit);
      loginLanguage.value = state.lang;
      languageSelect.value = state.lang;
      loginLanguage.addEventListener("change", () => setLanguage(loginLanguage.value));
      languageSelect.addEventListener("change", () => setLanguage(languageSelect.value));

      document.getElementById("logoutBtn").addEventListener("click", async () => {
        await api("/api/logout", { method: "POST" });
        showLogin();
      });

      document.getElementById("refreshBtn").addEventListener("click", loadDashboard);

      stripeSyncBtn.addEventListener("click", async () => {
        stripeSyncStatus.textContent = "Synchroniseren...";
        stripeSyncBtn.disabled = true;
        try {
          const result = await api("/api/integrations/stripe/sync", { method: "POST" });
          stripeSyncStatus.textContent = `${result.count} facturen opgehaald`;
          await loadDashboard();
        } catch (error) {
          stripeSyncStatus.textContent = error.message;
        } finally {
          stripeSyncBtn.disabled = false;
        }
      });

      wiseProfilesBtn.addEventListener("click", async () => {
        wiseProfilesStatus.textContent = "Ophalen...";
        wiseProfilesBtn.disabled = true;
        try {
          const result = await api("/api/integrations/wise/profiles", { method: "POST" });
          wiseProfilesStatus.textContent = `${result.count} profielen gevonden`;
          wiseProfilesList.innerHTML = result.profiles.length
            ? result.profiles.map((profile) => listItem(
              `${profile.name} - ${profile.type || "profile"}`,
              `Profile ID: ${profile.id}${profile.configured ? " - ingesteld in .env" : ""}`
            )).join("")
            : listItem("Geen profielen", "Wise gaf geen profielen terug voor deze token.");
        } catch (error) {
          wiseProfilesStatus.textContent = error.message;
          wiseProfilesList.innerHTML = "";
        } finally {
          wiseProfilesBtn.disabled = false;
        }
      });

      wiseSyncBtn.addEventListener("click", async () => {
        wiseSyncStatus.textContent = "Synchroniseren...";
        wiseSyncBtn.disabled = true;
        try {
          const result = await api("/api/integrations/wise/sync", { method: "POST" });
          wiseSyncStatus.textContent = `${result.count} transacties opgehaald`;
          await loadDashboard();
        } catch (error) {
          wiseSyncStatus.textContent = error.message;
        } finally {
          wiseSyncBtn.disabled = false;
        }
      });

      usageSyncBtn.addEventListener("click", async () => {
        usageSyncStatus.textContent = "Synchroniseren...";
        usageSyncBtn.disabled = true;
        try {
          const result = await api("/api/integrations/usage/sync", { method: "POST" });
          usageSyncStatus.textContent = `${result.agents} AI medewerkers verwerkt`;
          await loadDashboard();
        } catch (error) {
          usageSyncStatus.textContent = error.message;
        } finally {
          usageSyncBtn.disabled = false;
        }
      });

      invoiceFileInput.addEventListener("change", () => {
        const hasFile = Boolean(invoiceFileInput.files?.[0]);
        invoiceFileName.textContent = hasFile ? invoiceFileInput.files[0].name : "Kies een factuur";
        invoiceFileInput.closest(".ap-file-control").classList.toggle("has-file", hasFile);
      });

      wiseCsvFileInput.addEventListener("change", () => {
        const hasFile = Boolean(wiseCsvFileInput.files?.[0]);
        wiseCsvFileName.textContent = hasFile ? wiseCsvFileInput.files[0].name : "Kies Wise export";
        wiseCsvFileInput.closest(".ap-file-control").classList.toggle("has-file", hasFile);
      });

      document.getElementById("financeInvoiceFilters").addEventListener("click", (event) => {
        const button = event.target.closest("button[data-filter]");
        if (!button) return;
        state.financeFilter = button.dataset.filter;
        document.querySelectorAll("#financeInvoiceFilters button").forEach((item) => item.classList.remove("is-active"));
        button.classList.add("is-active");
        renderInvoiceForecast();
      });

      financeMatchList.addEventListener("click", async (event) => {
        const button = event.target.closest("button[data-match-action]");
        if (!button) return;
        button.disabled = true;
        try {
          const status = button.dataset.matchAction;
          const matchId = button.dataset.matchId;
          const match = state.data?.os?.finance?.financeMatching?.matches?.find((item) => item.id === matchId);
          await api(`/api/finance/matches/${encodeURIComponent(matchId)}`, {
            method: "POST",
            body: JSON.stringify({
              status,
              targetId: match?.targetId || "",
              targetType: match?.targetType || "",
              category: match?.category || "",
              spendType: match?.spendType || ""
            })
          });
          await loadDashboard();
        } catch (error) {
          financeMatchStatus.textContent = error.message;
        } finally {
          button.disabled = false;
        }
      });

      invoiceUploadForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        invoiceUploadMessage.classList.remove("is-visible");
        invoiceUploadMessage.textContent = "";
        const formData = new FormData(invoiceUploadForm);
        try {
          const response = await fetch("/api/finance/invoices/upload", {
            method: "POST",
            credentials: "same-origin",
            body: formData
          });
          const data = await response.json();
          if (!response.ok) throw new Error(data.error || "Upload mislukt.");
          invoiceUploadForm.reset();
          invoiceFileName.textContent = "Kies een factuur";
          invoiceFileInput.closest(".ap-file-control").classList.remove("has-file");
          invoiceUploadMessage.textContent = `Factuur opgeslagen: ${data.invoice.originalName}`;
          invoiceUploadMessage.classList.add("is-visible");
          await loadDashboard();
        } catch (error) {
          invoiceUploadMessage.textContent = error.message;
          invoiceUploadMessage.classList.add("is-visible");
        }
      });

      wiseCsvUploadForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        wiseCsvUploadMessage.classList.remove("is-visible");
        wiseCsvUploadMessage.textContent = "";
        const formData = new FormData(wiseCsvUploadForm);
        try {
          const response = await fetch("/api/integrations/wise/csv-upload", {
            method: "POST",
            credentials: "same-origin",
            body: formData
          });
          const data = await response.json();
          if (!response.ok) throw new Error(data.error || "Wise CSV upload mislukt.");
          wiseCsvUploadForm.reset();
          wiseCsvFileName.textContent = "Kies Wise export";
          wiseCsvFileInput.closest(".ap-file-control").classList.remove("has-file");
          wiseCsvUploadMessage.textContent = `${data.count} Wise transacties verwerkt. Totaal in feed: ${data.total}.`;
          wiseCsvUploadMessage.classList.add("is-visible");
          await loadDashboard();
        } catch (error) {
          wiseCsvUploadMessage.textContent = error.message;
          wiseCsvUploadMessage.classList.add("is-visible");
        }
      });

      document.getElementById("nav").addEventListener("click", (event) => {
        const button = event.target.closest("button[data-module]");
        if (!button) return;
        setActiveModule(button.dataset.module);
        closeMobileMenu();
      });

      subnav.addEventListener("click", (event) => {
        const button = event.target.closest("button[data-target]");
        if (!button) return;
        showSubsection(button.dataset.target);
        document.querySelectorAll("#ap-sales-dashboard .ap-subnav button").forEach((item) => item.classList.remove("is-active"));
        button.classList.add("is-active");
      });

      document.getElementById("sidebarToggle").addEventListener("click", () => appView.classList.toggle("is-menu-open"));
      document.getElementById("mobileBackdrop").addEventListener("click", closeMobileMenu);

      searchInput.addEventListener("input", () => {
        state.query = searchInput.value.trim().toLowerCase();
        renderCalls();
      });
    }

    async function handleLoginSubmit(event) {
      if (event) event.preventDefault();
      loginError.classList.remove("is-visible");
      const form = new FormData(loginForm);
      try {
        const response = await api("/api/login", {
          method: "POST",
          body: JSON.stringify({ email: form.get("email"), password: form.get("password") })
        });
        state.viewer = response.user;
        await loadDashboard();
        showApp();
      } catch (error) {
        loginError.textContent = error.message;
        loginError.classList.add("is-visible");
      }
      return false;
    }

    function setActiveModule(module, targetId) {
      const menu = sectionMenu[module] || sectionMenu.command;
      const firstTarget = targetId || menu.items[0][1];
      state.activeModule = module;
      document.querySelectorAll("#ap-sales-dashboard .ap-nav button").forEach((item) => item.classList.toggle("is-active", item.dataset.module === module));
      renderSubnav(firstTarget);
      showSubsection(firstTarget, false);
    }

    function showSubsection(targetId, shouldScroll = true) {
      const target = document.getElementById(targetId);
      if (!target) return;
      const sectionNode = target.classList.contains("ap-section") ? target : target.closest(".ap-section");
      if (!sectionNode) return;
      state.activeSection = sectionNode.id.replace("section-", "");
      document.querySelectorAll("#ap-sales-dashboard .ap-section").forEach((item) => item.classList.remove("is-active"));
      sectionNode.classList.add("is-active");
      if (shouldScroll) scrollToSubsection(targetId);
    }

    function renderSubnav(activeTarget) {
      const menu = sectionMenu[state.activeModule] || sectionMenu.command;
      mainTitle.textContent = menu.title;
      const visibleItems = menu.items.filter(([, , role]) => !role || state.viewer?.role === "admin" || state.viewer?.role === role);
      subnav.innerHTML = visibleItems.map(([label, target], index) => `
        <button type="button" class="${activeTarget ? target === activeTarget ? "is-active" : "" : index === 0 ? "is-active" : ""}" data-target="${target}">${label}</button>
      `).join("");
    }

    function closeMobileMenu() {
      appView.classList.remove("is-menu-open");
    }

    function scrollToSubsection(targetId) {
      const target = document.getElementById(targetId);
      if (!target) return;
      const top = target.getBoundingClientRect().top + window.scrollY - 18;
      window.scrollTo({ top: Math.max(0, top), behavior: "smooth" });
    }

    async function loadDashboard() {
      state.data = await api("/api/dashboard");
      state.viewer = state.data.viewer;
      render();
    }

    function render() {
      const data = state.data;
      viewerName.textContent = state.viewer.name;
      viewerLabel.textContent = roleLabel(state.viewer.role);
      viewerAvatar.textContent = state.viewer.name.split(/\s+/).map((part) => part[0]).join("").slice(0, 2).toUpperCase();
      syncLabel.textContent = data.rawSync.mode === "live"
        ? `${t("liveSync")} ${time(data.rawSync.syncedAt)}`
        : data.rawSync.mode === "ghl_error"
          ? `GHL niet live - ${data.rawSync.error || "controleer token en scopes"}`
          : t("demoSync");

      renderSubnav();
      renderOperatingSystem();

      totalStats.innerHTML = [
        stat(t("callsToday"), data.totals.callsToday),
        stat(t("callsWeek"), data.totals.callsWeek),
        stat(t("answeredCalls"), data.totals.answeredCalls),
        stat(t("bingos"), data.totals.bingos),
        stat(t("callMinutes"), data.totals.callMinutes),
        stat(t("noShows"), data.totals.noShows),
        stat(t("bingosPerHour"), data.totals.bingosPerHour),
        stat(t("conversationsPerBingo"), data.totals.conversationsPerBingo)
      ].join("");

      const stages = [
        ["Ready to call", "readyToCall"],
        ["Called", "called"],
        ["Follow up", "followUp"],
        ["Nope not today", "nopeNotToday"],
        ["BINGO", "bingo"]
      ];
      pipeline.innerHTML = stages.map(([label, key]) => `
        <div class="ap-stage">
          <strong>${label}</strong>
          <span class="ap-number">${format(data.opportunityStageTotals[key] || 0)}</span>
          <p class="ap-muted">${t("opportunitiesInStage")}</p>
        </div>
      `).join("");

      document.getElementById("callsPerBingo").textContent = `${format(data.totals.callsPerBingo)} ${t("callsPerBingo")}`;
      document.getElementById("nopeRatio").textContent = `${format(data.totals.nopePerBingo)} ${t("nopePerBingo")}`;
      document.getElementById("bingoProgress").style.width = `${Math.max(12, Math.min(100, 100 - data.totals.callsPerBingo))}%`;
      document.getElementById("nopeProgress").style.width = `${Math.max(12, Math.min(100, data.totals.nopePerBingo * 45))}%`;

      document.querySelector("#section-setters thead").innerHTML = `<tr><th>${t("setter")}</th><th>${t("callMinutesShort")}</th><th>${t("callsTodayShort")}</th><th>${t("callsWeekShort")}</th><th>${t("conversations")}</th><th>${t("noShows")}</th><th>${t("bingos")}</th><th>${t("callsBingo")}</th><th>${t("bingoHour")}</th></tr>`;
      document.querySelector("#section-closers thead").innerHTML = `<tr><th>${t("closer")}</th><th>${t("callMinutesShort")}</th><th>${t("showed")}</th><th>${t("meetings")}</th><th>${t("won")}</th><th>${t("lost")}</th><th>${t("daysToWon")}</th><th>Closing %</th></tr>`;

      settersTable.innerHTML = rowOrEmpty(data.setters, (setter) => `
        <tr>
          <td>${setter.name}</td><td>${format(setter.callMinutes)} ${t("minute")}</td><td>${format(setter.callsToday)}</td><td>${format(setter.callsWeek)}</td><td>${format(setter.answeredCalls)}</td><td>${format(setter.noShows)}</td><td>${format(setter.bingos)}</td><td>${format(setter.callsPerBingo)}</td><td>${format(setter.bingosPerHour)}</td>
        </tr>
      `);

      closersTable.innerHTML = rowOrEmpty(data.closers, (closer) => `
        <tr>
          <td>${closer.name}</td><td>${format(closer.callMinutes)} ${t("minute")}</td><td>${format(closer.showed)}</td><td>${format(closer.meetings)}</td><td>${format(closer.won)}</td><td>${format(closer.lost)}</td><td>${format(closer.avgDaysToClose)}</td><td>${format(closer.closeRate)}%</td>
        </tr>
      `);

      renderCalls();
      applyRoleNav();
    }

    function renderOperatingSystem() {
      const os = state.data.os || {};
      const ceo = os.ceo;

      if (ceo) {
        ceoStats.innerHTML = [
          stat("Cashpositie", money(ceo.cashPosition)),
          stat("Openstaande facturen", money(ceo.openInvoices)),
          stat("MRR", money(ceo.mrr)),
          stat("Sales deze maand", money(ceo.newSalesThisMonth)),
          stat("Pipeline forecast", money(ceo.pipelineForecast)),
          stat("Gem. brutomarge", `${format(ceo.averageGrossMargin)}%`),
          stat("Delivery risico's", ceo.deliveryRisks),
          stat("Klant health", `${ceo.customerHealth.green}/${ceo.customerHealth.orange}/${ceo.customerHealth.red}`)
        ].join("");
        const customerRisks = (os.customers || [])
          .filter((customer) => customer.health !== "green")
          .map((customer) => ({ title: customer.name, detail: `${customer.deliveryRisk} risico - ${customer.nextMilestone}` }));
        ceoRisks.innerHTML = customerRisks.length
          ? customerRisks.map((item) => listItem(item.title, item.detail)).join("")
          : listItem("Geen kritieke klantrisico's", "Alle actieve klanten staan momenteel op groen.");

        const financeActions = (os.finance?.reviewItems || []).map((item) => ({
          title: `${item.type} controleren`,
          detail: `${item.source}: ${item.suggestion}`
        }));
        const integrationActions = (os.integrations || [])
          .filter((item) => !["live", "connected", "ok", "actief"].includes(String(item.status).toLowerCase()))
          .map((item) => ({ title: `${item.name} koppeling`, detail: item.detail || `Status: ${item.status}` }));
        const actionQueue = [...financeActions, ...customerRisks, ...integrationActions].slice(0, 5);
        ceoDecisions.innerHTML = actionQueue.length
          ? actionQueue.map((item) => listItem(item.title, item.detail)).join("")
          : listItem("Geen urgente acties", "De belangrijkste controles zijn bijgewerkt.");
      } else {
        ceoStats.innerHTML = stat("Beperkte toegang", "Sales");
        ceoRisks.innerHTML = listItem("Rolrechten actief", "Management- en financecijfers zijn verborgen voor deze rol.");
        ceoDecisions.innerHTML = listItem("Persoonlijke werkruimte", "Gebruik Sales voor je actuele funnel en prestaties.");
      }

      customersTable.innerHTML = rowOrEmpty(os.customers, (customer) => `
        <tr>
          <td>${customer.name}</td>
          <td>${customer.domain}</td>
          <td>${customer.stage}</td>
          <td><span class="ap-health ap-health-${customer.health}"></span></td>
          <td>${customer.mrr === undefined ? "-" : money(customer.mrr)}</td>
          <td>${customer.grossMargin === undefined ? "-" : `${format(customer.grossMargin)}%`}</td>
          <td>${customer.openInvoices === undefined ? "-" : money(customer.openInvoices)}</td>
          <td>${customer.nextMilestone}</td>
        </tr>
      `);

      if (os.finance) {
        financeStats.innerHTML = [
          stat("Betaald ontvangen", money(os.finance.paidInvoices), "in"),
          stat("Nog te ontvangen", money(os.finance.forecastOpen), "in"),
          stat("Te ontvangen 7 dagen", money(os.finance.forecast7Days), "in"),
          stat("Te ontvangen 30 dagen", money(os.finance.forecast30Days), "in"),
          stat("Te laat", money(os.finance.overdueInvoices), "danger"),
          stat("Te betalen 7 dagen", money(os.finance.payable7Days), "out"),
          stat("Te betalen 30 dagen", money(os.finance.payable30Days), "out"),
          stat("Verwachte cash 30d", money(os.finance.expectedCash30), "neutral"),
          stat("Zakelijk week", money(os.finance.weeklyBusinessSpend), "out"),
          stat("Prive week", money(os.finance.weeklyPrivateSpend), "out"),
          stat("Gemengd week", money(os.finance.weeklyMixedSpend), "out"),
          stat("Verschil zakelijk/prive", money(os.finance.businessVsPrivateDifference), "neutral")
        ].join("");
        financeReview.innerHTML = os.finance.reviewItems.map((item) => (
          listItem(`${item.type} - ${item.confidence}%`, `${item.source}: ${item.suggestion}. Actie: ${item.action}`)
        )).join("");
        renderFinanceMatching();
        renderWiseTransactions();
        renderCashflowForecast();
        renderUsageCosts();
        renderInvoiceForecast();
        subscriptionsList.innerHTML = os.finance.subscriptions.map((item) => (
          listItem(`${item.name} - ${money(item.monthlyCost)}/mnd`, `${item.type} - ${item.split} - ${item.score}`)
        )).join("");
        automaticInvoiceSources.innerHTML = os.finance.automaticSources.map((source) => (
          listItem(`${source.name} - ${source.status}`, source.detail)
        )).join("");
        uploadedInvoicesList.innerHTML = os.finance.uploadedInvoices.length
          ? os.finance.uploadedInvoices.map((invoice) => (
            listItem(
              `${invoice.vendorName} - ${money(invoice.amount)}`,
              `${escapeHtml(invoice.originalName)} - ${escapeHtml(invoice.spendType)} - ${escapeHtml(invoice.category)} - ${new Date(invoice.uploadedAt).toLocaleDateString("nl-NL")} - <a href="${invoice.downloadUrl}">download</a>`,
              true
            )
          )).join("")
          : listItem("Nog geen uploads", "Upload hier handmatig facturen die nog niet via Gmail of Wise binnenkomen.");
      }

      deliveryList.innerHTML = (os.delivery?.milestones || []).map((item) => `
        <div class="ap-list-item">
          <strong>${item.customer} - ${item.phase}</strong>
          <span>${item.owner} - risico ${item.risk} - volgende stap: ${item.next}</span>
          <div class="ap-meter"><span style="width:${Math.max(5, Math.min(100, item.progress))}%"></span></div>
        </div>
      `).join("");

      if (os.operations) {
        operationsStats.innerHTML = [
          stat("Incomplete dossiers", os.operations.incompleteDossiers),
          stat("Missende contracten", os.operations.missingContracts),
          stat("Stille klanten", os.operations.staleCustomers)
        ].join("");
        operationsTimeline.innerHTML = os.operations.timeline.map((item) => (
          listItem(`${item.customer} - ${item.type}`, `${item.date}: ${item.detail}`)
        )).join("");
      }

      if (os.marketing) {
        marketingStats.innerHTML = [
          stat("Bereik vandaag", os.marketing.reachToday),
          stat("Bereik week", os.marketing.reachWeek),
          stat("Groei", `${format(os.marketing.growth)}%`),
          stat("Leads", os.marketing.leads)
        ].join("");
        topPosts.innerHTML = os.marketing.topPosts.map((post) => (
          listItem(`${post.channel} - score ${post.score}`, `${post.account}: ${post.title}`)
        )).join("");
      }

      if (os.teamOps) {
        teamStats.innerHTML = [
          stat("Teamleden", os.teamOps.activeMembers),
          stat("Capaciteit", `${format(os.teamOps.capacityUsed)}%`),
          stat("Late taken", os.teamOps.lateTasks),
          stat("Freelancers onboarding", os.teamOps.freelancersInOnboarding)
        ].join("");
        teamTable.innerHTML = rowOrEmpty(os.teamOps.members, (member) => `
          <tr><td>${member.name}</td><td>${roleLabel(member.role)}</td><td>${member.clickupActivity}%</td><td>${member.ghlActivity}%</td><td>${member.risk}</td></tr>
        `);
      }

      integrationsList.innerHTML = (os.integrations || []).map((item) => (
        listItem(item.name, `${item.status} - eigenaar: ${item.owner}${item.detail ? ` - ${item.detail}` : ""}`)
      )).join("");
      renderGhlStatus();
    }

    function renderGhlStatus() {
      const raw = state.data?.rawSync || {};
      const datasets = raw.datasets || {};
      const entries = Object.entries(datasets);
      const okCount = entries.filter(([, item]) => item.ok).length;
      const total = entries.length;
      ghlStatusChip.textContent = raw.mode === "live" ? "Live" : raw.mode === "ghl_error" ? "Actie nodig" : "Demo";
      ghlDatasetStats.innerHTML = [
        stat("Datasets live", `${okCount}/${total || 0}`, raw.mode === "live" ? "in" : "danger"),
        stat("Opportunities", raw.opportunities || 0, "neutral"),
        stat("Contacts", raw.contacts || 0, "neutral"),
        stat("Calls/events", Number(raw.voiceCallLogs || 0) + Number(raw.calendarEvents || 0), "neutral")
      ].join("");
      ghlDatasetList.innerHTML = entries.length ? entries.map(([label, item]) => (
        listItem(
          `${datasetLabel(label)} - ${item.ok ? "OK" : "Fout"}`,
          item.ok ? `${item.count} records opgehaald` : item.error || `Status ${item.status || "onbekend"}`
        )
      )).join("") : listItem("Geen GHL datasets", raw.error || "Vul een geldige GHL Private Integration token in.");
    }

    function renderWiseTransactions() {
      const transactions = state.data?.os?.finance?.wiseTransactions || [];
      const visible = transactions.filter((transaction) => transaction.direction === "outgoing" || transaction.direction === "incoming").slice(0, 8);
      wiseTransactionsList.innerHTML = visible.length ? visible.map((transaction) => {
        const label = transaction.spendType === "private" ? "Prive" : "Zakelijk";
        const sign = transaction.direction === "incoming" ? "+" : "-";
        const amountClass = transaction.direction === "incoming" ? "ap-money-in" : "ap-money-out";
        return `<div class="ap-list-item">
          <strong>${escapeHtml(label)} - ${escapeHtml(transaction.description)}</strong>
          <span><span class="${amountClass}">${sign} ${money(transaction.amount)}</span> - ${dateLabel(transaction.date)} - ${escapeHtml(transaction.currency)}</span>
        </div>`;
      }).join("") : listItem("Nog geen Wise transacties", "Ga naar Koppelingen en klik Wise transacties synchroniseren.");
    }

    function renderFinanceMatching() {
      const matching = state.data?.os?.finance?.financeMatching || { summary: {}, reviewQueue: [] };
      const summary = matching.summary || {};
      financeMatchStatus.textContent = `${summary.needsReview || 0} review - ${summary.missingDocument || 0} mist document`;
      financeMatchStats.innerHTML = [
        stat("Automatisch", summary.autoMatched || 0, "in"),
        stat("Review nodig", summary.needsReview || 0, "neutral"),
        stat("Mist document", summary.missingDocument || 0, "danger")
      ].join("");

      const queue = matching.reviewQueue || [];
      financeMatchList.innerHTML = queue.length ? queue.slice(0, 8).map((match) => {
        const sign = match.direction === "incoming" ? "+" : "-";
        const moneyClass = match.direction === "incoming" ? "ap-money-in" : "ap-money-out";
        const primaryAction = match.status === "ignored" ? "open" : "approved";
        const primaryLabel = match.status === "ignored" ? "Heropenen" : "Goedkeuren";
        const ignoreButton = match.status === "ignored" ? "" : `<button class="ap-button ap-button-secondary ap-button-small" type="button" data-match-action="ignored" data-match-id="${escapeHtml(match.id)}">Negeren</button>`;
        return `<div class="ap-list-item ap-match-item">
          <div class="ap-match-top">
            <div>
              <strong>${escapeHtml(match.description)}</strong>
              <span>${escapeHtml(match.suggestion)}</span>
            </div>
            <span class="ap-chip">${format(match.confidence)}%</span>
          </div>
          <div class="ap-match-meta">
            <span class="${moneyClass}">${sign} ${money(match.amount)}</span>
            <span>${dateLabel(match.transactionDate)}</span>
            <span>${escapeHtml(match.category)}</span>
            <span>${matchStatusLabel(match.status)}</span>
          </div>
          <span>${escapeHtml((match.reasons || []).join(" + "))}</span>
          <div class="ap-match-actions">
            <button class="ap-button ap-button-primary ap-button-small" type="button" data-match-action="${primaryAction}" data-match-id="${escapeHtml(match.id)}">${primaryLabel}</button>
            ${ignoreButton}
          </div>
        </div>`;
      }).join("") : listItem("Geen review nodig", "Alle beschikbare Wise transacties zijn gekoppeld of er zijn nog geen transacties ingeladen.");
    }

    function renderUsageCosts() {
      const usage = state.data?.os?.finance?.usageCosts || { agents: [], totals: {} };
      const totals = usage.totals || {};
      usageCostStatus.textContent = usage.syncedAt ? `Bijgewerkt ${dateLabel(usage.syncedAt)}` : "Demo model";
      usageCostStats.innerHTML = [
        stat("Alle minuten", format(totals.minutes || 0), "neutral"),
        stat("Gem. kosten/min", moneyPrecise(totals.averageCostPerMinute || 0), "out"),
        stat("Voice totaal", money(totals.voiceCost || 0), "out"),
        stat("SMS totaal", `${format(totals.smsCount || 0)} - ${money(totals.smsCost || 0)}`, "out")
      ].join("");
      usageCostTable.innerHTML = (usage.agents || []).length ? usage.agents.map((agent) => `
        <tr>
          <td>${escapeHtml(agent.agentName)}</td>
          <td>${escapeHtml(agent.customer)}</td>
          <td>${format(agent.minutes)}</td>
          <td>${moneyPrecise(agent.averageCostPerMinute)}</td>
          <td>${money(agent.voiceCost)}</td>
          <td>${format(agent.smsCount)}</td>
          <td>${moneyPrecise(agent.costPerSms)}</td>
          <td>${money(agent.smsCost)}</td>
          <td class="ap-money-strong">${money(agent.totalCost)}</td>
        </tr>
      `).join("") : `<tr><td colspan="9">Nog geen AI usage data beschikbaar.</td></tr>`;
    }

    function renderCashflowForecast() {
      const rows = state.data?.os?.finance?.cashflowForecast || [];
      cashflowForecastTable.innerHTML = rows.length ? rows.map((row) => `
        <tr>
          <td>${escapeHtml(row.period)}</td>
          <td class="ap-money-strong">${money(row.startingCash)}</td>
          <td class="ap-money-in">+ ${money(row.incoming)}</td>
          <td class="ap-money-out">- ${money(row.businessOutgoing)}</td>
          <td class="ap-money-out">- ${money(row.privateOutgoing)}</td>
          <td class="ap-money-out">- ${money(row.mixedOutgoing)}</td>
          <td class="${row.netMovement < 0 ? "ap-money-danger" : "ap-money-in"}">${signedMoney(row.netMovement)}</td>
          <td class="ap-money-strong">${money(row.endingCash)}</td>
        </tr>
      `).join("") : `<tr><td colspan="8">Nog geen cashflow forecast beschikbaar.</td></tr>`;
    }

    function renderInvoiceForecast() {
      const invoices = state.data?.os?.finance?.invoiceForecast || [];
      const filtered = invoices.filter((invoice) => {
        if (state.financeFilter === "all") return true;
        if (state.financeFilter === "forecast") return !invoice.paidAt && daysBetween(new Date(), invoice.expectedPaymentAt) <= 30;
        return invoice.status === state.financeFilter;
      });
      const total = filtered.reduce((sum, invoice) => sum + Number(invoice.amount || 0), 0);
      financeForecastTotal.textContent = `${filtered.length} facturen - ${money(total)}`;
      invoiceForecastTable.innerHTML = filtered.length ? filtered.map((invoice) => `
        <tr>
          <td>${escapeHtml(invoice.invoiceNumber)}<br><span class="ap-muted">${escapeHtml(invoice.type)}</span></td>
          <td>${escapeHtml(invoice.customer)}</td>
          <td>${money(invoice.amount)}</td>
          <td><span class="ap-chip">${invoiceStatusLabel(invoice.status)}</span></td>
          <td>${dateLabel(invoice.dueAt)}</td>
          <td>${invoice.paidAt ? `Betaald op ${dateLabel(invoice.paidAt)}` : dateLabel(invoice.expectedPaymentAt)}</td>
        </tr>
      `).join("") : `<tr><td colspan="6">Geen facturen voor deze filter.</td></tr>`;
    }

    function renderCalls() {
      const calls = (state.data.calls || []).filter((call) => {
        const haystack = `${call.owner} ${call.contact} ${call.result} ${call.transcript}`.toLowerCase();
        return !state.query || haystack.includes(state.query);
      });

      callList.innerHTML = calls.length ? calls.map((call) => `
        <article class="ap-call">
          <div>
            <h3>${call.contact}</h3>
            <p class="ap-muted">${call.owner} - ${call.date} - ${call.duration} - ${call.result}</p>
            <p class="ap-transcript">${call.transcript}</p>
          </div>
          <div>
            <span class="ap-score">${call.score}</span>
            <button class="ap-button ap-button-secondary ap-full" style="margin-top:10px" type="button" onclick="scoreCall('${call.id}')">${t("aiScore")}</button>
          </div>
          <div class="ap-coach" id="coach-${call.id}"></div>
        </article>
      `).join("") : `<p class="ap-muted">${t("noCalls")}</p>`;
    }

    async function scoreCall(id) {
      const coach = document.getElementById(`coach-${id}`);
      coach.classList.add("is-open");
      coach.innerHTML = `<p class="ap-muted">${t("loadingCoach")}</p>`;
      const response = await api(`/api/calls/${id}/score`, { method: "POST" });
      coach.innerHTML = `
        <strong>${t("aiScore")}: ${response.score.total}</strong>
        <p class="ap-muted"><strong>${t("missed")}:</strong> ${coachCopy(response.score).missedMoment}</p>
        <div><strong>${t("wentWell")}</strong><ul>${coachCopy(response.score).wentWell.map((item) => `<li>${item}</li>`).join("")}</ul></div>
        <div><strong>${t("couldImprove")}</strong><ul>${coachCopy(response.score).couldImprove.map((item) => `<li>${item}</li>`).join("")}</ul></div>
      `;
    }

    function applyRoleNav() {
      const adminOnlyButtons = document.querySelectorAll("[data-admin-only='true']");
      adminOnlyButtons.forEach((button) => button.classList.toggle("ap-hidden", state.viewer.role !== "admin"));
      const active = document.querySelector("#ap-sales-dashboard .ap-nav button.is-active");
      if (active && active.classList.contains("ap-hidden")) {
        setActiveModule("command");
      }
    }

    function showApp() {
      loginView.classList.add("ap-hidden");
      appView.classList.remove("ap-hidden");
      setActiveModule(state.activeModule);
      if (window.lucide) window.lucide.createIcons();
    }

    function showLogin() {
      appView.classList.add("ap-hidden");
      loginView.classList.remove("ap-hidden");
    }

    function stat(label, value, variant = "neutral") {
      return `<div class="ap-card ap-stat ap-stat-${variant}"><small>${label}</small><span class="ap-number">${format(value)}</span></div>`;
    }

    function rowOrEmpty(items, renderItem) {
      return items && items.length ? items.map(renderItem).join("") : `<tr><td colspan="9">${t("noRoleData")}</td></tr>`;
    }

    function listItem(title, detail, detailIsHtml = false) {
      return `<div class="ap-list-item"><strong>${escapeHtml(title)}</strong><span>${detailIsHtml ? detail : escapeHtml(detail)}</span></div>`;
    }

    function escapeHtml(value) {
      return String(value ?? "").replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
      }[char]));
    }

    function format(value) {
      const formatter = new Intl.NumberFormat(state.lang === "nl" ? "nl-NL" : "en-US", { maximumFractionDigits: 1 });
      return typeof value === "number" ? formatter.format(value) : value;
    }

    function money(value) {
      return new Intl.NumberFormat("nl-NL", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(Number(value || 0));
    }

    function moneyPrecise(value) {
      return new Intl.NumberFormat("nl-NL", { style: "currency", currency: "EUR", minimumFractionDigits: 3, maximumFractionDigits: 4 }).format(Number(value || 0));
    }

    function signedMoney(value) {
      const amount = Number(value || 0);
      return `${amount >= 0 ? "+" : "-"} ${money(Math.abs(amount))}`;
    }

    function dateLabel(value) {
      if (!value) return "-";
      return localDate(value).toLocaleDateString("nl-NL", { day: "2-digit", month: "short", year: "numeric" });
    }

    function daysBetween(start, end) {
      const startDate = start instanceof Date ? new Date(start) : localDate(start);
      const endDate = end instanceof Date ? new Date(end) : localDate(end);
      startDate.setHours(0, 0, 0, 0);
      endDate.setHours(0, 0, 0, 0);
      return Math.ceil((endDate.getTime() - startDate.getTime()) / 86400000);
    }

    function localDate(value) {
      if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
        const [year, month, day] = value.split("-").map(Number);
        return new Date(year, month - 1, day);
      }
      return new Date(value);
    }

    function invoiceStatusLabel(status) {
      return {
        paid: "Betaald",
        open: "Openstaand",
        overdue: "Te laat",
        draft: "Concept",
        forecast: "Aankomend"
      }[status] || status;
    }

    function matchStatusLabel(status) {
      return {
        approved: "Gekoppeld",
        changed: "Aangepast",
        ignored: "Genegeerd",
        review: "Review",
        missing_document: "Mist document"
      }[status] || status;
    }

    function datasetLabel(label) {
      return {
        opportunities: "Opportunities",
        conversations: "Conversations",
        contacts: "Contacts",
        pipelines: "Pipelines",
        users: "Users",
        calendars: "Calendars",
        voiceCallLogs: "Voice logs",
        calendarEvents: "Calendar events"
      }[label] || label;
    }

    function time(value) {
      return new Date(value).toLocaleTimeString("nl-NL", { hour: "2-digit", minute: "2-digit" });
    }

    function roleLabel(role) {
      return role === "admin" ? t("management") : role;
    }

    function t(key) {
      return (i18n[state.lang] && i18n[state.lang][key]) || i18n.nl[key] || key;
    }

    function setLanguage(lang) {
      state.lang = lang === "en" ? "en" : "nl";
      localStorage.setItem("apSalesLang", state.lang);
      loginLanguage.value = state.lang;
      languageSelect.value = state.lang;
      document.documentElement.lang = state.lang;
      document.querySelectorAll("[data-i18n]").forEach((node) => {
        node.textContent = t(node.dataset.i18n);
      });
      searchInput.placeholder = t("searchPlaceholder");
      searchInput.setAttribute("aria-label", t("searchPlaceholder"));
      syncLabel.textContent = t("loading");
      if (state.data) render();
      else renderSubnav();
    }

    function coachCopy(score) {
      if (state.lang === "nl") return score;
      return {
        missedMoment: score.missedMoment.includes("twijfel")
          ? "The lead showed doubt; a short value reframe could have helped here."
          : "There was room to ask deeper questions about the decision criteria.",
        wentWell: [
          "The opening was clear and calm.",
          "The lead had enough room to explain the problem.",
          "The setter kept the conversation structured and moved toward a clear next step."
        ],
        couldImprove: [
          "Make the pain and urgency concrete earlier.",
          "Summarize more often before moving to the next question.",
          "End with a sharper next step and confirm commitment."
        ]
      };
    }

    async function api(url, options = {}) {
      let response;
      try {
        response = await fetch(url, {
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          ...options
        });
      } catch (error) {
        throw new Error("Kan de backend niet bereiken. Open http://127.0.0.1:4173 en probeer opnieuw.");
      }
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Request mislukt.");
      return data;
    }

    window.scoreCall = scoreCall;
    window.apHandleLogin = handleLoginSubmit;
    setLanguage(state.lang);
    renderSubnav();
  
