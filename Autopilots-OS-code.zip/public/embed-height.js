(function () {
  var marker = "ap-embed-height-sync-2026-06-12";
  if (window[marker]) return;
  window[marker] = true;

  function elementBottom(el) {
    if (!el || !el.getBoundingClientRect) return 0;
    var tag = (el.tagName || "").toUpperCase();
    if (/^(SCRIPT|STYLE|LINK|META|NOSCRIPT)$/.test(tag)) return 0;
    var style = window.getComputedStyle(el);
    if (style.position === "fixed" || style.display === "none") return 0;
    var rect = el.getBoundingClientRect();
    if (!rect.height) return 0;
    return rect.bottom + (window.pageYOffset || document.documentElement.scrollTop || 0);
  }

  function getHeight() {
    var body = document.body;
    var candidates = [];
    var roots = document.querySelectorAll('#ap-property, #ap-home, #ap-crm-landing, #ap-leadsmachine-ai, #ap-thankyou, .ap-agent, main');

    Array.prototype.forEach.call(roots, function (root) {
      candidates.push(elementBottom(root));
    });

    if (body) {
      Array.prototype.forEach.call(body.children, function (child) {
        candidates.push(elementBottom(child));
      });
    }

    var measured = Math.max.apply(Math, candidates.filter(function (value) {
      return Number.isFinite(value) && value > 0;
    }));

    if (!Number.isFinite(measured) || measured < 400) {
      measured = body ? Math.max(body.scrollHeight || 0, body.offsetHeight || 0, 800) : 800;
    }

    return Math.ceil(measured + 24);
  }

  function syncHeight() {
    if (!window.parent || window.parent === window) return;
    window.parent.postMessage({
      type: "autopilots:embed-height",
      height: getHeight(),
      path: window.location.pathname
    }, "*");
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", syncHeight);
  } else {
    syncHeight();
  }

  window.addEventListener("load", syncHeight);
  window.addEventListener("resize", syncHeight);
  setTimeout(syncHeight, 250);
  setTimeout(syncHeight, 1000);
  setTimeout(syncHeight, 2500);

  if ("ResizeObserver" in window && document.body) {
    new ResizeObserver(syncHeight).observe(document.body);
  }

  if ("MutationObserver" in window) {
    new MutationObserver(syncHeight).observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true
    });
  }
})();

