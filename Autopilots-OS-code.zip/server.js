const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { CLOSER_STAGES, COUNTED_CALENDARS, SETTER_STAGES, TEAM } = require("./config");

const ROOT = __dirname;
const PUBLIC = fs.existsSync(path.join(ROOT, "public")) ? path.join(ROOT, "public") : ROOT;
const ENV = loadEnv(path.join(ROOT, ".env"));
const PORT = Number(process.env.PORT || ENV.PORT || 4173);
const DEFAULT_HOST = process.env.NODE_ENV === "production" ? "0.0.0.0" : "127.0.0.1";
const HOST = process.env.HOST || ENV.HOST || DEFAULT_HOST;
const DATA_DIR = path.join(ROOT, "data");
const INVOICE_UPLOAD_DIR = path.join(DATA_DIR, "invoice-uploads");
const INVOICE_INDEX_FILE = path.join(INVOICE_UPLOAD_DIR, "index.json");
const STRIPE_SYNC_FILE = path.join(DATA_DIR, "stripe-invoices.json");
const WISE_SYNC_FILE = path.join(DATA_DIR, "wise-transactions.json");
const FINANCE_MATCH_FILE = path.join(DATA_DIR, "finance-matches.json");
const GHL_SYNC_FILE = path.join(DATA_DIR, "ghl-live-data.json");
const USAGE_COST_FILE = path.join(DATA_DIR, "ai-usage-costs.json");
const AUDIT_LOG_FILE = path.join(DATA_DIR, "audit-log.json");
const INTEGRATION_HEALTH_FILE = path.join(DATA_DIR, "integration-health.json");
const GHL_CACHE_TTL_MS = 10 * 60 * 1000;
const GHL_DASHBOARD_PAGE_LIMIT = 25;
const IS_PRODUCTION = process.env.NODE_ENV === "production";
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_MAX_ATTEMPTS = Number(process.env.LOGIN_MAX_ATTEMPTS || ENV.LOGIN_MAX_ATTEMPTS || 8);
const LOCATION_ID = process.env.GHL_LOCATION_ID || ENV.GHL_LOCATION_ID || "fs9MG3kXRVSIiWUig6yv";
const GHL_TOKEN = process.env.GHL_PRIVATE_TOKEN || ENV.GHL_PRIVATE_TOKEN || "";
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || ENV.STRIPE_SECRET_KEY || "";
const WISE_API_TOKEN = process.env.WISE_API_TOKEN || ENV.WISE_API_TOKEN || "";
const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY || ENV.ELEVENLABS_API_KEY || "";
const TELNYX_API_KEY = process.env.TELNYX_API_KEY || ENV.TELNYX_API_KEY || "";
const WISE_PROFILE_ID = process.env.WISE_PROFILE_ID || ENV.WISE_PROFILE_ID || "";
const WISE_BUSINESS_PROFILE_ID = process.env.WISE_BUSINESS_PROFILE_ID || ENV.WISE_BUSINESS_PROFILE_ID || WISE_PROFILE_ID || "";
const WISE_PERSONAL_PROFILE_ID = process.env.WISE_PERSONAL_PROFILE_ID || ENV.WISE_PERSONAL_PROFILE_ID || "";
const SUPABASE_URL = process.env.SUPABASE_URL || ENV.SUPABASE_URL || "";
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_PUBLISHABLE_KEY || ENV.SUPABASE_ANON_KEY || ENV.SUPABASE_PUBLISHABLE_KEY || "";
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || ENV.SUPABASE_SERVICE_ROLE_KEY || "";
const DEBUG_TOKEN = process.env.DEBUG_TOKEN || ENV.DEBUG_TOKEN || "";
const SUPABASE_REST_URL = SUPABASE_URL ? `${SUPABASE_URL.replace(/\/$/, "")}/rest/v1` : "";

const sessions = new Map();
const loginAttempts = new Map();
let cachedGhlCompanyId = "";
ensureDir(INVOICE_UPLOAD_DIR);
const users = TEAM.map((member) => ({
  ...member,
  password: process.env[member.passwordEnv] || ENV[member.passwordEnv] || fallbackPassword(member)
}));

const server = http.createServer(async (req, res) => {
  try {
    req.requestId = crypto.randomBytes(8).toString("hex");
    const pathOnly = req.url.split("?")[0];
    if (pathOnly === "/api/login" && req.method === "POST") return login(req, res);
    if (pathOnly === "/api/logout" && req.method === "POST") return logout(req, res);
    if (pathOnly === "/api/me" && req.method === "GET") return me(req, res);
    if (pathOnly === "/api/dashboard" && req.method === "GET") return dashboard(req, res);
    if (pathOnly === "/api/finance/invoices/upload" && req.method === "POST") return uploadFinanceInvoice(req, res);
    if (pathOnly.startsWith("/api/finance/invoices/") && pathOnly.endsWith("/download") && req.method === "GET") return downloadFinanceInvoice(req, res);
    if (pathOnly.startsWith("/api/finance/matches/") && req.method === "POST") return updateFinanceMatch(req, res);
    if (pathOnly === "/api/integrations/stripe/sync" && req.method === "POST") return syncStripeInvoices(req, res);
    if (pathOnly === "/api/integrations/wise/profiles" && req.method === "POST") return findWiseProfiles(req, res);
    if (pathOnly === "/api/integrations/wise/sync" && req.method === "POST") return syncWiseTransactions(req, res);
    if (pathOnly === "/api/integrations/wise/csv-upload" && req.method === "POST") return uploadWiseCsv(req, res);
    if (pathOnly === "/api/integrations/usage/sync" && req.method === "POST") return syncUsageCosts(req, res);
    if (pathOnly === "/api/debug/live-data" && req.method === "GET") return debugLiveData(req, res);
    if (pathOnly === "/health" && req.method === "GET") return health(res);
    if (pathOnly.startsWith("/api/calls/") && pathOnly.endsWith("/score") && req.method === "POST") return scoreCall(req, res);
    return staticFile(req, res);
  } catch (error) {
    logError(req, error);
    const payload = { error: "Er ging iets mis." };
    if (!IS_PRODUCTION) payload.detail = error.message;
    json(res, 500, payload);
  }
});

if (require.main === module) {
  server.listen(PORT, HOST, () => {
    console.log(`Autopilots OS draait op http://${HOST}:${PORT}`);
  });
}

function loadEnv(file) {
  if (!fs.existsSync(file)) return {};
  return fs.readFileSync(file, "utf8").split(/\r?\n/).reduce((acc, line) => {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (match) acc[match[1]] = match[2].trim();
    return acc;
  }, {});
}

async function login(req, res) {
  const body = await bodyJson(req);
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");
  const limitKey = loginLimitKey(req, email);
  if (isLoginBlocked(limitKey)) {
    writeAuditLog({ req, action: "login.blocked", entityType: "user", entityId: email, status: "blocked" });
    return json(res, 429, { error: "Te veel inlogpogingen. Probeer het later opnieuw." });
  }
  const user = users.find((item) => item.email.toLowerCase() === email && item.password === password);
  if (!user) {
    recordFailedLogin(limitKey);
    writeAuditLog({ req, action: "login.failed", entityType: "user", entityId: email, status: "denied" });
    return json(res, 401, { error: "Deze login klopt niet." });
  }
  clearFailedLogin(limitKey);
  const sid = crypto.randomBytes(24).toString("hex");
  sessions.set(sid, { userId: user.id, createdAt: Date.now() });
  res.setHeader("Set-Cookie", sessionCookie(`ap_sales_sid=${sid}; Max-Age=28800`));
  writeAuditLog({ req, actor: user, action: "login.success", entityType: "user", entityId: user.id, status: "success" });
  json(res, 200, { user: publicUser(user) });
}

function logout(req, res) {
  const user = authUser(req);
  const sid = cookie(req, "ap_sales_sid");
  if (sid) sessions.delete(sid);
  res.setHeader("Set-Cookie", sessionCookie("ap_sales_sid=; Max-Age=0"));
  if (user) writeAuditLog({ req, actor: user, action: "logout", entityType: "user", entityId: user.id, status: "success" });
  json(res, 200, { ok: true });
}

function health(res) {
  json(res, 200, {
    ok: true,
    service: "autopilots-os",
    ghlConfigured: Boolean(GHL_TOKEN),
    stripeConfigured: Boolean(STRIPE_SECRET_KEY),
    wiseConfigured: Boolean(WISE_API_TOKEN),
    wiseProfileConfigured: Boolean(WISE_BUSINESS_PROFILE_ID || WISE_PERSONAL_PROFILE_ID),
    wiseBusinessProfileConfigured: Boolean(WISE_BUSINESS_PROFILE_ID),
    wisePersonalProfileConfigured: Boolean(WISE_PERSONAL_PROFILE_ID),
    elevenLabsConfigured: Boolean(ELEVENLABS_API_KEY),
    telnyxConfigured: Boolean(TELNYX_API_KEY),
    supabaseConfigured: Boolean(SUPABASE_URL && ((SUPABASE_SERVICE_ROLE_KEY && !SUPABASE_SERVICE_ROLE_KEY.includes("zet-je")) || (SUPABASE_ANON_KEY && !SUPABASE_ANON_KEY.includes("zet-je")))),
    supabaseWritable: supabaseEnabled(),
    integrationHealth: readIntegrationHealth(),
    timestamp: new Date().toISOString()
  });
}

function me(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  json(res, 200, { user: publicUser(user) });
}

async function dashboard(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  const data = await loadDashboardData();
  json(res, 200, filterForRole(data, user));
}

async function scoreCall(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  const callId = req.url.split("/")[3];
  const data = await loadDashboardData();
  const call = data.calls.find((item) => item.id === callId);
  if (!call) return json(res, 404, { error: "Gesprek niet gevonden." });
  if (user.role === "setter" && call.ownerId !== user.id) return json(res, 403, { error: "Geen toegang tot dit gesprek." });
  json(res, 200, { score: scoreTranscript(call) });
}

async function uploadFinanceInvoice(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  if (user.role !== "admin") return json(res, 403, { error: "Alleen admin kan facturen uploaden." });

  const parsed = await multipartForm(req);
  const file = parsed.files.invoice;
  if (!file || !file.content.length) return json(res, 400, { error: "Upload een factuurbestand." });

  const ext = safeExtension(file.filename);
  const id = `inv-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
  const storedName = `${id}${ext}`;
  const storedPath = path.join(INVOICE_UPLOAD_DIR, storedName);
  fs.writeFileSync(storedPath, file.content);

  const record = {
    id,
    originalName: file.filename || "factuur",
    storedName,
    vendorName: cleanName(parsed.fields.vendorName) || cleanName(file.filename) || "Onbekende leverancier",
    category: cleanName(parsed.fields.category) || "Nog te bepalen",
    spendType: ["business", "private", "mixed", "unknown"].includes(parsed.fields.spendType) ? parsed.fields.spendType : "unknown",
    companyId: cleanName(parsed.fields.companyId),
    amount: Number(parsed.fields.amount || 0),
    status: "needs_review",
    reviewStatus: "open",
    sourceSystem: "manual_upload",
    uploadedBy: user.id,
    uploadedAt: new Date().toISOString(),
    size: file.content.length
  };

  const invoices = readUploadedInvoices();
  invoices.unshift(record);
  writeUploadedInvoices(invoices);
  writeAuditLog({
    req,
    actor: user,
    action: "finance.invoice.uploaded",
    entityType: "uploaded_invoice",
    entityId: id,
    after: publicUploadedInvoice(record),
    status: "success"
  });

  json(res, 201, { invoice: publicUploadedInvoice(record) });
}

function downloadFinanceInvoice(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  if (user.role !== "admin") return json(res, 403, { error: "Alleen admin kan facturen downloaden." });

  const id = req.url.split("/")[4];
  const invoice = readUploadedInvoices().find((item) => item.id === id);
  if (!invoice) return json(res, 404, { error: "Factuur niet gevonden." });
  const filePath = path.join(INVOICE_UPLOAD_DIR, invoice.storedName);
  if (!filePath.startsWith(INVOICE_UPLOAD_DIR) || !fs.existsSync(filePath)) return json(res, 404, { error: "Bestand niet gevonden." });

  res.writeHead(200, securityHeaders({
    "Content-Type": contentTypeFor(invoice.originalName),
    "Content-Disposition": `attachment; filename="${encodeURIComponent(invoice.originalName)}"`
  }));
  writeAuditLog({
    req,
    actor: user,
    action: "finance.invoice.downloaded",
    entityType: "uploaded_invoice",
    entityId: invoice.id,
    status: "success"
  });
  fs.createReadStream(filePath).pipe(res);
}

async function updateFinanceMatch(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  if (user.role !== "admin") return json(res, 403, { error: "Alleen admin kan finance matches aanpassen." });

  const matchId = decodeURIComponent(req.url.split("?")[0].split("/")[4] || "");
  if (!matchId) return json(res, 400, { error: "Match ontbreekt." });
  const body = await bodyJson(req);
  const status = ["approved", "changed", "ignored", "open"].includes(body.status) ? body.status : "";
  if (!status) return json(res, 400, { error: "Gebruik approved, changed, ignored of open." });

  const decisions = readFinanceMatchDecisions();
  if (status === "open") {
    delete decisions[matchId];
  } else {
    decisions[matchId] = {
      matchId,
      status,
      targetId: cleanName(body.targetId),
      targetType: cleanName(body.targetType),
      category: cleanName(body.category),
      spendType: ["business", "private", "mixed", "unknown"].includes(body.spendType) ? body.spendType : "",
      note: cleanName(body.note),
      updatedAt: new Date().toISOString(),
      updatedBy: user.id
    };
  }
  writeFinanceMatchDecisions(decisions);
  writeAuditLog({
    req,
    actor: user,
    action: "finance.match.updated",
    entityType: "finance_match",
    entityId: matchId,
    after: decisions[matchId] || { status: "open" },
    status: "success"
  });

  const data = await loadDashboardData();
  json(res, 200, { ok: true, matchId, financeMatching: data.os?.finance?.financeMatching || null });
}

async function syncStripeInvoices(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  if (user.role !== "admin") return json(res, 403, { error: "Alleen admin kan Stripe synchroniseren." });
  if (!STRIPE_SECRET_KEY || STRIPE_SECRET_KEY.includes("zet-je")) {
    return json(res, 400, { error: "Stripe is nog niet gekoppeld. Zet STRIPE_SECRET_KEY in .env en herstart de server." });
  }

  const startedAt = new Date().toISOString();
  let invoices = [];
  let upcomingSubscriptions = [];
  try {
    invoices = await fetchStripeInvoices();
    upcomingSubscriptions = await fetchStripeUpcomingSubscriptions();
  } catch (error) {
    writeIntegrationHealth("stripe", "error", error.message, { startedAt });
    throw error;
  }
  const normalized = invoices.map(normalizeStripeInvoice);
  const normalizedUpcoming = upcomingSubscriptions.map(normalizeStripeUpcomingSubscription).filter((item) => item.amount > 0);
  writeJson(STRIPE_SYNC_FILE, {
    source: "stripe",
    syncedAt: new Date().toISOString(),
    startedAt,
    count: normalized.length,
    upcomingCount: normalizedUpcoming.length,
    invoices: normalized,
    upcomingSubscriptions: normalizedUpcoming
  });
  mirrorStripeSyncToSupabase({
    rawInvoices: invoices,
    rawSubscriptions: upcomingSubscriptions,
    invoices: normalized,
    upcomingSubscriptions: normalizedUpcoming
  });
  writeIntegrationHealth("stripe", "success", `${normalized.length} facturen en ${normalizedUpcoming.length} aankomende abonnementen opgehaald.`, {
    count: normalized.length,
    upcomingCount: normalizedUpcoming.length,
    startedAt
  });
  writeAuditLog({
    req,
    actor: user,
    action: "integration.stripe.synced",
    entityType: "integration",
    entityId: "stripe",
    after: { count: normalized.length, upcomingCount: normalizedUpcoming.length },
    status: "success"
  });
  json(res, 200, {
    syncedAt: new Date().toISOString(),
    count: normalized.length,
    upcomingCount: normalizedUpcoming.length,
    invoices: normalized,
    upcomingSubscriptions: normalizedUpcoming
  });
}

async function findWiseProfiles(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  if (user.role !== "admin") return json(res, 403, { error: "Alleen admin kan Wise-profielen ophalen." });
  if (!WISE_API_TOKEN || WISE_API_TOKEN.includes("zet-je")) {
    return json(res, 400, { error: "Wise is nog niet gekoppeld. Zet WISE_API_TOKEN in .env en herstart de server." });
  }

  let profiles = [];
  try {
    profiles = await fetchWiseProfiles();
  } catch (error) {
    writeIntegrationHealth("wise", "error", error.message, { operation: "profiles" });
    return json(res, 400, { error: `Wise-profielen konden niet worden opgehaald: ${error.message}` });
  }
  const normalized = profiles.map((profile) => ({
    id: String(profile.id || ""),
    type: profile.type || "",
    name: profile.name || profile.fullName || profile.businessName || "Wise profiel",
    details: {
      firstName: profile.firstName || "",
      lastName: profile.lastName || "",
      businessName: profile.businessName || "",
      email: profile.email || ""
    },
    configured: WISE_PROFILE_ID ? String(profile.id) === String(WISE_PROFILE_ID) : false
  }));

  writeIntegrationHealth("wise", "success", `${normalized.length} Wise-profielen opgehaald.`, {
    operation: "profiles",
    count: normalized.length,
    businessProfileConfigured: Boolean(WISE_BUSINESS_PROFILE_ID),
    personalProfileConfigured: Boolean(WISE_PERSONAL_PROFILE_ID)
  });
  writeAuditLog({
    req,
    actor: user,
    action: "integration.wise.profiles_checked",
    entityType: "integration",
    entityId: "wise",
    after: { count: normalized.length },
    status: "success"
  });
  json(res, 200, {
    count: normalized.length,
    configuredProfileId: WISE_PROFILE_ID || null,
    businessProfileId: WISE_BUSINESS_PROFILE_ID || null,
    personalProfileId: WISE_PERSONAL_PROFILE_ID || null,
    profiles: normalized
  });
}

async function syncWiseTransactions(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  if (user.role !== "admin") return json(res, 403, { error: "Alleen admin kan Wise synchroniseren." });
  if (!WISE_API_TOKEN || WISE_API_TOKEN.includes("zet-je")) {
    return json(res, 400, { error: "Wise is nog niet gekoppeld. Zet WISE_API_TOKEN in .env en herstart de server." });
  }

  const profiles = [
    { id: WISE_BUSINESS_PROFILE_ID, spendType: "business", label: "Zakelijk" },
    { id: WISE_PERSONAL_PROFILE_ID, spendType: "private", label: "Prive" }
  ].filter((profile) => profile.id);

  if (!profiles.length) {
    return json(res, 400, { error: "Geen Wise-profielen ingesteld. Zet WISE_BUSINESS_PROFILE_ID en/of WISE_PERSONAL_PROFILE_ID in .env." });
  }

  const startedAt = new Date().toISOString();
  const results = [];
  for (const profile of profiles) {
    const transactions = await fetchWiseTransactionsForProfile(profile);
    results.push({ ...profile, transactions });
  }
  const allTransactions = results.flatMap((result) => result.transactions);
  const successfulTransactions = allTransactions.filter((transaction) => transaction.status !== "error");
  const current = readWiseSync();
  const preservedTransactions = Array.isArray(current.transactions) ? current.transactions.filter((transaction) => transaction.status !== "error") : [];
  const storedTransactions = successfulTransactions.length ? mergeWiseTransactions(preservedTransactions, successfulTransactions) : preservedTransactions;
  writeJson(WISE_SYNC_FILE, {
    source: "wise",
    syncMode: "csv_or_api",
    syncedAt: new Date().toISOString(),
    startedAt,
    profiles: results.map((result) => ({ id: result.id, spendType: result.spendType, label: result.label, count: result.transactions.length })),
    apiErrors: allTransactions.filter((transaction) => transaction.status === "error"),
    transactions: storedTransactions
  });
  writeIntegrationHealth("wise", successfulTransactions.length ? "success" : "partial", `${successfulTransactions.length} transacties opgehaald, ${allTransactions.filter((transaction) => transaction.status === "error").length} fouten.`, {
    operation: "transactions",
    count: successfulTransactions.length,
    errors: allTransactions.filter((transaction) => transaction.status === "error").length,
    total: storedTransactions.length
  });
  writeAuditLog({
    req,
    actor: user,
    action: "integration.wise.synced",
    entityType: "integration",
    entityId: "wise",
    after: { count: successfulTransactions.length, total: storedTransactions.length },
    status: "success"
  });

  json(res, 200, {
    syncedAt: new Date().toISOString(),
    count: successfulTransactions.length,
    errors: allTransactions.filter((transaction) => transaction.status === "error").length,
    total: storedTransactions.length,
    profiles: results.map((result) => ({
      id: result.id,
      spendType: result.spendType,
      label: result.label,
      count: result.transactions.filter((transaction) => transaction.status !== "error").length,
      errors: result.transactions.filter((transaction) => transaction.status === "error").length
    }))
  });
}

async function uploadWiseCsv(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  if (user.role !== "admin") return json(res, 403, { error: "Alleen admin kan Wise CSV's uploaden." });

  const parsed = await multipartForm(req);
  const file = parsed.files.statement;
  if (!file || !file.content.length) return json(res, 400, { error: "Upload een Wise CSV-bestand." });
  if (path.extname(file.filename || "").toLowerCase() !== ".csv") return json(res, 400, { error: "Gebruik een CSV-export uit Wise." });

  const spendType = ["business", "private"].includes(parsed.fields.spendType) ? parsed.fields.spendType : "business";
  const profileLabel = spendType === "private" ? "Prive" : "Zakelijk";
  const importedAt = new Date().toISOString();
  const transactions = parseWiseCsvTransactions(file.content.toString("utf8"), {
    spendType,
    profileLabel,
    importedAt,
    filename: file.filename || "wise-export.csv"
  });
  if (!transactions.length) return json(res, 400, { error: "Geen transacties gevonden in deze CSV." });

  const current = readWiseSync();
  const previous = Array.isArray(current.transactions) ? current.transactions.filter((item) => item.status !== "error") : [];
  const merged = mergeWiseTransactions(previous, transactions);
  writeJson(WISE_SYNC_FILE, {
    source: "wise",
    syncMode: "csv_or_api",
    syncedAt: importedAt,
    lastCsvImport: {
      importedAt,
      filename: safeOriginalName(file.filename),
      spendType,
      importedCount: transactions.length,
      totalCount: merged.length
    },
    transactions: merged
  });
  writeIntegrationHealth("wise", "success", `${transactions.length} Wise CSV-transacties geimporteerd.`, {
    operation: "csv_upload",
    importedCount: transactions.length,
    totalCount: merged.length,
    spendType
  });
  writeAuditLog({
    req,
    actor: user,
    action: "integration.wise.csv_uploaded",
    entityType: "integration",
    entityId: "wise",
    after: { importedCount: transactions.length, totalCount: merged.length, spendType },
    status: "success"
  });

  json(res, 201, {
    importedAt,
    count: transactions.length,
    total: merged.length,
    spendType
  });
}

async function syncUsageCosts(req, res) {
  const user = authUser(req);
  if (!user) return json(res, 401, { error: "Niet ingelogd." });
  if (user.role !== "admin") return json(res, 403, { error: "Alleen admin kan usage-kosten synchroniseren." });

  const usage = await buildUsageCostData();
  writeJson(USAGE_COST_FILE, usage);
  writeIntegrationHealth("usage", usage.source === "demo_usage_model" ? "demo" : "success", `${usage.agents.length} AI medewerkers verwerkt.`, {
    source: usage.source,
    agents: usage.agents.length,
    totals: usage.totals,
    providers: usage.providers
  });
  writeAuditLog({
    req,
    actor: user,
    action: "integration.usage.synced",
    entityType: "integration",
    entityId: "usage",
    after: { source: usage.source, agents: usage.agents.length, totals: usage.totals },
    status: "success"
  });
  json(res, 200, {
    syncedAt: usage.syncedAt,
    source: usage.source,
    agents: usage.agents.length,
    totals: usage.totals,
    providers: usage.providers
  });
}

async function fetchWiseProfiles() {
  const response = await fetch("https://api.transferwise.com/v1/profiles", {
    headers: {
      Authorization: `Bearer ${WISE_API_TOKEN}`,
      "Content-Type": "application/json"
    }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error_description || data.message || `Wise ${response.status}`);
  return Array.isArray(data) ? data : [];
}

async function fetchWiseTransactionsForProfile(profile) {
  const balances = await fetchWiseBalances(profile.id);
  const intervalEnd = new Date().toISOString();
  const intervalStart = new Date(Date.now() - 90 * 86400000).toISOString();
  const transactions = [];

  for (const balance of balances) {
    try {
      const statement = await fetchWiseBalanceStatement(profile.id, balance.id, balance.currency, intervalStart, intervalEnd);
      const rows = Array.isArray(statement.transactions) ? statement.transactions : [];
      transactions.push(...rows.map((transaction) => normalizeWiseTransaction(transaction, profile, balance)));
    } catch (error) {
      transactions.push({
        id: `wise-error-${profile.id}-${balance.id}`,
        profileId: String(profile.id),
        profileLabel: profile.label,
        spendType: profile.spendType,
        balanceId: String(balance.id),
        currency: balance.currency,
        date: new Date().toISOString().slice(0, 10),
        description: `Wise statement kon niet worden opgehaald: ${error.message}`,
        amount: 0,
        direction: "error",
        status: "error",
        source: "Wise"
      });
    }
  }

  return transactions;
}

async function fetchWiseBalances(profileId) {
  const response = await fetch(`https://api.transferwise.com/v4/profiles/${encodeURIComponent(profileId)}/balances?types=STANDARD`, {
    headers: {
      Authorization: `Bearer ${WISE_API_TOKEN}`,
      "Content-Type": "application/json"
    }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error_description || data.message || `Wise balances ${response.status}`);
  return Array.isArray(data) ? data.map((balance) => ({
    id: balance.id,
    currency: balance.currency || balance.amount?.currency || "EUR"
  })) : [];
}

async function fetchWiseBalanceStatement(profileId, balanceId, currency, intervalStart, intervalEnd) {
  const params = new URLSearchParams({
    currency: currency || "EUR",
    intervalStart,
    intervalEnd,
    type: "COMPACT"
  });
  const response = await fetch(`https://api.transferwise.com/v1/profiles/${encodeURIComponent(profileId)}/balance-statements/${encodeURIComponent(balanceId)}/statement.json?${params.toString()}`, {
    headers: {
      Authorization: `Bearer ${WISE_API_TOKEN}`,
      "Content-Type": "application/json",
      Accept: "application/json"
    }
  });
  const text = await response.text();
  const data = text ? JSON.parse(text) : { transactions: [] };
  if (!response.ok) throw new Error(data.error_description || data.message || text || `Wise statement ${response.status}`);
  return data || {};
}

function normalizeWiseTransaction(transaction, profile, balance) {
  const value = Number(transaction.amount?.value ?? transaction.amount ?? 0);
  const details = transaction.details || {};
  return {
    id: String(transaction.id || transaction.referenceNumber || `${profile.id}-${balance.id}-${transaction.date}-${value}`),
    profileId: String(profile.id),
    profileLabel: profile.label,
    spendType: profile.spendType,
    balanceId: String(balance.id),
    currency: transaction.amount?.currency || balance.currency || "EUR",
    date: String(transaction.date || transaction.createdOn || "").slice(0, 10) || new Date().toISOString().slice(0, 10),
    description: details.description || details.title || transaction.description || transaction.type || "Wise transactie",
    amount: Math.abs(value),
    signedAmount: value,
    direction: value >= 0 ? "incoming" : "outgoing",
    status: transaction.status || "completed",
    source: "Wise",
    rawType: transaction.type || details.type || ""
  };
}

async function fetchStripeInvoices() {
  const params = new URLSearchParams();
  params.set("limit", "100");
  params.append("expand[]", "data.customer");
  const response = await fetch(`https://api.stripe.com/v1/invoices?${params.toString()}`, {
    headers: {
      Authorization: `Bearer ${STRIPE_SECRET_KEY}`
    }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || `Stripe ${response.status}`);
  return data.data || [];
}

async function fetchStripeUpcomingSubscriptions() {
  const now = Math.floor(Date.now() / 1000);
  const next30Days = now + 30 * 86400;
  const params = new URLSearchParams();
  params.set("limit", "100");
  params.set("status", "active");
  params.set("current_period_end[gte]", String(now));
  params.set("current_period_end[lte]", String(next30Days));
  params.append("expand[]", "data.customer");
  const response = await fetch(`https://api.stripe.com/v1/subscriptions?${params.toString()}`, {
    headers: {
      Authorization: `Bearer ${STRIPE_SECRET_KEY}`
    }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || `Stripe subscriptions ${response.status}`);
  return data.data || [];
}

function normalizeStripeInvoice(invoice) {
  const customer = typeof invoice.customer === "object" && invoice.customer ? invoice.customer : {};
  const customerName = invoice.customer_name || customer.name || invoice.account_name || "Onbekende klant";
  const status = stripeInvoiceStatus(invoice);
  return {
    id: invoice.id,
    invoiceNumber: invoice.number || invoice.id,
    customer: customerName,
    customerEmail: invoice.customer_email || customer.email || "",
    stripeCustomerId: customer.id || (typeof invoice.customer === "string" ? invoice.customer : ""),
    type: "Stripe factuur",
    status,
    amount: centsToEuro(invoice.amount_due || invoice.total || 0),
    amountPaid: centsToEuro(invoice.amount_paid || 0),
    amountRemaining: centsToEuro(invoice.amount_remaining || 0),
    issuedAt: unixDate(invoice.created),
    dueAt: unixDate(invoice.due_date) || unixDate(invoice.created),
    expectedPaymentAt: unixDate(invoice.due_date) || unixDate(invoice.created),
    paidAt: unixDate(invoice.status_transitions?.paid_at),
    hostedInvoiceUrl: invoice.hosted_invoice_url || "",
    source: "Stripe"
  };
}

function normalizeStripeUpcomingSubscription(subscription) {
  const customer = typeof subscription.customer === "object" && subscription.customer ? subscription.customer : {};
  const customerName = customer.name || subscription.metadata?.customerName || "Onbekende klant";
  const items = subscription.items?.data || [];
  const amount = items.reduce((sum, item) => {
    const price = item.price || item.plan || {};
    const quantity = Number(item.quantity || 1);
    return sum + centsToEuro(price.unit_amount || price.amount || 0) * quantity;
  }, 0);
  const nextPeriodEnd = subscription.current_period_end || items.map((item) => item.current_period_end).filter(Boolean).sort((a, b) => a - b)[0] || subscription.billing_cycle_anchor;
  const dueAt = unixDate(nextPeriodEnd);
  const productNames = items.map((item) => item.price?.nickname || item.plan?.nickname || item.price?.id || item.plan?.id).filter(Boolean);
  return {
    id: `stripe-upcoming-${subscription.id}-${subscription.current_period_end}`,
    invoiceNumber: `Upcoming ${String(subscription.id).slice(-6)}`,
    customer: customerName,
    customerEmail: customer.email || "",
    stripeCustomerId: customer.id || (typeof subscription.customer === "string" ? subscription.customer : ""),
    stripeSubscriptionId: subscription.id,
    type: productNames.length ? `Aankomend abonnement: ${productNames.join(", ")}` : "Aankomend Stripe abonnement",
    status: "forecast",
    amount: Number(amount.toFixed(2)),
    amountPaid: 0,
    amountRemaining: Number(amount.toFixed(2)),
    issuedAt: null,
    dueAt,
    expectedPaymentAt: dueAt,
    paidAt: null,
    source: "Stripe upcoming"
  };
}

function stripeInvoiceStatus(invoice) {
  if (invoice.status === "paid" || invoice.paid) return "paid";
  if (invoice.status === "draft") return "draft";
  const dueDate = invoice.due_date ? new Date(invoice.due_date * 1000) : null;
  if (dueDate && dueDate < new Date()) return "overdue";
  if (invoice.status === "open" || invoice.status === "uncollectible") return "open";
  return invoice.status || "open";
}

function centsToEuro(value) {
  return Number(((Number(value || 0)) / 100).toFixed(2));
}

function unixDate(value) {
  if (!value) return null;
  return new Date(value * 1000).toISOString().slice(0, 10);
}

async function debugLiveData(req, res) {
  const user = authUser(req);
  const params = new URL(req.url, "http://localhost").searchParams;
  const token = params.get("token");
  const refresh = params.get("refresh") === "1";
  const hasDebugToken = safeTokenMatch(token, DEBUG_TOKEN);
  if (!user && !hasDebugToken) return json(res, 401, { error: "Niet ingelogd." });
  if (user && user.role !== "admin") return json(res, 403, { error: "Alleen admin." });
  if (!GHL_TOKEN) return json(res, 400, { error: "GHL token ontbreekt." });
  const cached = readGhlSync();
  const raw = !refresh && cached ? cached.raw : await refreshGhlSync({ pageLimit: GHL_DASHBOARD_PAGE_LIMIT });
  json(res, 200, buildDebugPayload(raw));
}

function safeTokenMatch(value, expected) {
  if (!value || !expected) return false;
  const valueBuffer = Buffer.from(value);
  const expectedBuffer = Buffer.from(expected);
  return valueBuffer.length === expectedBuffer.length && crypto.timingSafeEqual(valueBuffer, expectedBuffer);
}

async function loadDashboardData() {
  if (GHL_TOKEN && !GHL_TOKEN.includes("zet-je")) {
    try {
      const cached = readGhlSync();
      const raw = cached && isFreshGhlSync(cached) ? cached.raw : await refreshGhlSync({ pageLimit: GHL_DASHBOARD_PAGE_LIMIT, fallback: cached?.raw });
      if (raw.diagnostics.authOk && raw.diagnostics.okCount > 0) return normalizeLiveData(raw);
      const fallback = demoData();
      fallback.rawSync = {
        mode: "ghl_error",
        syncedAt: new Date().toISOString(),
        error: raw.diagnostics.primaryError || "GHL gaf geen live datasets terug.",
        datasets: raw.diagnostics.datasets,
        opportunities: raw.opportunities.length,
        conversations: raw.conversations.length,
        contacts: raw.contacts.length,
        calendars: raw.calendars.length,
        calendarEvents: raw.calendarEvents.length,
        voiceCallLogs: raw.voiceCallLogs.length
      };
      applyGhlIntegrationStatus(fallback, raw.diagnostics);
      return fallback;
    } catch (error) {
      console.warn("Live sync niet beschikbaar, demo-data wordt gebruikt:", error.message);
      const fallback = demoData();
      fallback.rawSync = {
        mode: "ghl_error",
        syncedAt: new Date().toISOString(),
        error: error.message,
        datasets: {}
      };
      applyGhlIntegrationStatus(fallback, { authOk: false, primaryError: error.message, datasets: {} });
      return fallback;
    }
  }
  const fallback = demoData();
  fallback.rawSync = {
    mode: "ghl_error",
    syncedAt: new Date().toISOString(),
    error: GHL_TOKEN ? "GHL token is ongeldig of nog een placeholder." : "GHL token ontbreekt.",
    datasets: {}
  };
  applyGhlIntegrationStatus(fallback, { authOk: false, primaryError: fallback.rawSync.error, datasets: {} });
  return fallback;
}

async function fetchGoHighLevelData() {
  const raw = await fetchRawGoHighLevelData();
  return normalizeLiveData(raw);
}

async function refreshGhlSync({ pageLimit = GHL_DASHBOARD_PAGE_LIMIT, fallback = null } = {}) {
  const raw = await fetchRawGoHighLevelData({ pageLimit });
  if (raw.diagnostics.authOk && raw.diagnostics.okCount > 0) {
    writeJson(GHL_SYNC_FILE, {
      source: "gohighlevel",
      syncedAt: new Date().toISOString(),
      pageLimit,
      raw
    });
    return raw;
  }
  if (fallback) return {
    ...fallback,
    diagnostics: {
      ...fallback.diagnostics,
      staleBecause: raw.diagnostics.primaryError,
      datasets: raw.diagnostics.datasets
    }
  };
  return raw;
}

async function fetchRawGoHighLevelData({ pageLimit = GHL_DASHBOARD_PAGE_LIMIT } = {}) {
  const entries = [];
  for (const [label, fn] of [
    ["opportunities", () => fetchOpportunities(pageLimit)],
    ["conversations", () => fetchConversations(pageLimit)],
    ["contacts", () => fetchContacts(pageLimit)],
    ["pipelines", fetchPipelines],
    ["users", fetchGhlUsers],
    ["calendars", fetchCalendars],
    ["voiceCallLogs", fetchVoiceCallLogs],
    ["calendarEvents", fetchCalendarEventsForTeam]
  ]) {
    entries.push(await safeFetch(label, fn));
    await delay(150);
  }
  const byLabel = Object.fromEntries(entries.map((entry) => [entry.label, entry]));
  const diagnostics = buildGhlDiagnostics(byLabel);
  return {
    opportunities: byLabel.opportunities.data,
    conversations: byLabel.conversations.data,
    contacts: byLabel.contacts.data,
    pipelines: byLabel.pipelines.data,
    ghlUsers: byLabel.users.data,
    calendars: byLabel.calendars.data,
    voiceCallLogs: byLabel.voiceCallLogs.data,
    calendarEvents: byLabel.calendarEvents.data,
    diagnostics
  };
}

async function safeFetch(label, fn) {
  try {
    const data = await fn();
    return { label, ok: true, data, count: Array.isArray(data) ? data.length : 0, error: null, status: 200 };
  } catch (error) {
    console.warn(`${label} konden niet geladen worden:`, error.message);
    return { label, ok: false, data: [], count: 0, error: error.message, status: error.status || 0 };
  }
}

async function ghl(endpoint) {
  const response = await fetch(`https://services.leadconnectorhq.com${endpoint}`, {
    headers: {
      Authorization: `Bearer ${GHL_TOKEN}`,
      Version: "2023-02-21",
      "Content-Type": "application/json"
    }
  });
  const text = await response.text();
  const data = text ? JSON.parse(text) : {};
  if (!response.ok) {
    const message = data.message || data.error || data.error_description || `GHL ${response.status}`;
    const error = new Error(`${response.status}: ${message}`);
    error.status = response.status;
    throw error;
  }
  return data;
}

async function fetchOpportunities(pageLimit = GHL_DASHBOARD_PAGE_LIMIT) {
  const items = [];
  for (let page = 1; page <= pageLimit; page += 1) {
    const response = await pagedGhl(`/opportunities/search?location_id=${encodeURIComponent(LOCATION_ID)}&status=all&limit=100&page=${page}`, items, page);
    const chunk = response.opportunities || response.data || [];
    items.push(...chunk);
    if (chunk.length < 100) break;
    await delay(80);
  }
  return items;
}

async function fetchConversations(pageLimit = GHL_DASHBOARD_PAGE_LIMIT) {
  const items = [];
  for (let page = 1; page <= pageLimit; page += 1) {
    const response = await pagedGhl(`/conversations/search?locationId=${encodeURIComponent(LOCATION_ID)}&status=all&limit=100&page=${page}`, items, page);
    const chunk = response.conversations || response.data || [];
    items.push(...chunk);
    if (chunk.length < 100) break;
    await delay(80);
  }
  return items;
}

async function fetchContacts(pageLimit = GHL_DASHBOARD_PAGE_LIMIT) {
  const items = [];
  for (let page = 1; page <= pageLimit; page += 1) {
    const response = await pagedGhl(`/contacts/?locationId=${encodeURIComponent(LOCATION_ID)}&limit=100&page=${page}`, items, page);
    const chunk = response.contacts || response.data || [];
    items.push(...chunk);
    if (chunk.length < 100) break;
    await delay(80);
  }
  return items;
}

async function pagedGhl(endpoint, items, page) {
  try {
    return await ghl(endpoint);
  } catch (error) {
    if (error.status === 429 && page > 1 && items.length) return { data: [] };
    throw error;
  }
}

async function fetchPipelines() {
  const response = await ghl(`/opportunities/pipelines?locationId=${encodeURIComponent(LOCATION_ID)}`);
  return response.pipelines || response.data || [];
}

async function fetchGhlUsers() {
  const companyId = await fetchGhlCompanyId();
  const response = await ghl(`/users/search?companyId=${encodeURIComponent(companyId)}&locationId=${encodeURIComponent(LOCATION_ID)}`);
  return response.users || response.data || [];
}

async function fetchGhlCompanyId() {
  if (cachedGhlCompanyId) return cachedGhlCompanyId;
  const response = await ghl(`/locations/${encodeURIComponent(LOCATION_ID)}`);
  const companyId = response.companyId || response.location?.companyId || "";
  if (!companyId) throw new Error("GHL companyId kon niet worden bepaald uit location.");
  cachedGhlCompanyId = companyId;
  return cachedGhlCompanyId;
}

async function fetchCalendars() {
  const response = await ghl(`/calendars/?locationId=${encodeURIComponent(LOCATION_ID)}`);
  return response.calendars || response.data || [];
}

async function fetchCalendarEventsForTeam() {
  const range = dateRange();
  const closers = users.filter((user) => user.role === "closer");
  const events = [];
  for (const closer of closers) {
    const response = await ghl(`/calendars/events?locationId=${encodeURIComponent(LOCATION_ID)}&userId=${encodeURIComponent(closer.ghlUserId)}&startTime=${range.weekStartMs}&endTime=${range.weekEndMs}`);
    events.push(...(response.events || response.data || []));
  }
  return events;
}

async function fetchVoiceCallLogs() {
  const range = dateRange();
  const response = await ghl(`/voice-ai/dashboard/call-logs?locationId=${encodeURIComponent(LOCATION_ID)}&startDate=${range.weekStartMs}&endDate=${range.weekEndMs}&pageSize=50&page=1&sortBy=createdAt&sort=descend`);
  return response.callLogs || response.data || [];
}

function buildGhlDiagnostics(byLabel) {
  const datasets = Object.fromEntries(Object.entries(byLabel).map(([label, entry]) => [
    label,
    {
      ok: entry.ok,
      count: entry.count,
      status: entry.status,
      error: entry.error
    }
  ]));
  const entries = Object.values(byLabel);
  const okCount = entries.filter((entry) => entry.ok).length;
  const errorCount = entries.filter((entry) => !entry.ok).length;
  const authErrors = entries.filter((entry) => entry.status === 401 || /invalid jwt|unauthorized/i.test(entry.error || ""));
  const primaryError = authErrors[0]?.error || entries.find((entry) => entry.error)?.error || "";
  return {
    authOk: authErrors.length === 0,
    okCount,
    errorCount,
    primaryError,
    datasets
  };
}

async function buildUsageCostData() {
  const month = new Date().toISOString().slice(0, 7);
  const existing = readUsageCostSync();
  const baseAgents = existing.agents.length ? existing.agents : demoUsageAgents();
  const agents = baseAgents.map(normalizeUsageAgent);
  const totals = summarizeUsageAgents(agents);
  return {
    source: ELEVENLABS_API_KEY || TELNYX_API_KEY ? "configured_providers" : "demo_usage_model",
    syncedAt: new Date().toISOString(),
    month,
    providers: {
      elevenLabs: ELEVENLABS_API_KEY ? "Token ingesteld" : "Token ontbreekt",
      telnyx: TELNYX_API_KEY ? "Token ingesteld" : "Token ontbreekt"
    },
    agents,
    totals
  };
}

function demoUsageAgents() {
  return [
    {
      id: "agent-nova-receptionist",
      customerId: "cust-nova",
      customer: "Nova Dental Clinics",
      agentName: "Nova receptioniste",
      minutes: 842,
      voiceCost: 168.4,
      smsCount: 318,
      smsCost: 28.62,
      source: "Demo usage"
    },
    {
      id: "agent-vista-followup",
      customerId: "cust-vista",
      customer: "Vista Vastgoedbeheer",
      agentName: "Vista follow-up assistent",
      minutes: 376,
      voiceCost: 82.72,
      smsCount: 154,
      smsCost: 13.86,
      source: "Demo usage"
    },
    {
      id: "agent-horizon-service",
      customerId: "cust-horizon",
      customer: "Horizon Installatiegroep",
      agentName: "Horizon service agent",
      minutes: 1194,
      voiceCost: 298.5,
      smsCount: 521,
      smsCost: 46.89,
      source: "Demo usage"
    }
  ];
}

function normalizeUsageAgent(agent) {
  const minutes = Number(agent.minutes || 0);
  const voiceCost = Number(agent.voiceCost || 0);
  const smsCount = Number(agent.smsCount || 0);
  const smsCost = Number(agent.smsCost || 0);
  return {
    id: agent.id || `usage-${hashKey(`${agent.customer}-${agent.agentName}`)}`,
    customerId: agent.customerId || "",
    customer: agent.customer || "Onbekende klant",
    agentName: agent.agentName || "AI medewerker",
    minutes,
    averageCostPerMinute: minutes ? Number((voiceCost / minutes).toFixed(4)) : 0,
    voiceCost: Number(voiceCost.toFixed(2)),
    smsCount,
    costPerSms: smsCount ? Number((smsCost / smsCount).toFixed(4)) : 0,
    smsCost: Number(smsCost.toFixed(2)),
    totalCost: Number((voiceCost + smsCost).toFixed(2)),
    source: agent.source || "Usage feed"
  };
}

function summarizeUsageAgents(agents) {
  const minutes = sumNumbers(agents, "minutes");
  const voiceCost = sumNumbers(agents, "voiceCost");
  const smsCount = sumNumbers(agents, "smsCount");
  const smsCost = sumNumbers(agents, "smsCost");
  return {
    minutes,
    averageCostPerMinute: minutes ? Number((voiceCost / minutes).toFixed(4)) : 0,
    voiceCost,
    smsCount,
    costPerSms: smsCount ? Number((smsCost / smsCount).toFixed(4)) : 0,
    smsCost,
    totalCost: Number((voiceCost + smsCost).toFixed(2))
  };
}

function sumNumbers(items, key) {
  return Number((items || []).reduce((sum, item) => sum + Number(item[key] || 0), 0).toFixed(2));
}

function normalizeLiveData({ opportunities, conversations, contacts, pipelines, ghlUsers, calendars, voiceCallLogs, calendarEvents, diagnostics }) {
  const demo = demoData();
  const range = dateRange();
  const setterMembers = users.filter((user) => user.role === "setter");
  const closerMembers = users.filter((user) => user.role === "closer");
  const conversationOwnerByContactId = ownerByContact(conversations);
  const calendarNameById = Object.fromEntries((calendars || []).map((calendar) => [calendar.id, cleanName(calendar.name)]));
  const countedCalendarIds = new Set((calendars || [])
    .filter((calendar) => countedCalendarName(calendar.name))
    .map((calendar) => calendar.id));

  demo.rawSync = {
    mode: "live",
    opportunities: opportunities.length,
    conversations: conversations.length,
    contacts: contacts.length,
    pipelines: pipelines.length,
    users: ghlUsers.length,
    calendars: calendars.length,
    calendarEvents: calendarEvents.length,
    voiceCallLogs: voiceCallLogs.length,
    datasets: diagnostics.datasets,
    syncedAt: new Date().toISOString()
  };
  applyGhlIntegrationStatus(demo, diagnostics);

  demo.opportunityStageTotals = Object.fromEntries(Object.entries(SETTER_STAGES).map(([key, id]) => [
    key,
    opportunities.filter((item) => item.pipelineStageId === id || item.stageId === id).length
  ]));

  demo.closerStageTotals = Object.fromEntries(Object.entries(CLOSER_STAGES).map(([key, id]) => [
    key,
    opportunities.filter((item) => item.pipelineStageId === id || item.stageId === id).length
  ]));

  demo.setters = setterMembers.map((member) => {
    const assignedOpps = opportunities.filter((item) => opportunityOwner(item, conversationOwnerByContactId) === member.ghlUserId);
    const assignedEvents = calendarEvents.filter((event) => appointmentOwner(event, conversationOwnerByContactId) === member.ghlUserId && countedCalendarIds.has(event.calendarId));
    const bingoEvents = assignedEvents.filter((event) => isBingoAppointment(event));
    const stageBingoCount = assignedOpps.filter((item) => stageId(item) === SETTER_STAGES.bingo).length;
    const bingoCount = bingoEvents.length || stageBingoCount;
    const nopeCount = assignedOpps.filter((item) => stageId(item) === SETTER_STAGES.nopeNotToday).length;
    const callConversations = conversations.filter((item) => assignedConversation(item) === member.ghlUserId && isCallConversation(item));
    const callsToday = callConversations.filter((item) => inRange(dateValue(item.lastMessageDate || item.updatedAt || item.dateUpdated), range.todayStart, range.now)).length;
    const callsWeek = callConversations.filter((item) => inRange(dateValue(item.lastMessageDate || item.updatedAt || item.dateUpdated), range.weekStart, range.now)).length;
    const answeredCalls = callConversations.filter((item) => isAnsweredConversation(item)).length;
    const callMinutes = sumCallMinutes(callConversations, voiceCallLogs, member.ghlUserId);
    return {
      id: member.id,
      ghlUserId: member.ghlUserId,
      name: member.name,
      role: member.role,
      callMinutes,
      callsToday,
      callsWeek,
      answeredCalls,
      noShows: assignedEvents.filter((event) => appointmentStatus(event) === "no_show").length + assignedOpps.filter((item) => hasNoShowSignal(item)).length,
      bingos: bingoCount,
      callsPerBingo: ratio(callsWeek, bingoCount),
      conversationsPerBingo: ratio(answeredCalls, bingoCount),
      bingosPerHour: ratio(bingoCount, callMinutes / 60),
      nopePerBingo: ratio(nopeCount, bingoCount)
    };
  });

  demo.closers = closerMembers.map((member) => {
    const assignedOpps = opportunities.filter((item) => opportunityOwner(item, conversationOwnerByContactId) === member.ghlUserId);
    const won = assignedOpps.filter((item) => stageId(item) === CLOSER_STAGES.dealClosed || item.status === "won").length;
    const lost = assignedOpps.filter((item) => stageId(item) === CLOSER_STAGES.dealLost || item.status === "lost").length;
    const events = calendarEvents.filter((event) => event.assignedUserId === member.ghlUserId || (event.users || []).includes(member.ghlUserId));
    const countedEvents = events.filter((event) => countedCalendarIds.has(event.calendarId) || countedCalendarName(calendarNameById[event.calendarId]) || countedCalendarName(event.title));
    const noShows = assignedOpps.filter((item) => stageId(item) === CLOSER_STAGES.noShow).length + countedEvents.filter((event) => appointmentStatus(event) === "no_show").length;
    return {
      id: member.id,
      ghlUserId: member.ghlUserId,
      name: member.name,
      role: member.role,
      callMinutes: 0,
      showed: Math.max(0, countedEvents.length - noShows),
      meetings: countedEvents.length,
      won,
      lost,
      avgDaysToClose: averageDaysToClose(assignedOpps),
      closeRate: percentage(won, won + lost)
    };
  });

  demo.calls = normalizeCalls({ conversations, voiceCallLogs, setters: demo.setters, closers: demo.closers });
  demo.team = users.map(publicUser);
  demo.totals = buildTotals(demo.setters);

  return demo;
}

function applyGhlIntegrationStatus(data, diagnostics) {
  if (!data?.os?.integrations) return data;
  const datasetSummary = diagnostics?.datasets
    ? Object.entries(diagnostics.datasets).map(([label, item]) => `${label}: ${item.ok ? item.count : item.error}`).join(" | ")
    : "";
  data.os.integrations = data.os.integrations.map((item) => {
    if (item.name !== "GoHighLevel") return item;
    if (diagnostics?.authOk && diagnostics.okCount > 0) {
      return {
        ...item,
        status: `Live gekoppeld (${diagnostics.okCount} datasets)`,
        detail: datasetSummary || "GHL data wordt live opgehaald."
      };
    }
    return {
      ...item,
      status: "Token ongeldig of scopes missen",
      detail: diagnostics?.primaryError || "GHL gaf geen live data terug."
    };
  });
  return data;
}

function filterForRole(data, user) {
  const result = structuredClone(data);
  result.viewer = publicUser(user);
  if (user.role === "setter") {
    result.team = result.team.filter((member) => member.id === user.id);
    result.calls = result.calls.filter((call) => call.ownerId === user.id);
    result.setters = result.setters.filter((setter) => setter.id === user.id);
    result.closers = [];
    const setterTotals = result.setters.find((setter) => setter.id === user.id);
    if (setterTotals) {
      result.totals = {
        ...result.totals,
        callMinutes: setterTotals.callMinutes,
        callsToday: setterTotals.callsToday,
        callsWeek: setterTotals.callsWeek,
        answeredCalls: setterTotals.answeredCalls,
        noShows: setterTotals.noShows,
        bingos: setterTotals.bingos,
        callsPerBingo: setterTotals.callsPerBingo,
        conversationsPerBingo: setterTotals.conversationsPerBingo,
        bingosPerHour: setterTotals.bingosPerHour,
        nopePerBingo: setterTotals.nopePerBingo
      };
    }
    result.os = limitedOperatingSystemView(result.os);
  }
  if (user.role === "closer") {
    result.team = result.team.filter((member) => member.id === user.id);
    result.calls = result.calls.filter((call) => call.ownerId === user.id || call.closerId === user.id);
    result.setters = [];
    result.closers = result.closers.filter((closer) => closer.id === user.id);
    result.os = limitedOperatingSystemView(result.os);
  }
  return result;
}

function limitedOperatingSystemView(os) {
  return {
    ...os,
    ceo: null,
    finance: null,
    marketing: null,
    teamOps: null,
    customers: os.customers.map((customer) => ({
      id: customer.id,
      name: customer.name,
      domain: customer.domain,
      owner: customer.owner,
      stage: customer.stage,
      health: customer.health,
      nextMilestone: customer.nextMilestone,
      lastContact: customer.lastContact,
      deliveryRisk: customer.deliveryRisk
    }))
  };
}

function dateRange() {
  const now = new Date();
  const todayStart = new Date(now);
  todayStart.setHours(0, 0, 0, 0);
  const weekStart = new Date(todayStart);
  const day = weekStart.getDay() || 7;
  weekStart.setDate(weekStart.getDate() - day + 1);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 7);
  return {
    now,
    todayStart,
    weekStart,
    weekStartMs: weekStart.getTime(),
    weekEndMs: weekEnd.getTime()
  };
}

function dateValue(value) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function inRange(date, start, end) {
  return date && date >= start && date <= end;
}

function stageId(item) {
  return item.pipelineStageId || item.stageId || item.pipeline_stage_id || "";
}

function assignedTo(item) {
  return item.assignedTo || item.assigned_to || item.assignedUserId || item.userId || "";
}

function opportunityOwner(item, conversationOwnerByContactId) {
  return assignedTo(item) || conversationOwnerByContactId[contactId(item)] || "";
}

function contactId(item) {
  return item.contactId || item.contact_id || item.contact?.id || item.contact?.contactId || "";
}

function ownerByContact(conversations) {
  return conversations.reduce((acc, conversation) => {
    const owner = assignedConversation(conversation);
    const id = contactId(conversation);
    if (id && owner && !acc[id]) acc[id] = owner;
    return acc;
  }, {});
}

function assignedConversation(item) {
  return item.assignedTo || item.assigned_to || item.assignedUserId || item.userId || "";
}

function isCallConversation(item) {
  return String(item.lastMessageType || "").toUpperCase() === "TYPE_CALL";
}

function isAnsweredConversation(item) {
  const body = String(item.lastMessageBody || item.body || "").toLowerCase();
  const direction = String(item.lastMessageDirection || item.direction || "").toLowerCase();
  const status = String(item.status || item.callStatus || item.lastMessageStatus || "").toLowerCase();
  return isCallConversation(item) && !body.includes("missed") && !body.includes("voicemail") && !status.includes("missed") && direction !== "missed";
}

function hasNoShowSignal(item) {
  return stageId(item) === CLOSER_STAGES.noShow || String(item.name || item.status || "").toLowerCase().includes("no show");
}

function cleanName(value) {
  return String(value || "").trim();
}

function countedCalendarName(value) {
  const name = cleanName(value);
  return COUNTED_CALENDARS.some((calendar) => cleanName(calendar) === name);
}

function appointmentStatus(event) {
  return String(event.appointmentStatus || event.status || "").trim().toLowerCase().replace("-", "_");
}

function appointmentOwner(event, conversationOwnerByContactId) {
  return event.createdByUserId || event.createdBy?.userId || event.createdBy || event.bookedBy || event.assignedSetterId || conversationOwnerByContactId[contactId(event)] || "";
}

function isBingoAppointment(event) {
  const status = appointmentStatus(event);
  return status === "confirmed" || status === "showed" || status === "new";
}

function callDurationSeconds(item) {
  const values = [
    item.duration,
    item.callDuration,
    item.call_duration,
    item.durationSeconds,
    item.callDurationSeconds,
    item.lastMessageMeta?.duration,
    item.lastMessageMeta?.callDuration,
    item.metadata?.duration,
    item.metadata?.callDuration,
    item.callDetails?.duration
  ];
  const value = values.find((candidate) => candidate !== undefined && candidate !== null && candidate !== "");
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : 0;
}

function sumCallMinutes(callConversations, voiceCallLogs, ghlUserId) {
  const conversationSeconds = callConversations.reduce((sum, item) => sum + callDurationSeconds(item), 0);
  const voiceSeconds = voiceCallLogs
    .filter((log) => log.agentId === ghlUserId || log.userId === ghlUserId || log.assignedUserId === ghlUserId)
    .reduce((sum, log) => sum + callDurationSeconds(log), 0);
  return Number(((conversationSeconds + voiceSeconds) / 60).toFixed(1));
}

function ratio(numerator, denominator) {
  if (!denominator) return 0;
  return Number((numerator / denominator).toFixed(1));
}

function percentage(numerator, denominator) {
  if (!denominator) return 0;
  return Number(((numerator / denominator) * 100).toFixed(1));
}

function averageDaysToClose(opportunities) {
  const won = opportunities.filter((item) => stageId(item) === CLOSER_STAGES.dealClosed || item.status === "won");
  const days = won.map((item) => {
    const started = dateValue(item.createdAt || item.dateAdded || item.created_at);
    const closed = dateValue(item.lastStatusChangeAt || item.lastStageChangeAt || item.updatedAt || item.dateUpdated);
    if (!started || !closed) return null;
    return (closed - started) / 86400000;
  }).filter((value) => typeof value === "number" && value >= 0);
  if (!days.length) return 0;
  return Number((days.reduce((sum, value) => sum + value, 0) / days.length).toFixed(1));
}

function normalizeCalls({ conversations, voiceCallLogs, setters, closers }) {
  const closerId = closers[0] ? closers[0].id : "";
  const callLogs = voiceCallLogs
  .filter((log) => log.transcript || log.summary || callDurationSeconds(log) > 0)
  .map((log, index) => {
    const owner = setters.find((setter) => setter.ghlUserId === log.agentId) || setters[index % Math.max(1, setters.length)];
    return {
      id: log.id || `voice-call-${index}`,
      ownerId: owner ? owner.id : "",
      closerId,
      owner: owner ? owner.name : "Setter",
      contact: log.contactName || log.contactId || "Contact",
      date: String(log.createdAt || "").slice(0, 10),
      duration: secondsToClock(callDurationSeconds(log)),
      answered: callDurationSeconds(log) > 0,
      result: hasAppointmentAction(log) ? "Bingo" : "Call",
      score: 0,
      transcript: log.transcript || log.summary || "Nog geen transcriptie beschikbaar."
    };
  });

  if (callLogs.length) return callLogs;

  return conversations
    .filter(isCallConversation)
    .slice(0, 20)
    .map((conversation, index) => {
      const owner = setters.find((setter) => setter.ghlUserId === assignedConversation(conversation)) || setters[index % Math.max(1, setters.length)];
      return {
        id: conversation.id || `conversation-call-${index}`,
        ownerId: owner ? owner.id : "",
        closerId,
        owner: owner ? owner.name : "Setter",
        contact: conversation.fullName || conversation.contactName || conversation.phone || "Contact",
        date: String(conversation.lastMessageDate || conversation.updatedAt || conversation.dateUpdated || "").slice(0, 10),
        duration: secondsToClock(callDurationSeconds(conversation)),
        answered: isAnsweredConversation(conversation),
        result: "Call",
        score: 0,
        transcript: "Nog geen telefonische transcriptie beschikbaar."
      };
    });
}

function hasAppointmentAction(log) {
  return (log.executedCallActions || []).some((action) => action.actionType === "APPOINTMENT_BOOKING");
}

function secondsToClock(seconds) {
  const mins = Math.floor(Number(seconds || 0) / 60);
  const secs = Math.floor(Number(seconds || 0) % 60);
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

function buildTotals(setters) {
  const total = (key) => setters.reduce((sum, item) => sum + Number(item[key] || 0), 0);
  const callsWeek = total("callsWeek");
  const answeredCalls = total("answeredCalls");
  const bingos = total("bingos");
  const callMinutes = total("callMinutes");
  return {
    callMinutes: Number(callMinutes.toFixed(1)),
    callsToday: total("callsToday"),
    callsWeek,
    answeredCalls,
    noShows: total("noShows"),
    bingos,
    callsPerBingo: ratio(callsWeek, bingos),
    conversationsPerBingo: ratio(answeredCalls, bingos),
    bingosPerHour: ratio(bingos, callMinutes / 60),
    nopePerBingo: setters.length ? Number((setters.reduce((sum, item) => sum + Number(item.nopePerBingo || 0), 0) / setters.length).toFixed(1)) : 0
  };
}

function buildDebugPayload({ opportunities, conversations, contacts, pipelines, ghlUsers, calendars, voiceCallLogs, calendarEvents, diagnostics }) {
  const conversationOwnerByContactId = ownerByContact(conversations);
  return {
    generatedAt: new Date().toISOString(),
    counts: {
      opportunities: opportunities.length,
      conversations: conversations.length,
      contacts: contacts.length,
      pipelines: pipelines.length,
      users: ghlUsers.length,
      calendars: calendars.length,
      voiceCallLogs: voiceCallLogs.length,
      calendarEvents: calendarEvents.length
    },
    diagnostics,
    authStatus: diagnostics.authOk && diagnostics.okCount > 0
      ? "GHL gaf minimaal een dataset terug."
      : `GHL gaf geen bruikbare datasets terug: ${diagnostics.primaryError || "controleer token en scopes."}`,
    configuredTeam: users.map((user) => ({
      name: user.name,
      role: user.role,
      ghlUserId: user.ghlUserId
    })),
    configuredStages: {
      setter: SETTER_STAGES,
      closer: CLOSER_STAGES
    },
    observedOpportunityStages: countBy(opportunities, stageId),
    observedOpportunityAssignees: countBy(opportunities, assignedTo),
    observedOpportunityOwnersWithConversationFallback: countBy(opportunities, (item) => opportunityOwner(item, conversationOwnerByContactId)),
    observedConversationAssignees: countBy(conversations, assignedConversation),
    observedConversationTypes: countBy(conversations, (item) => item.lastMessageType || item.type || "unknown"),
    observedCalendars: calendars.map((calendar) => ({
      id: calendar.id,
      name: calendar.name,
      counted: countedCalendarName(calendar.name)
    })),
    observedPipelines: pipelines.map((pipeline) => ({
      id: pipeline.id,
      name: pipeline.name,
      stages: (pipeline.stages || []).map((stage) => ({ id: stage.id, name: stage.name }))
    })),
    observedUsers: ghlUsers.slice(0, 20).map((user) => ({
      id: user.id,
      name: user.name || `${user.firstName || ""} ${user.lastName || ""}`.trim(),
      email: user.email
    })),
    observedCalendarEventStatuses: countBy(calendarEvents, (event) => event.appointmentStatus || "unknown"),
    observedCalendarEventTitles: countBy(calendarEvents, (event) => event.title || "unknown"),
    samples: {
      opportunities: opportunities.slice(0, 5).map(sampleOpportunity),
      conversations: conversations.slice(0, 5).map(sampleConversation),
      contacts: contacts.slice(0, 5).map(sampleContact),
      calendarEvents: calendarEvents.slice(0, 5).map(sampleCalendarEvent),
      voiceCallLogs: voiceCallLogs.slice(0, 5).map(sampleVoiceCallLog)
    },
    notes: [
      "Als observedOpportunityAssignees niet matcht met configuredTeam.ghlUserId, tellen opportunities per persoon niet goed.",
      "Als observedConversationAssignees leeg of anders is, komen calls waarschijnlijk niet via conversations assignedTo binnen.",
      "Als voiceCallLogs leeg is, zijn transcripties/call logs niet beschikbaar via Voice AI of mist de scope voice-ai-dashboard.readonly.",
      "Als calendars niet counted zijn, moet de calendarnaam exact worden toegevoegd aan COUNTED_CALENDARS."
    ]
  };
}

function countBy(items, getKey) {
  return items.reduce((acc, item) => {
    const key = String(getKey(item) || "empty");
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
}

function sampleOpportunity(item) {
  return {
    id: item.id,
    contactId: contactId(item),
    name: item.name,
    pipelineId: item.pipelineId,
    pipelineStageId: stageId(item),
    assignedTo: assignedTo(item),
    status: item.status,
    createdAt: item.createdAt || item.dateAdded || item.created_at,
    updatedAt: item.updatedAt || item.dateUpdated,
    lastStageChangeAt: item.lastStageChangeAt,
    lastStatusChangeAt: item.lastStatusChangeAt
  };
}

function sampleConversation(item) {
  return {
    id: item.id,
    contactId: item.contactId,
    assignedTo: assignedConversation(item),
    lastMessageType: item.lastMessageType,
    type: item.type,
    lastMessageDirection: item.lastMessageDirection,
    lastMessageDate: item.lastMessageDate,
    updatedAt: item.updatedAt || item.dateUpdated,
    duration: callDurationSeconds(item),
    hasBody: Boolean(item.lastMessageBody)
  };
}

function sampleContact(item) {
  return {
    id: item.id,
    name: item.fullName || item.contactName || `${item.firstName || ""} ${item.lastName || ""}`.trim(),
    email: item.email,
    phone: item.phone,
    assignedTo: assignedTo(item),
    tags: item.tags || [],
    createdAt: item.createdAt || item.dateAdded
  };
}

function sampleCalendarEvent(event) {
  return {
    id: event.id,
    contactId: contactId(event),
    title: event.title,
    calendarId: event.calendarId,
    assignedUserId: event.assignedUserId,
    createdBy: event.createdBy,
    createdByUserId: event.createdByUserId,
    bookedBy: event.bookedBy,
    users: event.users,
    appointmentStatus: event.appointmentStatus,
    startTime: event.startTime,
    endTime: event.endTime
  };
}

function sampleVoiceCallLog(log) {
  return {
    id: log.id,
    contactId: log.contactId,
    agentId: log.agentId,
    createdAt: log.createdAt,
    duration: log.duration,
    hasTranscript: Boolean(log.transcript),
    hasSummary: Boolean(log.summary),
    actionTypes: (log.executedCallActions || []).map((action) => action.actionType)
  };
}

function scoreTranscript(call) {
  const text = call.transcript.toLowerCase();
  const positives = ["volgende stap", "afspraak", "bingo", "concreet", "budget", "probleem"];
  const gaps = ["misschien", "geen tijd", "twijfel", "later", "prijs"];
  const score = Math.max(58, Math.min(96, 72 + positives.filter((word) => text.includes(word)).length * 5 - gaps.filter((word) => text.includes(word)).length * 3));
  return {
    total: score,
    wentWell: [
      "De opening was duidelijk en rustig.",
      "De lead kreeg genoeg ruimte om het probleem uit te leggen.",
      call.result === "Bingo" ? "De setter stuurde goed naar een concrete Bingo." : "De setter hield het gesprek netjes gestructureerd."
    ],
    couldImprove: [
      "Maak de pijn en urgentie eerder concreet.",
      "Vat vaker samen voordat je naar de volgende vraag gaat.",
      "Eindig met een scherpere next step en check commitment."
    ],
    missedMoment: call.result === "Nope not today" ? "De lead gaf twijfel aan; hier had een korte herformulering van waarde kunnen helpen." : "Er was ruimte om de beslissingscriteria iets dieper uit te vragen."
  };
}

function demoData() {
  const setterMembers = users.filter((user) => user.role === "setter");
  const closerMembers = users.filter((user) => user.role === "closer");
  const demoSetters = setterMembers.map((member, index) => {
    const bingos = [8, 7, 6, 5, 5][index] || 4;
    const callsWeek = [248, 231, 219, 204, 198][index] || 160;
    const answeredCalls = [78, 72, 67, 61, 58][index] || 45;
    const callMinutes = [96, 82, 74, 63, 58][index] || 45;
    return {
      id: member.id,
      ghlUserId: member.ghlUserId,
      name: member.name,
      role: member.role,
      callMinutes,
      callsToday: [51, 45, 42, 38, 35][index] || 30,
      callsWeek,
      answeredCalls,
      noShows: [2, 3, 3, 4, 2][index] || 2,
      bingos,
      callsPerBingo: Number((callsWeek / Math.max(1, bingos)).toFixed(1)),
      conversationsPerBingo: Number((answeredCalls / Math.max(1, bingos)).toFixed(1)),
      bingosPerHour: Number((bingos / Math.max(1, callMinutes / 60)).toFixed(2)),
      nopePerBingo: Number(([0.5, 0.7, 0.8, 0.6, 0.4][index] || 0.5).toFixed(2))
    };
  });
  const demoClosers = closerMembers.map((member, index) => ({
    id: member.id,
    ghlUserId: member.ghlUserId,
    name: member.name,
    role: member.role,
    callMinutes: [64, 52][index] || 0,
    showed: [16, 14][index] || 0,
    meetings: [18, 15][index] || 0,
    won: [7, 5][index] || 0,
    lost: [4, 5][index] || 0,
    avgDaysToClose: [5.8, 7.2][index] || 0,
    closeRate: [38.9, 33.3][index] || 0
  }));
  const setterByIndex = (index) => demoSetters[index] || demoSetters[0] || { id: "unknown", name: "Setter" };
  const closerByIndex = (index) => demoClosers[index] || { id: "", name: "" };
  const total = (key) => demoSetters.reduce((sum, item) => sum + Number(item[key] || 0), 0);
  const totalBingos = total("bingos");
  const totalCallsWeek = total("callsWeek");
  const totalAnswered = total("answeredCalls");
  const totalCallMinutes = total("callMinutes");
  return {
    rawSync: { mode: "demo", opportunities: 24, conversations: 18, syncedAt: new Date().toISOString() },
    os: operatingSystemDemo(),
    stageConfig: { setter: SETTER_STAGES, closer: CLOSER_STAGES, countedCalendars: COUNTED_CALENDARS },
    opportunityStageTotals: { readyToCall: 38, called: 91, followUp: 27, nopeNotToday: 14, bingo: totalBingos },
    closerStageTotals: { discoveryCall: 18, followUpCall: 9, noShow: 7, proposalSent: 6, dealClosed: 5, dealLost: 4, future: 3 },
    totals: {
      callMinutes: Number(totalCallMinutes.toFixed(1)),
      callsToday: total("callsToday"),
      callsWeek: totalCallsWeek,
      answeredCalls: totalAnswered,
      noShows: total("noShows"),
      bingos: totalBingos,
      callsPerBingo: Number((totalCallsWeek / Math.max(1, totalBingos)).toFixed(1)),
      conversationsPerBingo: Number((totalAnswered / Math.max(1, totalBingos)).toFixed(1)),
      bingosPerHour: Number((totalBingos / Math.max(1, totalCallMinutes / 60)).toFixed(2)),
      nopePerBingo: Number((demoSetters.reduce((sum, item) => sum + item.nopePerBingo, 0) / Math.max(1, demoSetters.length)).toFixed(2))
    },
    setters: demoSetters,
    closers: demoClosers,
    calls: [
      { id: "call-1001", ownerId: setterByIndex(0).id, closerId: closerByIndex(0).id, owner: setterByIndex(0).name, contact: "Jasper van Dijk", date: "2026-06-08", duration: "12:48", answered: true, result: "Bingo", score: 86, transcript: "Setter: Hoi Jasper, ik bel kort over je aanvraag. Lead: Ik wil vooral minder handmatig opvolgen. Setter: Helder, dus het probleem zit in snelheid en opvolging. Lead: Ja, precies. Setter: Dan is een volgende stap logisch: een afspraak met onze specialist om te kijken welke pipeline nu lekt." },
      { id: "call-1002", ownerId: setterByIndex(1).id, closerId: closerByIndex(0).id, owner: setterByIndex(1).name, contact: "Linda Meijer", date: "2026-06-08", duration: "08:21", answered: true, result: "Follow up", score: 74, transcript: "Setter: Wat maakt dat je nu kijkt naar automatisering? Lead: We missen overzicht. Setter: Dan wil ik je later vandaag nog even terugpakken met twee concrete opties." },
      { id: "call-1003", ownerId: setterByIndex(2).id, closerId: closerByIndex(1).id, owner: setterByIndex(2).name, contact: "Ramon Peters", date: "2026-06-07", duration: "06:04", answered: true, result: "Nope not today", score: 68, transcript: "Setter: Past het om morgen te kijken? Lead: Misschien, maar ik heb geen tijd. Setter: Begrijpelijk, ik stuur nog wat info na." },
      { id: "call-1004", ownerId: setterByIndex(3).id, closerId: closerByIndex(1).id, owner: setterByIndex(3).name, contact: "Eva Bos", date: "2026-06-07", duration: "14:11", answered: true, result: "Bingo", score: 91, transcript: "Setter: Als ik je goed begrijp kost opvolging jullie deals. Lead: Ja, dat is het probleem. Setter: Dan plan ik een Bingo met onze closer, zodat jullie exact zien wat er anders moet." }
    ],
    team: users.map(publicUser)
  };
}

function operatingSystemDemo() {
  const uploadedInvoices = readUploadedInvoices().map(publicUploadedInvoice);
  const stripeSync = readStripeSync();
  const wiseSync = readWiseSync();
  const matchDecisions = readFinanceMatchDecisions();
  const usageCosts = readUsageCostSync();
  const customers = [
    {
      id: "cust-nova",
      name: "Nova Dental Clinics",
      domain: "novadental.nl",
      owner: "Tim Kuiper",
      stage: "Automations in bouw",
      health: "green",
      mrr: 3250,
      setupRevenue: 6500,
      grossMargin: 72,
      openInvoices: 0,
      usageCost: 418,
      nextMilestone: "Voice agent testcall afronden",
      lastContact: "2026-06-08",
      documentsComplete: true,
      deliveryRisk: "Laag"
    },
    {
      id: "cust-vista",
      name: "Vista Vastgoedbeheer",
      domain: "vistavastgoed.nl",
      owner: "Jean Paul Blommaert",
      stage: "Kickoff gepland",
      health: "orange",
      mrr: 2100,
      setupRevenue: 4200,
      grossMargin: 58,
      openInvoices: 4200,
      usageCost: 176,
      nextMilestone: "Intakeformulier compleet krijgen",
      lastContact: "2026-06-06",
      documentsComplete: false,
      deliveryRisk: "Middel"
    },
    {
      id: "cust-horizon",
      name: "Horizon Installatiegroep",
      domain: "horizon-installatie.nl",
      owner: "Kaan Karademir",
      stage: "Livegang",
      health: "red",
      mrr: 1850,
      setupRevenue: 3000,
      grossMargin: 39,
      openInvoices: 1850,
      usageCost: 922,
      nextMilestone: "Usage prijsafspraak herzien",
      lastContact: "2026-06-02",
      documentsComplete: true,
      deliveryRisk: "Hoog"
    }
  ];

  const openInvoices = customers.reduce((sum, customer) => sum + customer.openInvoices, 0);
  const mrr = customers.reduce((sum, customer) => sum + customer.mrr, 0);
  const setupRevenue = customers.reduce((sum, customer) => sum + customer.setupRevenue, 0);
  const averageMargin = Math.round(customers.reduce((sum, customer) => sum + customer.grossMargin, 0) / customers.length);
  const demoInvoiceForecast = [
    {
      id: "sales-inv-2026-101",
      invoiceNumber: "AP-2026-101",
      customer: "Nova Dental Clinics",
      type: "Verkoopfactuur",
      status: "paid",
      amount: 3250,
      issuedAt: "2026-06-01",
      dueAt: "2026-06-08",
      expectedPaymentAt: "2026-06-06",
      paidAt: "2026-06-06",
      source: "Stripe"
    },
    {
      id: "sales-inv-2026-102",
      invoiceNumber: "AP-2026-102",
      customer: "Vista Vastgoedbeheer",
      type: "Setup fee",
      status: "open",
      amount: 4200,
      issuedAt: "2026-06-05",
      dueAt: "2026-06-19",
      expectedPaymentAt: "2026-06-18",
      paidAt: null,
      source: "Stripe"
    },
    {
      id: "sales-inv-2026-103",
      invoiceNumber: "AP-2026-103",
      customer: "Horizon Installatiegroep",
      type: "Retainer",
      status: "overdue",
      amount: 1850,
      issuedAt: "2026-05-20",
      dueAt: "2026-06-03",
      expectedPaymentAt: "2026-06-12",
      paidAt: null,
      source: "Stripe"
    },
    {
      id: "sales-inv-2026-104",
      invoiceNumber: "AP-2026-104",
      customer: "Nova Dental Clinics",
      type: "Usage doorbelasting",
      status: "draft",
      amount: 418,
      issuedAt: "2026-06-09",
      dueAt: "2026-06-23",
      expectedPaymentAt: "2026-06-23",
      paidAt: null,
      source: "Forecast"
    }
  ];
  const invoiceForecast = buildStripeForecast(stripeSync, demoInvoiceForecast);
  const financeMatching = buildFinanceMatching({
    transactions: wiseSync.transactions,
    invoiceForecast,
    uploadedInvoices,
    decisions: matchDecisions
  });
  const matchedInvoiceIds = new Set(financeMatching.matches
    .filter((match) => match.status === "approved" && match.targetType === "sales_invoice")
    .map((match) => match.targetId));
  const matchedUploadIds = new Set(financeMatching.matches
    .filter((match) => match.status === "approved" && match.targetType === "uploaded_invoice")
    .map((match) => match.targetId));
  const enrichedInvoiceForecast = invoiceForecast.map((invoice) => {
    if (!matchedInvoiceIds.has(invoice.id) || invoice.paidAt) return invoice;
    const matched = financeMatching.matches.find((match) => match.targetId === invoice.id && match.status === "approved");
    return {
      ...invoice,
      status: "paid",
      paidAt: matched?.transactionDate || invoice.expectedPaymentAt,
      matchedBy: "Wise"
    };
  });
  const forecastOpen = enrichedInvoiceForecast
    .filter(isReceivableInvoice)
    .reduce((sum, invoice) => sum + invoice.amount, 0);
  const forecast7Days = enrichedInvoiceForecast
    .filter((invoice) => isReceivableInvoice(invoice) && daysUntil(invoice.expectedPaymentAt) <= 7)
    .reduce((sum, invoice) => sum + invoice.amount, 0);
  const forecast30Days = enrichedInvoiceForecast
    .filter((invoice) => isReceivableInvoice(invoice) && daysUntil(invoice.expectedPaymentAt) <= 30)
    .reduce((sum, invoice) => sum + invoice.amount, 0);
  const cashPosition = 48250;
  const wiseBusinessOut = sumWiseTransactions(wiseSync.transactions, "business", "outgoing");
  const wisePrivateOut = sumWiseTransactions(wiseSync.transactions, "private", "outgoing");
  const weeklyBusinessSpend = wiseBusinessOut || 4120;
  const weeklyPrivateSpend = wisePrivateOut || 870;
  const weeklyMixedSpend = 320;
  const cashflowForecast = buildCashflowForecast({
    cashPosition,
    forecast7Days,
    forecast30Days,
    weeklyBusinessSpend,
    weeklyPrivateSpend,
    weeklyMixedSpend,
    mrr
  });

  return {
    ceo: {
      cashPosition,
      openInvoices,
      mrr,
      newSalesThisMonth: setupRevenue,
      pipelineForecast: 38200,
      averageGrossMargin: averageMargin,
      deliveryRisks: customers.filter((customer) => customer.health !== "green").length,
      customerHealth: {
        green: customers.filter((customer) => customer.health === "green").length,
        orange: customers.filter((customer) => customer.health === "orange").length,
        red: customers.filter((customer) => customer.health === "red").length
      }
    },
    customers,
    finance: {
      paidInvoices: 28750,
      openInvoices,
      overdueInvoices: 1850,
      expectedCash30: 65400,
      forecastOpen,
      forecast7Days,
      forecast30Days,
      payable7Days: weeklyBusinessSpend + weeklyPrivateSpend + weeklyMixedSpend,
      payable30Days: (weeklyBusinessSpend + weeklyPrivateSpend + weeklyMixedSpend) * 4,
      cashflowForecast,
      invoiceForecast: enrichedInvoiceForecast,
      financeMatching,
      usageCosts,
      wiseTransactions: wiseSync.transactions,
      wiseSyncedAt: wiseSync.syncedAt,
      wiseBusinessOutgoing: wiseBusinessOut,
      wisePrivateOutgoing: wisePrivateOut,
      weeklyBusinessSpend,
      weeklyPrivateSpend,
      weeklyMixedSpend,
      businessVsPrivateDifference: 3250,
      uploadedInvoices,
      automaticSources: [
        {
          name: "Gmail inkomende facturen",
          status: "Nog niet gekoppeld",
          detail: "Haalt facturen uit mailboxlabels en leveranciersmails zodra Google/Gmail API is verbonden."
        },
        {
          name: "Stripe verkoopfacturen",
          status: STRIPE_SECRET_KEY ? (stripeSync.syncedAt ? "Gekoppeld" : "Klaar om te synchroniseren") : "Nog niet gekoppeld",
          detail: stripeSync.syncedAt
            ? `Laatst gesynchroniseerd: ${stripeSync.syncedAt}. ${stripeSync.invoices.length} facturen opgehaald.`
            : "Importeert automatisch verzonden facturen, betaalstatus en Stripe customer ID zodra de API-key in .env staat."
        },
        {
          name: "Wise betalingen",
          status: wiseSync.syncedAt ? "CSV/API actief" : (WISE_API_TOKEN ? "API klaar, CSV fallback beschikbaar" : "CSV fallback beschikbaar"),
          detail: wiseSync.syncedAt
            ? `Laatst bijgewerkt: ${wiseSync.syncedAt}. ${wiseSync.transactions.length} transacties beschikbaar met zakelijk/prive onderscheid.`
            : "Upload tijdelijk Wise CSV's. Zodra Wise statements via API toestaat, gebruikt dezelfde feed automatische transacties."
        },
        {
          name: "AI usage kosten",
          status: usageCosts.syncedAt ? "Usage feed actief" : "Demo usage actief",
          detail: usageCosts.syncedAt
            ? `Laatst bijgewerkt: ${usageCosts.syncedAt}. ${usageCosts.agents.length} AI medewerkers met ElevenLabs/Telnyx kosten.`
            : "Meet ElevenLabs minuten en Telnyx SMS per AI medewerker/klant zodra providerdata beschikbaar is."
        }
      ],
      subscriptions: [
        { name: "GoHighLevel", type: "CRM", owner: "Operations", monthlyCost: 497, split: "Zakelijk", score: "Essentieel" },
        { name: "ElevenLabs", type: "Voice AI", owner: "Delivery", monthlyCost: 330, split: "Zakelijk", score: "Essentieel" },
        { name: "Notion Personal", type: "Documentatie", owner: "Management", monthlyCost: 19, split: "Prive", score: "Twijfel" }
      ],
      reviewItems: [
        ...financeMatching.reviewQueue.slice(0, 8).map((match) => ({
          id: match.id,
          type: match.direction === "incoming" ? "Ontvangst match" : "Uitgave match",
          source: match.source,
          suggestion: match.suggestion,
          confidence: match.confidence,
          action: match.action
        })),
        ...uploadedInvoices.slice(0, 5).map((invoice) => ({
          id: invoice.id,
          type: "Upload factuur",
          source: "Manual upload",
          suggestion: `${invoice.vendorName} - ${invoice.spendType}${matchedUploadIds.has(invoice.id) ? " - gematcht" : ""}`,
          confidence: invoice.spendType === "unknown" ? 50 : 100,
          action: matchedUploadIds.has(invoice.id) ? "Gekoppeld aan betaling" : "Controle nodig"
        }))
      ]
    },
    delivery: {
      milestones: [
        { customer: "Nova Dental Clinics", phase: "Testfase", progress: 72, owner: "Delivery", risk: "Laag", next: "Voice agent testcall" },
        { customer: "Vista Vastgoedbeheer", phase: "Intake", progress: 28, owner: "Operations", risk: "Middel", next: "Klantinput ophalen" },
        { customer: "Horizon Installatiegroep", phase: "Livegang", progress: 88, owner: "Delivery", risk: "Hoog", next: "Kostenafspraak aanpassen" }
      ]
    },
    operations: {
      timeline: [
        { customer: "Nova Dental Clinics", type: "Read AI", detail: "Kickoff samenvatting opgeslagen", date: "2026-06-08" },
        { customer: "Vista Vastgoedbeheer", type: "Document", detail: "Verwerkersovereenkomst ontbreekt", date: "2026-06-07" },
        { customer: "Horizon Installatiegroep", type: "Alert", detail: "Usage stijgt sneller dan MRR", date: "2026-06-06" }
      ],
      incompleteDossiers: 1,
      missingContracts: 1,
      staleCustomers: 1
    },
    marketing: {
      reachToday: 18400,
      reachWeek: 126000,
      growth: 18,
      leads: 42,
      topPosts: [
        { channel: "LinkedIn", account: "Tim persoonlijk", title: "Waarom klantcontact automatiseren nu marge bepaalt", score: 91 },
        { channel: "TikTok", account: "Autopilots", title: "Voice agent demo voor vastgoedbeheer", score: 84 },
        { channel: "Instagram", account: "Autopilots", title: "Voor/na: follow-up proces", score: 78 }
      ]
    },
    teamOps: {
      activeMembers: users.length,
      capacityUsed: 76,
      lateTasks: 6,
      freelancersInOnboarding: 2,
      members: users.map((user, index) => ({
        name: user.name,
        role: user.role,
        clickupActivity: [92, 81, 74, 68, 63, 58, 86][index] || 60,
        ghlActivity: [84, 79, 76, 71, 69, 62, 88][index] || 60,
        risk: index === 3 ? "Vol" : "Normaal"
      }))
    },
    integrations: [
      { name: "GoHighLevel", status: "Demo/live voorbereid", owner: "Sales & CRM" },
      { name: "Stripe", status: STRIPE_SECRET_KEY ? "Klaar voor live sync" : "API-key ontbreekt", owner: "Finance" },
      { name: "Wise", status: WISE_API_TOKEN ? ((WISE_BUSINESS_PROFILE_ID || WISE_PERSONAL_PROFILE_ID) ? "Token + profielen ingesteld" : "Token ingesteld, profiel zoeken") : "API-token ontbreekt", owner: "Finance" },
      { name: "ClickUp", status: "Volgende koppeling", owner: "Delivery" },
      { name: "Read AI", status: "Fase 4", owner: "Operations" }
    ]
  };
}

function daysUntil(value) {
  const date = dateValue(value);
  if (!date) return Number.POSITIVE_INFINITY;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  date.setHours(0, 0, 0, 0);
  return Math.ceil((date.getTime() - today.getTime()) / 86400000);
}

function isReceivableInvoice(invoice) {
  return !invoice.paidAt && ["open", "overdue", "draft", "forecast"].includes(invoice.status);
}

function buildStripeForecast(stripeSync, fallbackInvoices) {
  const invoices = Array.isArray(stripeSync.invoices) ? stripeSync.invoices : [];
  const upcoming = Array.isArray(stripeSync.upcomingSubscriptions) ? stripeSync.upcomingSubscriptions : [];
  if (!invoices.length && !upcoming.length) return fallbackInvoices;

  const invoiceKeys = new Set(invoices.map((invoice) => forecastDedupeKey(invoice)));
  const uniqueUpcoming = upcoming.filter((item) => !invoiceKeys.has(forecastDedupeKey(item)));
  return [...invoices, ...uniqueUpcoming].sort((a, b) => {
    const aDate = a.expectedPaymentAt || a.dueAt || a.issuedAt || "";
    const bDate = b.expectedPaymentAt || b.dueAt || b.issuedAt || "";
    return String(aDate).localeCompare(String(bDate));
  });
}

function forecastDedupeKey(invoice) {
  return [
    normalizeSearchText(invoice.customer || invoice.customerEmail || invoice.stripeCustomerId),
    Number(invoice.amount || invoice.amountRemaining || 0).toFixed(2),
    invoice.expectedPaymentAt || invoice.dueAt || ""
  ].join("|");
}

function buildCashflowForecast({ cashPosition, forecast7Days, forecast30Days, weeklyBusinessSpend, weeklyPrivateSpend, weeklyMixedSpend, mrr }) {
  const weeklyOut = weeklyBusinessSpend + weeklyPrivateSpend + weeklyMixedSpend;
  const rows = [
    { period: "7 dagen", weeks: 1, incoming: forecast7Days },
    { period: "14 dagen", weeks: 2, incoming: forecast7Days },
    { period: "30 dagen", weeks: 4, incoming: forecast30Days },
    { period: "60 dagen", weeks: 8, incoming: forecast30Days + mrr }
  ];
  let previousEnding = cashPosition;
  return rows.map((row) => {
    const businessOutgoing = weeklyBusinessSpend * row.weeks;
    const privateOutgoing = weeklyPrivateSpend * row.weeks;
    const mixedOutgoing = weeklyMixedSpend * row.weeks;
    const totalOutgoing = weeklyOut * row.weeks;
    const netMovement = row.incoming - totalOutgoing;
    const endingCash = previousEnding + netMovement;
    const result = {
      period: row.period,
      startingCash: previousEnding,
      incoming: row.incoming,
      businessOutgoing,
      privateOutgoing,
      mixedOutgoing,
      totalOutgoing,
      netMovement,
      endingCash
    };
    previousEnding = endingCash;
    return result;
  });
}

function publicUser(user) {
  return { id: user.id, ghlUserId: user.ghlUserId, name: user.name, role: user.role, email: user.email };
}

function fallbackPassword(member) {
  if (process.env.NODE_ENV === "production") return crypto.randomBytes(24).toString("hex");
  if (member.role === "admin") return "autopilot";
  return "welkom";
}

function loginLimitKey(req, email) {
  return `${clientIp(req)}|${email || "unknown"}`;
}

function isLoginBlocked(key) {
  const item = loginAttempts.get(key);
  if (!item) return false;
  if (Date.now() - item.firstAt > LOGIN_WINDOW_MS) {
    loginAttempts.delete(key);
    return false;
  }
  return item.count >= LOGIN_MAX_ATTEMPTS;
}

function recordFailedLogin(key) {
  const now = Date.now();
  const item = loginAttempts.get(key);
  if (!item || now - item.firstAt > LOGIN_WINDOW_MS) {
    loginAttempts.set(key, { count: 1, firstAt: now, lastAt: now });
    return;
  }
  item.count += 1;
  item.lastAt = now;
}

function clearFailedLogin(key) {
  loginAttempts.delete(key);
}

function authUser(req) {
  const sid = cookie(req, "ap_sales_sid");
  const session = sid && sessions.get(sid);
  if (!session) return null;
  return users.find((user) => user.id === session.userId) || null;
}

function cookie(req, name) {
  const raw = req.headers.cookie || "";
  const item = raw.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
  return item ? decodeURIComponent(item.split("=").slice(1).join("=")) : "";
}

function sessionCookie(value) {
  const sameSite = process.env.NODE_ENV === "production" ? "SameSite=None; Secure" : "SameSite=Lax";
  return `${value}; HttpOnly; ${sameSite}; Path=/`;
}

async function bodyJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

async function bodyBuffer(req, maxBytes = 25 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw new Error("Bestand is te groot.");
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function multipartForm(req) {
  const contentType = req.headers["content-type"] || "";
  const boundaryMatch = contentType.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
  if (!boundaryMatch) throw new Error("Multipart boundary ontbreekt.");
  const boundary = Buffer.from(`--${boundaryMatch[1] || boundaryMatch[2]}`);
  const body = await bodyBuffer(req);
  const parts = splitBuffer(body, boundary);
  const fields = {};
  const files = {};

  for (const rawPart of parts) {
    let part = trimBoundaryPart(rawPart);
    if (!part.length || part.equals(Buffer.from("--"))) continue;
    const separator = part.indexOf(Buffer.from("\r\n\r\n"));
    if (separator === -1) continue;
    const headerText = part.slice(0, separator).toString("utf8");
    const content = part.slice(separator + 4);
    const disposition = headerText.split(/\r?\n/).find((line) => line.toLowerCase().startsWith("content-disposition")) || "";
    const name = attr(disposition, "name");
    if (!name) continue;
    const filename = attr(disposition, "filename");
    if (filename) {
      files[name] = { filename: safeOriginalName(filename), content };
    } else {
      fields[name] = content.toString("utf8").trim();
    }
  }

  return { fields, files };
}

function splitBuffer(buffer, separator) {
  const result = [];
  let start = 0;
  let index = buffer.indexOf(separator, start);
  while (index !== -1) {
    if (index > start) result.push(buffer.slice(start, index));
    start = index + separator.length;
    index = buffer.indexOf(separator, start);
  }
  if (start < buffer.length) result.push(buffer.slice(start));
  return result;
}

function trimBoundaryPart(part) {
  let start = 0;
  let end = part.length;
  while (start < end && (part[start] === 13 || part[start] === 10)) start += 1;
  while (end > start && (part[end - 1] === 13 || part[end - 1] === 10)) end -= 1;
  if (end - start >= 2 && part[end - 2] === 45 && part[end - 1] === 45) end -= 2;
  while (end > start && (part[end - 1] === 13 || part[end - 1] === 10)) end -= 1;
  return part.slice(start, end);
}

function attr(header, name) {
  const match = header.match(new RegExp(`${name}="([^"]*)"`, "i"));
  return match ? match[1] : "";
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function readUploadedInvoices() {
  try {
    if (!fs.existsSync(INVOICE_INDEX_FILE)) return [];
    return JSON.parse(fs.readFileSync(INVOICE_INDEX_FILE, "utf8"));
  } catch {
    return [];
  }
}

function writeUploadedInvoices(invoices) {
  ensureDir(INVOICE_UPLOAD_DIR);
  fs.writeFileSync(INVOICE_INDEX_FILE, JSON.stringify(invoices, null, 2));
}

function readStripeSync() {
  try {
    if (!fs.existsSync(STRIPE_SYNC_FILE)) return { syncedAt: null, invoices: [] };
    const data = JSON.parse(fs.readFileSync(STRIPE_SYNC_FILE, "utf8"));
    return {
      syncedAt: data.syncedAt || null,
      invoices: Array.isArray(data.invoices) ? data.invoices : [],
      upcomingSubscriptions: Array.isArray(data.upcomingSubscriptions) ? data.upcomingSubscriptions : []
    };
  } catch {
    return { syncedAt: null, invoices: [], upcomingSubscriptions: [] };
  }
}

function readWiseSync() {
  try {
    if (!fs.existsSync(WISE_SYNC_FILE)) return { syncedAt: null, transactions: [] };
    const data = JSON.parse(fs.readFileSync(WISE_SYNC_FILE, "utf8"));
    return {
      syncedAt: data.syncedAt || null,
      transactions: Array.isArray(data.transactions) ? data.transactions : []
    };
  } catch {
    return { syncedAt: null, transactions: [] };
  }
}

function readGhlSync() {
  try {
    if (!fs.existsSync(GHL_SYNC_FILE)) return null;
    const data = JSON.parse(fs.readFileSync(GHL_SYNC_FILE, "utf8"));
    if (!data.raw || !data.syncedAt) return null;
    return data;
  } catch {
    return null;
  }
}

function readUsageCostSync() {
  try {
    if (!fs.existsSync(USAGE_COST_FILE)) {
      const agents = demoUsageAgents().map(normalizeUsageAgent);
      return {
        source: "demo_usage_model",
        syncedAt: null,
        month: new Date().toISOString().slice(0, 7),
        providers: {
          elevenLabs: ELEVENLABS_API_KEY ? "Token ingesteld" : "Token ontbreekt",
          telnyx: TELNYX_API_KEY ? "Token ingesteld" : "Token ontbreekt"
        },
        agents,
        totals: summarizeUsageAgents(agents)
      };
    }
    const data = JSON.parse(fs.readFileSync(USAGE_COST_FILE, "utf8"));
    const agents = Array.isArray(data.agents) ? data.agents.map(normalizeUsageAgent) : [];
    return {
      source: data.source || "usage_feed",
      syncedAt: data.syncedAt || null,
      month: data.month || new Date().toISOString().slice(0, 7),
      providers: data.providers || {},
      agents,
      totals: summarizeUsageAgents(agents)
    };
  } catch {
    const agents = demoUsageAgents().map(normalizeUsageAgent);
    return { source: "demo_usage_model", syncedAt: null, month: new Date().toISOString().slice(0, 7), providers: {}, agents, totals: summarizeUsageAgents(agents) };
  }
}

function isFreshGhlSync(cache) {
  const syncedAt = dateValue(cache?.syncedAt);
  return Boolean(syncedAt && Date.now() - syncedAt.getTime() < GHL_CACHE_TTL_MS);
}

function readFinanceMatchDecisions() {
  try {
    if (!fs.existsSync(FINANCE_MATCH_FILE)) return {};
    const data = JSON.parse(fs.readFileSync(FINANCE_MATCH_FILE, "utf8"));
    return data && typeof data.decisions === "object" && !Array.isArray(data.decisions) ? data.decisions : {};
  } catch {
    return {};
  }
}

function writeFinanceMatchDecisions(decisions) {
  writeJson(FINANCE_MATCH_FILE, {
    updatedAt: new Date().toISOString(),
    decisions
  });
}

function sumWiseTransactions(transactions, spendType, direction) {
  return Number((transactions || [])
    .filter((transaction) => transaction.spendType === spendType && transaction.direction === direction && transaction.status !== "error")
    .reduce((sum, transaction) => sum + Number(transaction.amount || 0), 0)
    .toFixed(2));
}

function buildFinanceMatching({ transactions, invoiceForecast, uploadedInvoices, decisions }) {
  const usableTransactions = (transactions || [])
    .filter((transaction) => ["incoming", "outgoing"].includes(transaction.direction) && transaction.status !== "error")
    .slice(0, 250);
  const matches = usableTransactions.map((transaction) => buildTransactionMatch(transaction, invoiceForecast, uploadedInvoices, decisions));
  const approved = matches.filter((match) => match.status === "approved").length;
  const changed = matches.filter((match) => match.status === "changed").length;
  const ignored = matches.filter((match) => match.status === "ignored").length;
  const needsReview = matches.filter((match) => match.status === "review").length;
  const missingDocument = matches.filter((match) => match.status === "missing_document").length;
  const autoMatched = matches.filter((match) => match.autoApproved).length;
  const reviewQueue = matches
    .filter((match) => ["review", "missing_document", "changed"].includes(match.status))
    .sort((a, b) => b.confidence - a.confidence || String(b.transactionDate).localeCompare(String(a.transactionDate)));

  return {
    summary: {
      total: matches.length,
      approved,
      changed,
      ignored,
      needsReview,
      missingDocument,
      autoMatched,
      matchedAmountIncoming: sumMatches(matches, "incoming"),
      matchedAmountOutgoing: sumMatches(matches, "outgoing")
    },
    matches,
    reviewQueue
  };
}

function buildTransactionMatch(transaction, invoiceForecast, uploadedInvoices, decisions) {
  const direction = transaction.direction;
  const candidates = direction === "incoming"
    ? (invoiceForecast || []).map((invoice) => scoreSalesInvoiceCandidate(transaction, invoice)).filter(Boolean)
    : (uploadedInvoices || []).map((invoice) => scoreUploadedInvoiceCandidate(transaction, invoice)).filter(Boolean);
  candidates.sort((a, b) => b.score - a.score);
  const best = candidates[0] || null;
  const id = `match-${hashKey(`${transaction.id}|${best?.targetId || "missing"}`)}`;
  const decision = decisions[id];
  const category = decision?.category || best?.category || suggestFinanceCategory(transaction);
  const spendType = decision?.spendType || transaction.spendType || "unknown";
  const confidence = Math.max(0, Math.min(100, Math.round(decision?.status === "changed" ? 100 : best?.score || category.score || 40)));
  const autoApproved = Boolean(!decision && best && confidence >= 92);
  const status = decision?.status === "approved" ? "approved"
    : decision?.status === "changed" ? "changed"
      : decision?.status === "ignored" ? "ignored"
        : autoApproved ? "approved"
          : best ? "review"
            : "missing_document";

  return {
    id,
    transactionId: transaction.id,
    transactionDate: transaction.date,
    description: transaction.description,
    amount: transaction.amount,
    currency: transaction.currency || "EUR",
    direction,
    spendType,
    source: transaction.source || "Wise",
    targetId: decision?.targetId || best?.targetId || "",
    targetType: decision?.targetType || best?.targetType || "",
    targetLabel: best?.targetLabel || (direction === "incoming" ? "Geen Stripe factuur gevonden" : "Geen bon/factuur gevonden"),
    category: typeof category === "string" ? category : category.name,
    confidence,
    reasons: best?.reasons || [category.reason || "Geen harde match gevonden"],
    suggestion: best
      ? `${best.targetLabel} op ${moneyServer(transaction.amount)}`
      : `${direction === "incoming" ? "Ontvangst zonder verkoopfactuur" : "Uitgave mist bon/factuur"} - ${category.name || category}`,
    action: status === "approved" ? "Automatisch gekoppeld"
      : status === "changed" ? "Handmatig aangepast"
        : status === "ignored" ? "Genegeerd"
          : status === "missing_document" ? "Document/factuur toevoegen"
            : "Controle aanbevolen",
    status,
    autoApproved,
    decision: decision || null,
    candidates: candidates.slice(0, 3)
  };
}

function scoreSalesInvoiceCandidate(transaction, invoice) {
  const reasons = [];
  let score = 0;
  const amountDiff = Math.abs(Number(transaction.amount || 0) - Number(invoice.amount || 0));
  if (amountDiff < 0.01) {
    score += 55;
    reasons.push("bedrag exact gelijk");
  } else if (amountDiff <= Math.max(10, Number(invoice.amount || 0) * 0.03)) {
    score += 35;
    reasons.push("bedrag bijna gelijk");
  }
  const textScore = tokenOverlapScore(transaction.description, `${invoice.customer} ${invoice.invoiceNumber} ${invoice.customerEmail || ""}`);
  if (textScore >= 2) {
    score += 25;
    reasons.push("omschrijving lijkt op klant/factuur");
  } else if (textScore === 1) {
    score += 12;
    reasons.push("omschrijving heeft klant-signaal");
  }
  const days = Math.abs(daysBetweenServer(transaction.date, invoice.expectedPaymentAt || invoice.dueAt || invoice.issuedAt));
  if (days <= 3) {
    score += 15;
    reasons.push("datum ligt rond verwachte betaling");
  } else if (days <= 14) {
    score += 8;
    reasons.push("datum ligt binnen betaalvenster");
  }
  if (["open", "overdue", "draft"].includes(invoice.status)) score += 5;
  if (score < 35) return null;
  return {
    targetId: invoice.id,
    targetType: "sales_invoice",
    targetLabel: `${invoice.invoiceNumber} - ${invoice.customer}`,
    category: "Klantbetaling",
    score,
    reasons
  };
}

function scoreUploadedInvoiceCandidate(transaction, invoice) {
  const reasons = [];
  let score = 0;
  const invoiceAmount = Number(invoice.amount || 0);
  const amountDiff = Math.abs(Number(transaction.amount || 0) - invoiceAmount);
  if (invoiceAmount > 0 && amountDiff < 0.01) {
    score += 50;
    reasons.push("bedrag exact gelijk");
  } else if (invoiceAmount > 0 && amountDiff <= Math.max(10, invoiceAmount * 0.05)) {
    score += 30;
    reasons.push("bedrag bijna gelijk");
  }
  const textScore = tokenOverlapScore(transaction.description, `${invoice.vendorName} ${invoice.originalName} ${invoice.category}`);
  if (textScore >= 2) {
    score += 32;
    reasons.push("omschrijving lijkt op leverancier");
  } else if (textScore === 1) {
    score += 14;
    reasons.push("omschrijving heeft leverancier-signaal");
  }
  const days = Math.abs(daysBetweenServer(transaction.date, invoice.uploadedAt));
  if (days <= 7) {
    score += 10;
    reasons.push("betaling en upload liggen dicht bij elkaar");
  }
  if (invoice.spendType && invoice.spendType === transaction.spendType) score += 8;
  if (score < 30) return null;
  return {
    targetId: invoice.id,
    targetType: "uploaded_invoice",
    targetLabel: `${invoice.vendorName} - ${invoice.originalName}`,
    category: invoice.category || suggestFinanceCategory(transaction).name,
    score,
    reasons
  };
}

function suggestFinanceCategory(transaction) {
  const text = normalizeSearchText(transaction.description);
  const rules = [
    { name: "AI usage", score: 78, reason: "AI/voice leverancier herkend", words: ["openai", "anthropic", "elevenlabs", "telnyx", "supabase", "llm"] },
    { name: "Software", score: 72, reason: "software abonnement herkend", words: ["notion", "slack", "google", "zapier", "make", "github", "vercel"] },
    { name: "Marketing", score: 70, reason: "marketingplatform herkend", words: ["meta", "facebook", "linkedin", "tiktok", "youtube", "ads"] },
    { name: "Freelancer", score: 68, reason: "freelance/contractor signaal", words: ["freelance", "contractor", "upwork", "fiverr"] },
    { name: "Belasting/btw", score: 70, reason: "belasting signaal", words: ["belasting", "tax", "btw", "vat"] }
  ];
  const match = rules.find((rule) => rule.words.some((word) => text.includes(word)));
  if (match) return { name: match.name, score: match.score, reason: match.reason };
  return {
    name: transaction.direction === "incoming" ? "Klantbetaling" : (transaction.spendType === "private" ? "Prive" : "Nog te categoriseren"),
    score: transaction.direction === "incoming" ? 62 : 45,
    reason: "categorie op basis van richting en rekeningtype"
  };
}

function tokenOverlapScore(left, right) {
  const rightTokens = new Set(normalizeSearchText(right).split(" ").filter((token) => token.length >= 4));
  return normalizeSearchText(left).split(" ").filter((token) => token.length >= 4 && rightTokens.has(token)).length;
}

function normalizeSearchText(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9@.]+/g, " ").trim();
}

function daysBetweenServer(start, end) {
  const startDate = dateValue(start);
  const endDate = dateValue(end);
  if (!startDate || !endDate) return Number.POSITIVE_INFINITY;
  startDate.setHours(0, 0, 0, 0);
  endDate.setHours(0, 0, 0, 0);
  return Math.ceil((endDate.getTime() - startDate.getTime()) / 86400000);
}

function sumMatches(matches, direction) {
  return Number((matches || [])
    .filter((match) => match.status === "approved" && match.direction === direction)
    .reduce((sum, match) => sum + Number(match.amount || 0), 0)
    .toFixed(2));
}

function moneyServer(value) {
  return new Intl.NumberFormat("nl-NL", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(Number(value || 0));
}

function parseWiseCsvTransactions(csv, context) {
  const rows = parseCsvRows(csv);
  if (rows.length < 2) return [];
  const headers = rows[0].map((header) => normalizeHeader(header));

  return rows.slice(1).map((row, index) => {
    const record = headers.reduce((acc, header, columnIndex) => {
      if (header) acc[header] = (row[columnIndex] || "").trim();
      return acc;
    }, {});
    const date = firstValue(record, ["date", "createdon", "created", "time", "completedon", "transactiondate"]);
    const rawAmount = firstValue(record, ["amount", "targetamount", "sourceamount", "paidout", "paidin", "value"]);
    const amount = parseMoney(rawAmount);
    if (!date || !Number.isFinite(amount) || amount === 0) return null;
    const description = firstValue(record, ["description", "details", "merchant", "payee", "payeename", "payer", "payername", "reference", "paymentreference", "note", "type"]) || "Wise transactie";
    const currency = firstValue(record, ["currency", "targetcurrency", "sourcecurrency", "balancecurrency"]) || inferCurrency(rawAmount) || "EUR";
    const normalizedDate = normalizeDate(date);
    const direction = amount < 0 ? "outgoing" : "incoming";
    const absoluteAmount = Math.abs(amount);

    return {
      id: `wise-csv-${hashKey(`${context.spendType}|${normalizedDate}|${absoluteAmount}|${description}|${currency}`)}`,
      profileId: `csv-${context.spendType}`,
      profileLabel: context.profileLabel,
      spendType: context.spendType,
      balanceId: `csv-${context.spendType}-${currency}`,
      currency,
      date: normalizedDate,
      description,
      amount: absoluteAmount,
      direction,
      status: "completed",
      source: "Wise CSV",
      importedAt: context.importedAt,
      originalFile: safeOriginalName(context.filename),
      rowNumber: index + 2
    };
  }).filter(Boolean);
}

function parseCsvRows(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const normalized = String(csv || "").replace(/^\uFEFF/, "");
  const delimiter = detectCsvDelimiter(normalized);

  for (let index = 0; index < normalized.length; index += 1) {
    const char = normalized[index];
    const next = normalized[index + 1];
    if (char === '"' && quoted && next === '"') {
      field += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === delimiter && !quoted) {
      row.push(field);
      field = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(field);
      if (row.some((value) => value.trim())) rows.push(row);
      row = [];
      field = "";
    } else {
      field += char;
    }
  }

  row.push(field);
  if (row.some((value) => value.trim())) rows.push(row);
  return rows;
}

function detectCsvDelimiter(csv) {
  const firstLine = String(csv || "").split(/\r?\n/).find((line) => line.trim()) || "";
  const commas = (firstLine.match(/,/g) || []).length;
  const semicolons = (firstLine.match(/;/g) || []).length;
  return semicolons > commas ? ";" : ",";
}

function normalizeHeader(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function firstValue(record, keys) {
  for (const key of keys) {
    if (record[key]) return record[key];
  }
  return "";
}

function parseMoney(value) {
  const clean = String(value || "")
    .replace(/[^\d,.\-]/g, "")
    .replace(/\.(?=\d{3}(?:\D|$))/g, "")
    .replace(",", ".");
  const amount = Number(clean);
  return Number.isFinite(amount) ? amount : NaN;
}

function inferCurrency(value) {
  const match = String(value || "").match(/\b[A-Z]{3}\b/);
  return match ? match[0] : "";
}

function normalizeDate(value) {
  const raw = String(value || "").trim();
  const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;
  const european = raw.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})/);
  if (european) return `${european[3]}-${european[2].padStart(2, "0")}-${european[1].padStart(2, "0")}`;
  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? new Date().toISOString().slice(0, 10) : parsed.toISOString().slice(0, 10);
}

function hashKey(value) {
  return crypto.createHash("sha1").update(String(value)).digest("hex").slice(0, 16);
}

function mergeWiseTransactions(existing, imported) {
  const byId = new Map();
  [...existing, ...imported].forEach((transaction) => {
    if (transaction?.id) byId.set(transaction.id, transaction);
  });
  return [...byId.values()].sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")));
}

function writeJson(file, data) {
  ensureDir(path.dirname(file));
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function appendJsonArray(file, entry, maxEntries = 1000) {
  const rows = readJsonArray(file);
  rows.push(entry);
  writeJson(file, rows.slice(-maxEntries));
}

function readJsonArray(file) {
  if (!fs.existsSync(file)) return [];
  try {
    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function writeAuditLog({ req, actor = null, action, entityType, entityId = "", before = null, after = null, status = "success" }) {
  const entry = {
    id: `audit-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`,
    requestId: req?.requestId || "",
    actorId: actor?.id || null,
    actorRole: actor?.role || null,
    action,
    entityType,
    entityId,
    status,
    ip: req ? clientIp(req) : "",
    userAgent: req?.headers?.["user-agent"] || "",
    before,
    after,
    createdAt: new Date().toISOString()
  };
  appendJsonArray(AUDIT_LOG_FILE, entry, 5000);
  mirrorAuditLogToSupabase(entry);
}

function writeIntegrationHealth(name, status, detail, metadata = {}) {
  const current = readIntegrationHealth();
  const entry = {
    name,
    status,
    detail,
    metadata,
    checkedAt: new Date().toISOString()
  };
  current[name] = entry;
  writeJson(INTEGRATION_HEALTH_FILE, current);
  mirrorIntegrationHealthToSupabase(entry);
}

function readIntegrationHealth() {
  if (!fs.existsSync(INTEGRATION_HEALTH_FILE)) return {};
  try {
    const data = JSON.parse(fs.readFileSync(INTEGRATION_HEALTH_FILE, "utf8"));
    return data && typeof data === "object" && !Array.isArray(data) ? data : {};
  } catch {
    return {};
  }
}

function logError(req, error) {
  const entry = {
    level: "error",
    requestId: req?.requestId || "",
    method: req?.method || "",
    url: req?.url || "",
    message: error.message,
    stack: IS_PRODUCTION ? undefined : error.stack,
    createdAt: new Date().toISOString()
  };
  console.error(JSON.stringify(entry));
}

function clientIp(req) {
  const forwarded = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return forwarded || req.socket?.remoteAddress || "unknown";
}

function supabaseEnabled() {
  return Boolean(SUPABASE_REST_URL && SUPABASE_SERVICE_ROLE_KEY && !SUPABASE_SERVICE_ROLE_KEY.includes("zet-je"));
}

async function supabaseRequest(table, { method = "GET", query = "", body = null, prefer = "" } = {}) {
  if (!supabaseEnabled()) return { ok: false, skipped: true, error: "Supabase service role ontbreekt." };
  const headers = {
    apikey: SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
    "Content-Type": "application/json"
  };
  if (prefer) headers.Prefer = prefer;
  const response = await fetch(`${SUPABASE_REST_URL}/${table}${query}`, {
    method,
    headers,
    body: body === null ? undefined : JSON.stringify(body)
  });
  const text = await response.text();
  const data = text ? safeJsonParse(text, text) : null;
  if (!response.ok) {
    return {
      ok: false,
      status: response.status,
      error: typeof data === "string" ? data : (data.message || data.error || `Supabase ${response.status}`),
      data
    };
  }
  return { ok: true, status: response.status, data };
}

function safeJsonParse(value, fallback = null) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function mirrorAuditLogToSupabase(entry) {
  if (!supabaseEnabled()) return;
  supabaseRequest("audit_log", {
    method: "POST",
    prefer: "return=minimal",
    body: {
      action: entry.action,
      entity_type: entry.entityType,
      entity_id: entry.entityId || null,
      before_value: entry.before || null,
      after_value: {
        value: entry.after || null,
        audit_meta: {
          local_id: entry.id,
          request_id: entry.requestId,
          actor_id: entry.actorId,
          actor_role: entry.actorRole,
          status: entry.status,
          ip: entry.ip,
          user_agent: entry.userAgent
        }
      },
      created_at: entry.createdAt
    }
  }).then((result) => {
    if (!result.ok && !result.skipped) console.warn("Supabase audit mirror faalde:", result.error);
  }).catch((error) => console.warn("Supabase audit mirror faalde:", error.message));
}

function mirrorIntegrationHealthToSupabase(entry) {
  if (!supabaseEnabled()) return;
  supabaseRequest("integration_health", {
    method: "POST",
    query: "?on_conflict=source_system",
    prefer: "resolution=merge-duplicates,return=minimal",
    body: {
      source_system: entry.name,
      status: entry.status,
      detail: entry.detail,
      metadata: entry.metadata || {},
      checked_at: entry.checkedAt
    }
  }).then((result) => {
    if (!result.ok && !result.skipped) console.warn("Supabase integration health mirror faalde:", result.error);
  }).catch((error) => console.warn("Supabase integration health mirror faalde:", error.message));
}

function mirrorStripeSyncToSupabase({ rawInvoices, rawSubscriptions, invoices, upcomingSubscriptions }) {
  if (!supabaseEnabled()) return;
  const rawRows = [
    ...rawInvoices.map((invoice) => ({
      source_system: "stripe",
      source_id: String(invoice.id),
      entity_type: "invoice",
      payload: invoice
    })),
    ...rawSubscriptions.map((subscription) => ({
      source_system: "stripe",
      source_id: String(subscription.id),
      entity_type: "subscription",
      payload: subscription
    }))
  ];
  const invoiceRows = [...invoices, ...upcomingSubscriptions].map((invoice) => ({
    stripe_invoice_id: invoice.id,
    invoice_number: invoice.invoiceNumber,
    amount: Number(invoice.amount || invoice.amountRemaining || 0),
    currency: "eur",
    status: invoice.status || "open",
    issued_at: invoice.issuedAt || null,
    due_at: invoice.dueAt || null,
    paid_at: invoice.paidAt || null,
    source_system: invoice.source || "stripe",
    raw: invoice
  }));

  Promise.all([
    rawRows.length ? supabaseRequest("raw_imports", {
      method: "POST",
      query: "?on_conflict=source_system,source_id,entity_type",
      prefer: "resolution=merge-duplicates,return=minimal",
      body: rawRows
    }) : Promise.resolve({ ok: true }),
    invoiceRows.length ? supabaseRequest("invoices_sales", {
      method: "POST",
      query: "?on_conflict=stripe_invoice_id",
      prefer: "resolution=merge-duplicates,return=minimal",
      body: invoiceRows
    }) : Promise.resolve({ ok: true })
  ]).then((results) => {
    const failed = results.find((result) => !result.ok && !result.skipped);
    if (failed) {
      console.warn("Supabase Stripe mirror faalde:", failed.error);
      writeIntegrationHealth("supabase", "partial", `Stripe mirror faalde: ${failed.error}`, { source: "stripe" });
      return;
    }
    writeIntegrationHealth("supabase", "success", "Stripe raw/core records naar Supabase gespiegeld.", {
      rawRows: rawRows.length,
      invoiceRows: invoiceRows.length
    });
  }).catch((error) => {
    console.warn("Supabase Stripe mirror faalde:", error.message);
    writeIntegrationHealth("supabase", "partial", `Stripe mirror faalde: ${error.message}`, { source: "stripe" });
  });
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function publicUploadedInvoice(invoice) {
  return {
    id: invoice.id,
    originalName: invoice.originalName,
    vendorName: invoice.vendorName,
    category: invoice.category,
    spendType: invoice.spendType,
    amount: invoice.amount,
    status: invoice.status,
    reviewStatus: invoice.reviewStatus,
    uploadedAt: invoice.uploadedAt,
    size: invoice.size,
    downloadUrl: `/api/finance/invoices/${invoice.id}/download`
  };
}

function safeOriginalName(value) {
  return path.basename(String(value || "factuur")).replace(/[^\w.\- ()]/g, "_").slice(0, 160);
}

function safeExtension(filename) {
  const ext = path.extname(filename || "").toLowerCase();
  const allowed = new Set([".pdf", ".png", ".jpg", ".jpeg", ".webp", ".heic", ".txt", ".csv"]);
  return allowed.has(ext) ? ext : ".bin";
}

function contentTypeFor(filename) {
  const ext = path.extname(filename || "").toLowerCase();
  const types = {
    ".pdf": "application/pdf",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".heic": "image/heic",
    ".txt": "text/plain",
    ".csv": "text/csv"
  };
  return types[ext] || "application/octet-stream";
}

function staticFile(req, res) {
  const urlPath = req.url === "/" ? "/index.html" : decodeURIComponent(req.url.split("?")[0]);
  const target = path.normalize(path.join(PUBLIC, urlPath));
  if (!target.startsWith(PUBLIC)) return json(res, 403, { error: "Verboden." });
  if (!fs.existsSync(target)) return json(res, 404, { error: "Niet gevonden." });
  const ext = path.extname(target).toLowerCase();
  const types = { ".html": "text/html", ".css": "text/css", ".js": "application/javascript", ".svg": "image/svg+xml" };
  res.writeHead(200, securityHeaders({ "Content-Type": types[ext] || "application/octet-stream" }));
  fs.createReadStream(target).pipe(res);
}

function json(res, status, payload) {
  res.writeHead(status, securityHeaders({ "Content-Type": "application/json" }));
  res.end(JSON.stringify(payload));
}

function securityHeaders(headers = {}) {
  return {
    ...headers,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "SAMEORIGIN",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "Content-Security-Policy": [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline'",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: blob:",
      "connect-src 'self'",
      "frame-ancestors 'self'"
    ].join("; ")
  };
}

module.exports = {
  server,
  __test: {
    buildCashflowForecast,
    buildFinanceMatching,
    buildStripeForecast,
    filterForRole,
    publicUser,
    securityHeaders,
    safeJsonParse,
    supabaseEnabled,
    suggestFinanceCategory
  }
};
