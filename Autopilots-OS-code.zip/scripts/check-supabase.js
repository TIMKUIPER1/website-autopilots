const fs = require("fs");
const path = require("path");

function loadEnv(file) {
  if (!fs.existsSync(file)) return {};
  return fs.readFileSync(file, "utf8").split(/\r?\n/).reduce((acc, line) => {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (match) acc[match[1]] = match[2].trim();
    return acc;
  }, {});
}

async function checkTable(restUrl, key, table) {
  const response = await fetch(`${restUrl}/${table}?select=*&limit=1`, {
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`
    }
  });
  const text = await response.text();
  return {
    table,
    ok: response.ok,
    status: response.status,
    message: response.ok ? "bereikbaar" : text.slice(0, 220)
  };
}

(async () => {
  const env = { ...loadEnv(path.join(__dirname, "..", ".env")) };
  const url = String(env.SUPABASE_URL || "").replace(/\/$/, "");
  const key = env.SUPABASE_SERVICE_ROLE_KEY || "";
  if (!url || !key || key.includes("zet-je")) {
    console.log(JSON.stringify({ ok: false, configured: false, message: "SUPABASE_URL of SUPABASE_SERVICE_ROLE_KEY ontbreekt." }, null, 2));
    process.exit(1);
  }
  const restUrl = `${url}/rest/v1`;
  const tables = ["audit_log", "integration_health", "raw_imports", "invoices_sales"];
  const results = [];
  for (const table of tables) results.push(await checkTable(restUrl, key, table));
  const ok = results.every((result) => result.ok);
  console.log(JSON.stringify({ ok, configured: true, results }, null, 2));
  process.exit(ok ? 0 : 1);
})().catch((error) => {
  console.log(JSON.stringify({ ok: false, configured: true, error: error.message }, null, 2));
  process.exit(1);
});
