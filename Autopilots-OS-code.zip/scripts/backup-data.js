const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const root = path.join(__dirname, "..");
const dataDir = path.join(root, "data");
const backupDir = path.join(root, "backups");
const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const targetDir = path.join(backupDir, `data-backup-${stamp}`);

function sha256(file) {
  return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

function copyDir(from, to, manifest) {
  if (!fs.existsSync(from)) return;
  fs.mkdirSync(to, { recursive: true });
  for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
    const source = path.join(from, entry.name);
    const target = path.join(to, entry.name);
    if (entry.isDirectory()) {
      copyDir(source, target, manifest);
    } else if (entry.isFile()) {
      fs.copyFileSync(source, target);
      const relative = path.relative(dataDir, source);
      const stat = fs.statSync(source);
      manifest.files.push({
        path: relative,
        bytes: stat.size,
        sha256: sha256(source)
      });
    }
  }
}

const manifest = {
  source: dataDir,
  createdAt: new Date().toISOString(),
  files: []
};

fs.mkdirSync(targetDir, { recursive: true });
copyDir(dataDir, path.join(targetDir, "data"), manifest);
fs.writeFileSync(path.join(targetDir, "manifest.json"), JSON.stringify(manifest, null, 2));

console.log(`Backup gemaakt: ${targetDir}`);
console.log(`${manifest.files.length} bestanden vastgelegd.`);
